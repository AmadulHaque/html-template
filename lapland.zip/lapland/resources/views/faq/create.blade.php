@extends('layouts.app')
@section('site_title', $site_title)
@section('content')
    @push('styles')
       
    @endpush
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header py-2">
                    <h4 class="mb-0 cd-title d-flex align-items-center justify-content-between">{{ $title }}
                    </h4>
                </div>
                <div class="card-body">
                    <form id="store_or_update_form" action="{{ route('app.faq.store') }}" method="POST"
                        enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="update_id" id="update_id">
                        <div class="form-group">
                            <label for="question" class="required">Question</label>
                            <input type="text" class="form-control @error('question') is-invalid @enderror" id="question"
                                name="question" value="{{ old('question') }}">
                            @error('question')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="answer" class="required">Answer</label>
                            <textarea class="form-control summernote @error('answer') is-invalid @enderror" id="answer" name="answer" rows="4">{{ old('answer') }}</textarea>
                            @error('answer')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        

                        <div class="form-group text-center">
                            <input type="submit" id="submitBtn" class="btn btn-info btn-sm" value="Submit">
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

@endsection

@push('scripts')
<script>
    //SummerNote
$(function() {
    $('.summernote').summernote({
        height: 280,
    });

});
</script>
@endpush
