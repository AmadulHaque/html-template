@extends('layouts.app')
@section('site_title', $site_title)
@section('content')
    @push('styles')
       
    @endpush
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header py-2">
                    <h4 class="mb-0 cd-title d-flex align-items-center justify-content-between">{{ $title }}
                    </h4>
                </div>
                <div class="card-body">
                    <form id="store_or_update_form" action="{{ route('app.time-slot.store') }}" method="POST"
                        enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="update_id" id="update_id">
                        <div class="form-group">
                            <label for="title" class="required">Title</label>
                            <input type="text" class="form-control @error('title') is-invalid @enderror" id="title"
                                name="title" value="{{ old('title') }}">
                            @error('title')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="date_time" class="required">Time</label>
                                    <input type="datetime-local" class="form-control @error('date_time') is-invalid @enderror" id="date_time"
                                        name="date_time" value="{{ old('date_time') }}">
                                    @error('date_time')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="time_zone" class="required">Time Zone</label>
                                    <select class="form-control  @error('time_zone') is-invalid @enderror" id="time_zone"
                                        name="time_zone">
                                        <option value="UTC +3">UTC +3</option>
                                 
                                    </select>
                                    @error('time_zone')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                       
                        <div class="form-group text-center">
                            <input type="submit" id="submitBtn" class="btn btn-info btn-sm" value="Submit">
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

@endsection

@push('scripts')
<script>
    //SummerNote
$(function() {
    $('.summernote').summernote({
        height: 280,
    });

});
</script>
@endpush
