<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="{{ route('app.dashboard') }}" class="brand-link">
        <img src="{{ asset('/') }}img/AdminLTELogo.png" alt="Logo" class="brand-image img-circle elevation-3"
            style="opacity: .8">
        <span class="brand-text font-weight-light">Visit Lapland
        </span>
    </a>
    <!-- Sidebar -->
    <div class="sidebar px-0">

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                data-accordion="false">
                <li class="nav-item">
                    <a href="{{ route('app.dashboard') }}" class="nav-link {{ request()->is('/') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-home">
                        </i>
                        <p>Dashboard</p>
                    </a>
                </li>
                @if (Gate::allows('app.role.index') || Gate::allows('app.user.index'))
                <li class="nav-item {{ request()->is('role*') || request()->is('user*') ? 'menu-open' : '' }}">
                    <a href="#" class="nav-link {{ request()->is('role*') || request()->is('user*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-th-list"></i>
                        <p>
                            Administration
                            <i class="right fas fa-angle-left fa-sm"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        @permission('app.role.index')
                        <li class="nav-item">
                            <a href="{{ route('app.role.index') }}" class="nav-link {{ request()->is('role*') ? 'active' : '' }}">
                                <p>Role & Permissions</p>
                            </a>
                        </li>
                        @endpermission
                        @permission('app.user.index')
                        <li class="nav-item">
                            <a href="{{ route('app.user.index') }}" class="nav-link {{ request()->is('user*') ? 'active' : '' }}">
                                <p>Users</p>
                            </a>
                        </li>
                        @endpermission
                    </ul>
                </li>
                @endif
                {{-- @if (Gate::allows('app.blog.index') || Gate::allows('app.user.index')) --}}
                <li class="nav-item {{ request()->is('blog*') || request()->is('blog.category*') ? 'menu-open' : '' }}">
                    <a href="#" class="nav-link {{ request()->is('blog*') || request()->is('blog.category*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-th-list"></i>
                        <p>
                            Blogs Management
                            <i class="right fas fa-angle-left fa-sm"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        @permission('app.role.index')
                        <li class="nav-item">
                            <a href="{{ route('app.blog.index') }}" class="nav-link {{ request()->is('blog*') ? 'active' : '' }}">
                                <p>Blogs</p>
                            </a>
                        </li>
                        @endpermission
                        @permission('app.user.index')
                        <li class="nav-item">
                            <a href="{{ route('app.blog.category.index') }}" class="nav-link  {{ request()->is('blog.category*') ? 'active' : '' }}">
                                <p>Blog Categories</p>
                            </a>
                        </li>
                        @endpermission
                    </ul>
                </li>
                {{-- @endif --}}

                {{-- @if (Gate::allows('app.blog.index') || Gate::allows('app.user.index')) --}}
                <li class="nav-item {{ request()->is('tour*') || request()->is('tour*') || request()->is('faq*') || request()->is('time-slot*')|| request()->is('tour-include*') ? 'menu-open'  : '' }}">
                    <a href="#" class="nav-link {{ request()->is('tour*') || request()->is('tour.category*') || request()->is('faq*') || request()->is('time-slot*')|| request()->is('tour-include*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-th-list"></i>
                        <p>
                            Tour Management
                            <i class="right fas fa-angle-left fa-sm"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        @permission('app.role.index')
                        <li class="nav-item">
                            <a href="{{ route('app.tour.index') }}" class="nav-link {{ request()->is('tour*') ? 'active' : '' }}">
                                <p>Tours</p>
                            </a>
                        </li>
                        @endpermission
                        @permission('app.user.index')
                        <li class="nav-item">
                            <a href="{{ route('app.tour.category.index') }}" class="nav-link  {{ request()->is('tour*') ? 'active' : '' }}">
                                <p>Tour Categories</p>
                            </a>
                        </li>
                        @endpermission
                        @permission('app.user.index')
                        <li class="nav-item">
                            <a href="{{ route('app.faq.index') }}" class="nav-link  {{ request()->is('faq*') ? 'active' : '' }}">
                                <p>Faqs</p>
                            </a>
                        </li>
                        @endpermission
                        @permission('app.user.index')
                        <li class="nav-item">
                            <a href="{{ route('app.time-slot.index') }}" class="nav-link  {{ request()->is('time-slot*') ? 'active' : '' }}">
                                <p>Time Slots</p>
                            </a>
                        </li>
                        @endpermission
                        @permission('app.user.index')
                        <li class="nav-item">
                            <a href="{{ route('app.tour-include.index') }}" class="nav-link  {{ request()->is('tour-include*') ? 'active' : '' }}">
                                <p>Tour Includes</p>
                            </a>
                        </li>
                        @endpermission
                    </ul>
                </li>
                {{-- @endif --}}

                    {{-- @if (Gate::allows('app.blog.index') || Gate::allows('app.user.index')) --}}
                    <li class="nav-item {{ request()->is('app.payment*') || request()->is('app.payment*') ? 'menu-open' : '' }}">
                        <a href="#" class="nav-link {{ request()->is('app.payment*') || request()->is('app.payment*') ? 'active' : '' }}">
                            <i class="nav-icon fas fa-th-list"></i>
                            <p>
                                Payment Management
                                <i class="right fas fa-angle-left fa-sm"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            @permission('app.role.index')
                            <li class="nav-item">
                                <a href="{{ route('app.payment.index') }}" class="nav-link {{ request()->is('app.payment*') ? 'active' : '' }}">
                                    <p>Payments</p>
                                </a>
                            </li>
                            @endpermission 
                        </ul>
                    </li>
                    {{-- @endif --}}

                          {{-- @if (Gate::allows('app.blog.index') || Gate::allows('app.user.index')) --}}
                          <li class="nav-item {{ request()->is('app.booking*') || request()->is('app.booking*') ? 'menu-open' : '' }}">
                            <a href="#" class="nav-link {{ request()->is('app.booking*') || request()->is('app.booking*') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-th-list"></i>
                                <p>
                                    Bookings
                                    <i class="right fas fa-angle-left fa-sm"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                                @permission('app.role.index')
                                <li class="nav-item">
                                    <a href="{{ route('app.booking.index') }}" class="nav-link {{ request()->is('app.booking*') ? 'active' : '' }}">
                                        <p>All Bookings</p>
                                    </a>
                                </li>
                                @endpermission 
                            </ul>
                        </li>
                        {{-- @endif --}}

                          {{-- @if (Gate::allows('app.blog.index') || Gate::allows('app.user.index')) --}}
                          <li class="nav-item {{ request()->routeIs('app.setting.index') ? 'menu-open' : '' }}">
                            <a href="#" class="nav-link {{ request()->routeIs('app.setting.index') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-th-list"></i>
                                <p>
                                    Settings
                                    <i class="right fas fa-angle-left fa-sm"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                                @permission('app.role.index')
                                <li class="nav-item">
                                    <a href="{{ route('app.setting.index') }}" class="nav-link {{ request()->routeIs('app.setting.index') ? 'active' : '' }}">
                                        <p>All Settings</p>
                                    </a>
                                </li>
                                @endpermission 
                            </ul>
                        </li>
                        
                        {{-- @endif --}}
                        
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
