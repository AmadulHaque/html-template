<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Log in | Admin</title>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="{{ asset('/') }}css/adminlte.css">
    <style>
        /* checkbox */
        .form-checkbox input {
            padding: 0;
            height: initial;
            width: initial;
            margin-bottom: 0;
            display: none;
            cursor: pointer;
        }

        .form-checkbox label {
            position: relative;
            cursor: pointer;
        }

        .form-checkbox label:before {
            content:'';
            -webkit-appearance: none;
            background-color: transparent;
            border: 2px solid #1abc9c;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05), inset 0px -15px 10px -12px rgba(0, 0, 0, 0.05);
            padding: 6px;
            display: inline-block;
            position: relative;
            vertical-align: middle;
            cursor: pointer;
            margin-right: 5px;
        }

        .form-checkbox input:checked + label:after {
            content: '';
            display: block;
            position: absolute;
            top: 6px;
            left: 6px;
            width: 6px;
            height: 12px;
            border: solid #1abc9c;
            border-width: 0 2px 2px 0;
            transform: rotate(45deg);
        }
    </style>
</head>

<body class="hold-transition login-page">
    <div class="login-box">
        <div class="login-logo">
            <a href="../../index2.html"><b>Login</b></a>
        </div>
        <!-- /.login-logo -->
        <div class="card">
            <div class="card-body login-card-body">
                @yield('content')
            </div>
            <!-- /.login-card-body -->
        </div>
    </div>
    <!-- /.login-box -->

    <!-- jQuery -->
    <script src="{{ asset('/') }}js/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="{{ asset('/') }}js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>
    <script src="{{ asset('/') }}js/adminlte.min.js"></script>
    <script>
        // toastr alert message
        function notification(status, message){
            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "500",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }

            switch (status) {
                case 'success':
                toastr.success(message);
                break;

                case 'error':
                toastr.error(message);
                break;

                case 'warning':
                toastr.warning(message);
                break;

                case 'info':
                toastr.info(message);
                break;
            }
        }

        // session flash message
        @if (Session::get('success'))
            notification('success',"{{ Session::get('success') }}")
        @elseif (Session::get('error'))
            notification('error',"{{ Session::get('error') }}")
        @elseif (Session::get('info'))
            notification('info',"{{ Session::get('info') }}")
        @elseif (Session::get('warning'))
            notification('warning',"{{ Session::get('warning') }}")
        @endif
    </script>
</body>

</html>
