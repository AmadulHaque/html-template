<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('site_title') | Starter Template</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css">
    <!-- IonIcons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    {{-- Toastr --}}
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    {{-- Datatable --}}
    <link href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/1.0.3/css/dataTables.responsive.css">
    {{-- daterangepicker --}}
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
    {{-- Summer Note --}}
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
    {{-- Select 2 --}}
    <link href="https://rawgit.com/select2/select2/4.0.6/dist/css/select2.min.css" rel="stylesheet">  
    <!-- Theme style -->
    <link rel="stylesheet" href="{{ asset('/') }}css/adminlte.css">
    <link rel="stylesheet" href="{{ asset('/') }}css/custom.css">
    @stack('styles')
</head>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Navbar -->
        @include('include.header')
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        @include('include.sidebar')

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <!-- /.col -->
                        <div class="col-sm-12">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="{{ url('/') }}">Dashboard</a></li>
                                @isset($breadcrumb)
                                    @foreach ($breadcrumb as $title=>$url)
                                    <li class="breadcrumb-item {{ $loop->last ? '' : 'active' }}">@if ($loop->last){{ $title }}@else <a href="{{ $url }}">{{ $title }}</a>@endif</li>
                                    @endforeach
                                @endisset
                            </ol>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->
            <!-- Main content -->
            <div class="content">
                <div class="container-fluid">
                    @yield('content')
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <!-- Main Footer -->
        @include('include.footer')
        <!-- ./wrapper -->
    </div>

    <!-- jQuery -->
    <script src="{{ asset('/') }}js/jquery.min.js"></script>
    <script src="{{ asset('/') }}js/bootstrap.bundle.min.js"></script>
    <script src="{{ asset('/') }}js/adminlte.min.js"></script>
    <script src="{{ asset('/') }}js/Chart.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    {{-- Toastr --}}
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>
    {{-- Daterange --}}
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    {{-- Datatables --}}
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/1.0.3/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.colVis.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
    <script src="https://rawgit.com/select2/select2/4.0.5/dist/js/select2.full.min.js"></script>
    <script src="{{ asset('/') }}js/dashboard.js"></script>
    <script src="{{ asset('/') }}js/custom.js"></script>
    <script>
        // ajax header setup
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        // token
        var _token = "{{ csrf_token() }}";
        var table;

        // toastr alert message
        function notification(status, message){
            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "500",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }

            switch (status) {
                case 'success':
                toastr.success(message);
                break;

                case 'error':
                toastr.error(message);
                break;

                case 'warning':
                toastr.warning(message);
                break;

                case 'info':
                toastr.info(message);
                break;
            }
        }

        $(document).ready(function(){
            // session flash message
            @if (Session::get('success'))
                notification('success',"{{ Session::get('success') }}")
            @elseif (Session::get('error'))
                notification('error',"{{ Session::get('error') }}")
            @elseif (Session::get('info'))
                notification('info',"{{ Session::get('info') }}")
            @elseif (Session::get('warning'))
                notification('warning',"{{ Session::get('warning') }}")
            @endif

            // tooltip
            $('[data-toggle="tooltip"]').tooltip();

            // datatable reload
            $(document).on('click', 'button.table-reload', function(){
                table.ajax.reload();
            });

            // reset btn
            $(document).on('click','.reset_btn',function(){
                $('form#store_or_update_form').find('.schedule-error').remove();
                $('#store_or_update_form select').selectpicker('val','');
                $('form#store_or_update_form')[0].reset();
            });

            // search table
            $(document).on('keyup keypress', 'input[name="search_here"]', function(){
                table.ajax.reload();
            });
        });

          //Select2
          $(document).ready(function() {
            $('.select2').select2();
        });

    </script>
    @stack('scripts')
</body>

</html>
