@extends('layouts.app')
@section('site_title', $site_title)
@section('content')
    @push('styles')
        <style>
            input[type="file"] {
                display: block;
            }

            .imageThumb {
                max-height: 75px;
                border: 2px solid;
                padding: 1px;
                cursor: pointer;
            }

            .pip {
                display: inline-block;
                margin: 10px 10px 0 0;
            }

            .remove {
                display: block;
                background: #444;
                border: 1px solid black;
                color: white;
                text-align: center;
                cursor: pointer;
            }

            .remove:hover {
                background: white;
                color: black;
            }
        </style>
    @endpush
    <div class="row">
        <div class="col-md-12">
            <div class="card">

                <div class="card-body">
                    <form id="store_or_update_form" action="{{ route('app.blog.category.store') }}" method="POST"
                        enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="update_id" id="update_id">
                        <div class="form-group">
                            <label for="title" class="required">Title</label>
                            <input type="text" class="form-control @error('title') is-invalid @enderror" id="title"
                                name="title" value="{{ old('title') }}">
                            @error('title')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="meta_title" class="required">Meta Title</label>
                            <input type="text" class="form-control @error('meta_title') is-invalid @enderror"
                                id="meta_title" name="meta_title" value="{{ old('meta_title') }}">
                            @error('meta_title')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="meta_description"  class="required">Meta Description</label>
                            <textarea class="form-control @error('meta_description') is-invalid @enderror" id="meta_description"
                                name="meta_description">{{ old('meta_description') }}</textarea>
                            @error('meta_description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="image" class="required">Image</label>
                            <input type="file" class="form-control-file @error('image') is-invalid @enderror"
                                id="image" name="image">
                            <small class="form-text text-muted">(Max Size 5MB)</small>
                            @error('image')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group text-center">
                            <input type="submit" id="submitBtn" class="btn btn-info btn-sm" value="Submit">
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

@endsection

@push('scripts')
    <script src="{{ asset('/') }}js/spartan-multi-image-picker-min.js"></script>
    <script>
        //Banner Image
        $(document).ready(function() {
            if (window.File && window.FileList && window.FileReader) {
                $("#image").on("change", function(e) {
                    var files = e.target.files,
                        filesLength = files.length;

                    var maxFileSize = 5120;
                    var maxFileLimit = 2;
                    for (var i = 0; i < filesLength; i++) {
                        var f = files[i];
                        var fileSize = f.size / 1024;
                        if (fileSize > maxFileSize) {
                            $(this).val('');
                            alert("File size exceeds the limit of 5MB.");
                            continue;
                        }

                        if (filesLength >= maxFileLimit) {
                            $(this).val('');
                            alert("You can only upload a maximum of 1 file.");
                            break;
                        }

                        var fileReader = new FileReader();
                        fileReader.onload = (function(e) {
                            var file = e.target;
                            $("<span class=\"pip\">" +
                                "<img class=\"imageThumb\" src=\"" + e.target.result +
                                "\" title=\"" + file.name + "\"/>" +
                                "<br/><span class=\"remove\">Remove image</span>" +
                                "</span>").insertAfter("#image");
                            $(".remove").click(function() {
                                $(this).parent(".pip").remove();
                            });
                        });
                        fileReader.readAsDataURL(f);
                    }
                    console.log(files);
                });
            } else {
                alert("Your browser doesn't support to File API")
            }
        });
    </script>
@endpush
