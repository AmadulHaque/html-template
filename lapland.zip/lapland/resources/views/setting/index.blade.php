@extends('layouts.app')
@section('site_title', $site_title)
@section('content')
    @push('styles')
        <style>
            input[type="file"] {
                display: block;
            }

            .imageThumb {
                max-height: 75px;
                border: 2px solid;
                padding: 1px;
                cursor: pointer;
            }

            .pip {
                display: inline-block;
                margin: 10px 10px 0 0;
            }

            .remove {
                display: block;
                background: #444;
                border: 1px solid black;
                color: white;
                text-align: center;
                cursor: pointer;
            }

            .remove:hover {
                background: white;
                color: black;
            }
        </style>
    @endpush
    <div class="row">
        <div class="col-md-12">
            <div class="card">

                <div class="card-body">
                    <form action="{{ route('app.setting.update') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="date_format">Date Format:</label>
                                    <input type="text" name="date_format" id="date_format" class="form-control"
                                        value="{{ old('date_format', $settings->where('key', 'date_format')->first()->value) }}">
                                    @error('date_format')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="datetime_format">Datetime Format:</label>
                                    <input type="text" name="datetime_format" id="datetime_format" class="form-control"
                                        value="{{ old('datetime_format', $settings->where('key', 'datetime_format')->first()->value) }}">
                                    @error('datetime_format')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="currency_icon">Currency Icon:</label>
                                    <input type="text" name="currency_icon" id="currency_icon" class="form-control"
                                        value="{{ old('currency_icon', $settings->where('key', 'currency_icon')->first()->value) }}">
                                    @error('currency_icon')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                          
                            

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="site_title">Site Title:</label>
                                    <input type="text" name="site_title" id="site_title" class="form-control"
                                        value="{{ old('site_title', $settings->where('key', 'site_title')->first()->value) }}">
                                    @error('site_title')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="site_description">Site Description:</label>
                                    <textarea name="site_description" id="site_description" class="form-control" rows="4">{{ old('site_description', $settings->where('key', 'site_description')->first()->value) }}</textarea>
                                    @error('site_description')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="site_logo">Site Logo</label>
                                    <input type="file" class="form-control @error('site_logo') is-invalid @enderror" id="site_logo" name="site_logo">
                                    <small class="form-text text-muted">(Max Size 5MB)</small>
                                    @error('site_logo')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                
                                    <div id="image_preview">
                                        @if (!empty($settings->where('key', 'site_logo')->first()->value))
                                            <img class="preview-image" style="width: 80px"
                                                src="{{ uploaded_asset($settings->where('key', 'site_logo')->first()->value) }}"
                                                data-id="" title="undefined">
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="site_favicon">Favicon</label>
                                    <input type="file" class="form-control @error('site_favicon') is-invalid @enderror" id="site_favicon" name="site_favicon">
                                    <small class="form-text text-muted">(Max Size 5MB)</small>
                                    @error('site_favicon')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                
                                    <div id="fav_image_preview">
                                        @if (!empty($settings->where('key', 'site_favicon')->first()->value))
                                            <img class="fav-preview-image" style="width: 80px"
                                                src="{{ uploaded_asset($settings->where('key', 'site_favicon')->first()->value) }}"
                                                data-id="" title="undefined">
                                        @endif
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="home_page_video">Home Page Video:</label>
                                    <input type="text" name="home_page_video" id="home_page_video" class="form-control"
                                        value="{{ old('home_page_video', $settings->where('key', 'home_page_video')->first()->value) }}">
                                    @error('home_page_video')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-12 mx-2 my-2">
                                <div class="row">
                                    <div class="col-md-4 border border-info">
                                        <div class="form-group">
                                            <label for="tab1_title">Tab 1 Title:</label>
                                            <input type="text" name="tab1_title" id="tab1_title" class="form-control"
                                                value="{{ old('tab1_title', $settings->where('key', 'tab1_title')->first()->value) }}">
                                            @error('tab1_title')
                                                <div class="text-danger">{{ $message }}</div>
                                            @enderror
                                        </div>
                                        <div class="form-group">
                                            <label for="tab1_tours" class="required">Tab 1 Tours</label>
                                            <select class="form-control select2 @error('tab1_tours') is-invalid @enderror" id="tab1_tours" name="tab1_tours[]" multiple>
                                                @php
                                                    $defaultTours = json_decode($settings->where('key', 'tab1_tours')->first()->value, true) ?? [];
                                                @endphp
                                                @foreach ($tours as $tour)
                                                    <option value="{{ $tour->id }}" {{ in_array($tour->id, old('tab1_tours', $defaultTours)) ? 'selected' : '' }}>
                                                        {{ trimString($tour->title, 30) }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('tab1_tours')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                        
                                    </div>

                                    <div class="col-md-4 border border-info">
                                        <div class="form-group">
                                            <label for="tab1_title">Tab 2 Title:</label>
                                            <input type="text" name="tab2_title" id="tab2_title" class="form-control"
                                                value="{{ old('tab2_title', $settings->where('key', 'tab2_title')->first()->value) }}">
                                            @error('tab2_title')
                                                <div class="text-danger">{{ $message }}</div>
                                            @enderror
                                        </div>
                                        <div class="form-group">
                                            <label for="tab2_tours" class="required">Tab 2 Tours</label>
                                            <select class="form-control select2 @error('tab2_tours') is-invalid @enderror" id="tab2_tours" name="tab2_tours[]" multiple>
                                                @php
                                                    $defaultTours = json_decode($settings->where('key', 'tab2_tours')->first()->value, true) ?? [];
                                                @endphp
                                                @foreach ($tours as $tour)
                                                    <option value="{{ $tour->id }}" {{ in_array($tour->id, old('tab2_tours', $defaultTours)) ? 'selected' : '' }}>
                                                        {{ trimString($tour->title, 30) }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('tab2_tours')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="col-md-4 border border-info">
                                        <div class="form-group">
                                            <label for="tab1_title">Tab 3 Title:</label>
                                            <input type="text" name="tab3_title" id="tab3_title" class="form-control"
                                                value="{{ old('tab3_title', $settings->where('key', 'tab3_title')->first()->value) }}">
                                            @error('tab3_title')
                                                <div class="text-danger">{{ $message }}</div>
                                            @enderror
                                        </div>
                                        <div class="form-group">
                                            <label for="tab3_tours" class="required">Tab 3 Tours</label>
                                            <select class="form-control select2 @error('tab3_tours') is-invalid @enderror" id="tab3_tours" name="tab3_tours[]" multiple>
                                                @php
                                                    $defaultTours = json_decode($settings->where('key', 'tab3_tours')->first()->value, true) ?? [];
                                                @endphp
                                                @foreach ($tours as $tour)
                                                    <option value="{{ $tour->id }}" {{ in_array($tour->id, old('tab3_tours', $defaultTours)) ? 'selected' : '' }}>
                                                        {{ trimString($tour->title, 30) }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('tab3_tours')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                </div>
                            </div>
                         
                            <div class="col-md-12">
                                <br>
                                <div class="form-group">
                                    <label for="feature_tours" class="required">Feature Tours</label>
                                    <select class="form-control select2 @error('feature_tours') is-invalid @enderror" id="feature_tours" name="feature_tours[]" multiple>
                                        @php
                                            $defaultTours = json_decode($settings->where('key', 'feature_tours')->first()->value, true) ?? [];
                                        @endphp
                                        @foreach ($tours as $tour)
                                            <option value="{{ $tour->id }}" {{ in_array($tour->id, old('feature_tours', $defaultTours)) ? 'selected' : '' }}>
                                                {{ trimString($tour->title, 30) }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('feature_tours')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                        </div>
                </div>
                <div class="row mx-2">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="social_media_facebook">Facebook:</label>
                            <input type="text" name="social_media_facebook" id="social_media_facebook"
                                class="form-control"
                                value="{{ old('social_media_facebook', $settings->where('key', 'social_media_facebook')->first()->value) }}">
                            @error('social_media_facebook')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="social_media_instagram">Instagram:</label>
                            <input type="text" name="social_media_instagram" id="social_media_instagram"
                                class="form-control"
                                value="{{ old('social_media_instagram', $settings->where('key', 'social_media_instagram')->first()->value) }}">
                            @error('social_media_instagram')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="social_media_twitter">Twitter:</label>
                            <input type="text" name="social_media_twitter" id="social_media_twitter" class="form-control"
                                value="{{ old('social_media_twitter', $settings->where('key', 'social_media_twitter')->first()->value) }}">
                            @error('social_media_twitter')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="social_media_youtube">YouTube:</label>
                            <input type="text" name="social_media_youtube" id="social_media_youtube"
                                class="form-control"
                                value="{{ old('social_media_youtube', $settings->where('key', 'social_media_youtube')->first()->value) }}">
                            @error('social_media_youtube')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="social_media_pinterest">Pinterest:</label>
                            <input type="text" name="social_media_pinterest" id="social_media_pinterest"
                                class="form-control"
                                value="{{ old('social_media_pinterest', $settings->where('key', 'social_media_pinterest')->first()->value) }}">
                            @error('social_media_pinterest')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                </div>




                <div class="row m-2">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="mail_host">Mail Host:</label>
                            <input type="text" name="mail_host" id="mail_host" class="form-control"
                                value="{{ old('mail_host', $settings->where('key', 'mail_host')->first()->value) }}">
                            @error('mail_host')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="mail_port">Mail Port:</label>
                            <input type="text" name="mail_port" id="mail_port" class="form-control"
                                value="{{ old('mail_port', $settings->where('key', 'mail_port')->first()->value) }}">
                            @error('mail_port')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="mail_from_address">Mail From Address:</label>
                            <input type="text" name="mail_from_address" id="mail_from_address" class="form-control"
                                value="{{ old('mail_from_address', $settings->where('key', 'mail_from_address')->first()->value) }}">
                            @error('mail_from_address')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="mail_from_name">Mail From Name:</label>
                            <input type="text" name="mail_from_name" id="mail_from_name" class="form-control"
                                value="{{ old('mail_from_name', $settings->where('key', 'mail_from_name')->first()->value) }}">
                            @error('mail_from_name')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="mail_encryption">Mail Encryption:</label>
                            <input type="text" name="mail_encryption" id="mail_encryption" class="form-control"
                                value="{{ old('mail_encryption', $settings->where('key', 'mail_encryption')->first()->value) }}">
                            @error('mail_encryption')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="mail_username">Mail Username:</label>
                            <input type="text" name="mail_username" id="mail_username" class="form-control"
                                value="{{ old('mail_username', $settings->where('key', 'mail_username')->first()->value) }}">
                            @error('mail_username')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="mail_password">Mail Password:</label>
                            <input type="password" name="mail_password" id="mail_password" class="form-control"
                                value="{{ old('mail_password', $settings->where('key', 'mail_password')->first()->value) }}">
                            @error('mail_password')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>


                 <div class="text-center">
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Update Settings</button>
                    </div>
                 </div>
                </form>

            </div>
        </div>
    </div>
    </div>

@endsection

@push('scripts')
    <script src="{{ asset('/') }}js/spartan-multi-image-picker-min.js"></script>
    <script>
     
        $(document).ready(function() {
    if (window.File && window.FileList && window.FileReader) {
        $("#site_logo").on("change", function(e) {
            var files = e.target.files,
                filesLength = files.length;

            var maxFileSize = 5120;
            var maxFileLimit = 2;

            // Remove the existing image preview
            $("#image_preview").html("");

            for (var i = 0; i < filesLength; i++) {
                var f = files[i];
                var fileSize = f.size / 1024;
                if (fileSize > maxFileSize) {
                    $(this).val('');
                    alert("File size exceeds the limit of 5MB.");
                    continue;
                }

                if (filesLength >= maxFileLimit) {
                    $(this).val('');
                    alert("You can only upload a maximum of 1 file.");
                    break;
                }

                var fileReader = new FileReader();
                fileReader.onload = (function(e) {
                    var file = e.target;
                    $("<span class=\"pip\">" +
                        "<img class=\"imageThumb\" src=\"" + e.target.result +
                        "\" title=\"" + file.name + "\"/>" +
                        "<br/><span class=\"remove\">Remove image</span>" +
                        "</span>").insertAfter("#site_logo");
                    $(".remove").click(function() {
                        $(this).parent(".pip").remove();
                    });
                });
                fileReader.readAsDataURL(f);
            }
            console.log(files);
        });
    } else {
        alert("Your browser doesn't support the File API");
    }



    if (window.File && window.FileList && window.FileReader) {
        $("#site_favicon").on("change", function(e) {
            var files = e.target.files,
                filesLength = files.length;

            var maxFileSize = 5120;
            var maxFileLimit = 2;

            // Remove the existing image preview
            $("#fav_image_preview").html("");

            for (var i = 0; i < filesLength; i++) {
                var f = files[i];
                var fileSize = f.size / 1024;
                if (fileSize > maxFileSize) {
                    $(this).val('');
                    alert("File size exceeds the limit of 5MB.");
                    continue;
                }

                if (filesLength >= maxFileLimit) {
                    $(this).val('');
                    alert("You can only upload a maximum of 1 file.");
                    break;
                }

                var fileReader = new FileReader();
                fileReader.onload = (function(e) {
                    var file = e.target;
                    $("<span class=\"pip\">" +
                        "<img class=\"imageThumb\" src=\"" + e.target.result +
                        "\" title=\"" + file.name + "\"/>" +
                        "<br/><span class=\"remove\">Remove image</span>" +
                        "</span>").insertAfter("#site_favicon");
                    $(".remove").click(function() {
                        $(this).parent(".pip").remove();
                    });
                });
                fileReader.readAsDataURL(f);
            }
            console.log(files);
        });
    } else {
        alert("Your browser doesn't support the File API");
    }

});

    </script>
@endpush
