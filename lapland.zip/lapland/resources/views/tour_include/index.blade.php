@extends('layouts.app')
@section('site_title', $site_title)
@section('content')
    @push('styles')
  
    @endpush
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header py-2">
                    <h4 class="mb-0 cd-title d-flex align-items-center justify-content-between">{{ $title }}
                        @permission('app.user.create')
                            <a href="{{route('app.tour-include.create')}}" class="btn btn-sm btn-primary rounded-0"><i class="fas fa-plus fa-sm"></i> Add Tour Include</a>
                        @endpermission
                    </h4>
                </div>
                <div class="card-body">
                    <table class="table table-borderless w-100 table-sm table-hover table-striped" id="blog-datatable">
                        <thead>
                            @permission('app.user.bulk-delete')
                                <th>
                                    <div class="form-checkbox">
                                        <input type="checkbox" class="form-check-input" id="select_all" onclick="select_all()">
                                        <label class="form-check-label" for="select_all"></label>
                                    </div>
                                </th>
                            @endpermission
                            <th>SL</th>
                            <th>Title</th>
                            <th>Status</th>
                            <th>Created at</th>
                            @if (Gate::allows('app.user.view') || Gate::allows('app.user.edit') || Gate::allows('app.user.delete'))
                                <th>Action</th>
                            @endif
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script src="{{ asset('/') }}js/spartan-multi-image-picker-min.js"></script>
    <script>
        table = $('#blog-datatable').DataTable({
            processing: true,
            serverSide: true,
            responsive: true,
            order: [], //Initial no order
            bInfo: true, //TO show the total number of data
            bFilter: false, //For datatable default search box show/hide
            ordering: false,
            lengthMenu: [
                [5, 10, 15, 25, 50, 100, -1],
                [5, 10, 15, 25, 50, 100, "All"]
            ],
            pageLength: 10, //number of data show per page
            ajax: {
                url: "{{ route('app.tour-include.index') }}",
                type: "GET",
                dataType: "JSON",
                data: function(d) {
                    d._token = _token;
                    d.search = $('input[name="search_here"]').val();
                },
            },
            columns: [
                @permission('app.user.bulk-delete')
                    {
                        data: 'bulk_check'
                    },
                @endpermission {
                    data: 'DT_RowIndex'
                },
                {
                    data: 'title'
                },
                {
                    data: 'status'
                },
                {
                    data: 'created_at'
                },
                @if (Gate::allows('app.user.view') || Gate::allows('app.user.edit') || Gate::allows('app.user.delete'))
                    {
                        data: 'action'
                    },
                @endpermission
            ],
            language: {
                processing: '<img src="{{ asset('img/table-loading.svg') }}">',
                emptyTable: '<strong class="text-danger">No Data Found</strong>',
                infoEmpty: '',
                zeroRecords: '<strong class="text-danger">No Data Found</strong>',
                oPaginate: {
                    sPrevious: "Previous", // This is the link to the previous page
                    sNext: "Next", // This is the link to the next page
                },
                lengthMenu: `<div class='d-flex align-items-center w-100 justify-content-between'>_MENU_
                        <button type='button' style='min-width: 110px;' class='btn btn-sm btn-danger d-none rounded-0 delete_btn ml-2 px-3' onclick='multi_delete()'>Bulk Delete</button>

                        <input name='search_here' class='form-control-s ml-2' placeholder="Search Here" autocomplete="off"/>
                    </div>`,
            }
        });






        @permission('app.user.bulk-delete')
            // multi delete
            function multi_delete() {
                let ids = [];
                let rows;
                $('.select_data:checked').each(function() {
                    ids.push($(this).val());
                    rows = table.rows($('.select_data:checked').parents('tr'));
                });

                if (ids.length == 0) {
                    Swal.fire({
                        type: 'error',
                        title: 'Error',
                        text: 'Please checked at least one row of table!',
                        icon: 'warning',
                    });
                } else {
                    let url = "{{ route('app.user.bulk.delete') }}";
                    bulk_delete(ids, url, rows);
                }
            }
        @endpermission

        $('#image').spartanMultiImagePicker({
            fieldName: 'image[]',
            maxCount: 5,
            rowHeight: '150px',
            groupClassName: 'col-md-12 com-sm-12 com-xs-12 px-0',
            maxFileSize: '',
            dropFileLabel: 'Drop Here',
            allowExt: 'png|jpg|jpeg',
            onExtensionErr: function(index, file) {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Only png,jpg,jpeg file format allowed!'
                });
            }
        });

        $('input[name="image"]').prop('required', true);
        $('input[name="image[]"]').prop('multiple', true);
        $('.remove-files').on('click', function() {
            $(this).parents('.col-md-12').remove();
        });

        // status changes
        $(document).on('click', '.change_status', function() {
            var id = $(this).data('id');
            var name = $(this).data('name');
            var status = $(this).data('status');
            var url = "{{ route('app.tour-include.status.change') }}"
            change_status(id, status, name, url);
        });

    </script>
@endpush
