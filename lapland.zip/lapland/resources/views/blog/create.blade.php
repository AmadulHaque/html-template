@extends('layouts.app')
@section('site_title', $site_title)
@section('content')
    @push('styles')
        <style>
            input[type="file"] {
                display: block;
            }

            .imageThumb {
                max-height: 75px;
                border: 2px solid;
                padding: 1px;
                cursor: pointer;
            }

            .pip {
                display: inline-block;
                margin: 10px 10px 0 0;
            }

            .remove {
                display: block;
                background: #444;
                border: 1px solid black;
                color: white;
                text-align: center;
                cursor: pointer;
            }

            .remove:hover {
                background: white;
                color: black;
            }
        </style>
    @endpush
    <div class="row">
        <div class="col-md-12">
            <div class="card">

                <div class="card-body">
                    <form id="store_or_update_form" action="{{ route('app.blog.store') }}" method="POST"
                        enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="update_id" id="update_id">
                        <div class="form-group">
                            <label for="title" class="required">Title</label>
                            <input type="text" class="form-control @error('title') is-invalid @enderror" id="title"
                                name="title" value="{{ old('title') }}">
                            @error('title')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="description" class="required">Description</label>
                            <textarea class="form-control summernote @error('description') is-invalid @enderror" id="description"
                                name="description">{{ old('description') }}</textarea>
                            @error('description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="description">Winter</label>
                            <textarea class="form-control summernote @error('winter') is-invalid @enderror" id="winter" name="winter">{{ old('winter') }}</textarea>
                            @error('winter')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="description">Kids</label>
                            <textarea class="form-control summernote @error('kids') is-invalid @enderror" id="kids" name="kids">{{ old('kids') }}</textarea>
                            @error('kids')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="description">Pets</label>
                            <textarea class="form-control summernote @error('pets') is-invalid @enderror" id="pets" name="pets">{{ old('pets') }}</textarea>
                            @error('pets')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="description">Summer</label>
                            <textarea class="form-control summernote @error('summer') is-invalid @enderror" id="summer" name="summer">{{ old('summer') }}</textarea>
                            @error('summer')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="category_id" class="required">Category Name</label>
                            <select class="form-control select2 @error('category_id') is-invalid @enderror" id="category_id"
                                name="category_id">
                                <option value="">Select a Category</option>
                                @foreach ($categories as $category)
                                    <option value="{{ $category->id }}" @if ($category->id == old('category_id')) selected @endif>
                                        {{ $category->title }}</option>
                                @endforeach
                            </select>
                            @error('category_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        {{-- <div class="form-group">
                            <label for="relevant_tour" class="required">Relevant Tours</label>
                            <select class="form-control select2 @error('relevant_tour') is-invalid @enderror"
                                id="relevant_tour" name="relevant_tour" multiple>
                                <option value="">Select Tours</option>
                                @foreach ($categories as $category)
                                    <option value="{{ $category->id }}" @if ($category->id == old('relevant_tour')) selected @endif>
                                        {{ $category->title }}</option>
                                @endforeach
                            </select>
                            @error('relevant_tour')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div> --}}
                        <div class="form-group">
                            <label for="meta_title" class="required">Meta Title</label>
                            <input type="text" class="form-control @error('meta_title') is-invalid @enderror"
                                id="meta_title" name="meta_title" value="{{ old('meta_title') }}">
                            @error('meta_title')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="meta_description">Meta Description</label>
                            <textarea class="form-control @error('meta_description') is-invalid @enderror" id="meta_description"
                                name="meta_description">{{ old('meta_description') }}</textarea>
                            @error('meta_description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="thumbnails" class="required">Thumbnail Images</label>
                            <input type="file" class="form-control-file @error('thumbnails') is-invalid @enderror"
                                id="thumbnails" name="thumbnails[]" multiple>
                            <small class="form-text text-muted">(Max 10 images, Max Size Per file: 5MB)</small>
                            @error('thumbnails')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="banner_image" class="required">Banner Image</label>
                            <input type="file" class="form-control-file @error('banner_image') is-invalid @enderror"
                                id="banner_image" name="banner_image">
                            <small class="form-text text-muted">(Max Size 5MB)</small>
                            @error('banner_image')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="video" class="">Thumbnail Video</label>
                            <input type="file" class="form-control-file @error('video') is-invalid @enderror"
                                id="video" name="video">
                            <small class="form-text text-muted">(Max Size 10MB)</small>
                            @error('video')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <video id="video-preview" controls style="display: none; max-width: 50%;"></video>
                        </div>
                        <div class="form-group text-center">
                            <input type="submit" id="submitBtn" class="btn btn-info btn-sm" value="Submit">
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

@endsection

@push('scripts')
    <script src="{{ asset('/') }}js/spartan-multi-image-picker-min.js"></script>
    <script>
        //Thumbnail Images
        $(document).ready(function() {
            if (window.File && window.FileList && window.FileReader) {
                $("#thumbnails").on("change", function(e) {
                    var files = e.target.files,
                        filesLength = files.length;

                    var maxFileSize = 5120;
                    var maxFileLimit = 10;
                    for (var i = 0; i < filesLength; i++) {
                        var f = files[i];
                        var fileSize = f.size / 1024;
                        if (fileSize > maxFileSize) {
                            $(this).val('');
                            alert("File size exceeds the limit of 5MB.");
                            continue;
                        }

                        if (filesLength >= maxFileLimit) {
                            $(this).val('');
                            alert("You can only upload a maximum of 10 files.");
                            break;
                        }

                        var fileReader = new FileReader();
                        fileReader.onload = (function(e) {
                            var file = e.target;
                            $("<span class=\"pip\">" +
                                "<img class=\"imageThumb\" src=\"" + e.target.result +
                                "\" title=\"" + file.name + "\"/>" +
                                "<br/><span class=\"remove\">Remove image</span>" +
                                "</span>").insertAfter("#thumbnails");
                            $(".remove").click(function() {
                                $(this).parent(".pip").remove();
                            });
                        });
                        fileReader.readAsDataURL(f);
                    }
                    console.log(files);
                });
            } else {
                alert("Your browser doesn't support to File API")
            }
        });

        //Banner Image
        $(document).ready(function() {
            if (window.File && window.FileList && window.FileReader) {
                $("#banner_image").on("change", function(e) {
                    var files = e.target.files,
                        filesLength = files.length;

                    var maxFileSize = 5120;
                    var maxFileLimit = 2;
                    for (var i = 0; i < filesLength; i++) {
                        var f = files[i];
                        var fileSize = f.size / 1024;
                        if (fileSize > maxFileSize) {
                            $(this).val('');
                            alert("File size exceeds the limit of 5MB.");
                            continue;
                        }

                        if (filesLength >= maxFileLimit) {
                            $(this).val('');
                            alert("You can only upload a maximum of 1 file.");
                            break;
                        }

                        var fileReader = new FileReader();
                        fileReader.onload = (function(e) {
                            var file = e.target;
                            $("<span class=\"pip\">" +
                                "<img class=\"imageThumb\" src=\"" + e.target.result +
                                "\" title=\"" + file.name + "\"/>" +
                                "<br/><span class=\"remove\">Remove image</span>" +
                                "</span>").insertAfter("#banner_image");
                            $(".remove").click(function() {
                                $(this).parent(".pip").remove();
                            });
                        });
                        fileReader.readAsDataURL(f);
                    }
                    console.log(files);
                });
            } else {
                alert("Your browser doesn't support to File API")
            }
        });

        //Thumbnail Video

        $(document).ready(function() {
            if (window.File && window.FileList && window.FileReader) {
                $("#video").on("change", function(e) {
                    var video = e.target.files[0];

                    // Set maximum file size in bytes (10MB)
                    var maxFileSize = 10 * 1024 * 1024;

                    if (video) {
                        var fileSize = video.size;

                        if (fileSize > maxFileSize) {
                            alert("Video size exceeds the limit of 10MB.");
                            $(this).val('');
                            return;
                        }

                        var videoType = video.type.split('/')[0]; // Get the video type (e.g., "video")

                        if (videoType !== 'video') {
                            alert("Please select a valid video file.");
                            $(this).val('');
                            return;
                        }

                        var videoURL = URL.createObjectURL(video);
                        $("#video-preview").attr("src", videoURL).show();
                    }
                });
            } else {
                alert("Your browser doesn't support the File API");
            }
        });

        //Search Reloevant Tours
        const $searchSelect = $('#searchSelect');

        $searchSelect.select2({
            placeholder: 'Search',
            minimumInputLength: 2,
            ajax: {
                url: 'url',
                dataType: 'json',
                delay: 250,
                data: function(params) {
                    return {
                        query: params.term
                    };
                },
                processResults: function(data) {
                    return {
                        results: data.map(item => ({
                            id: item.id,
                            text: item.value
                        }))
                    };
                }
            }
        });

        $searchSelect.on('select2:open', function() {
            $searchSelect.select2('close');
        });

        $searchSelect.on('select2:select', function(e) {
            const selectedData = e.params.data;
            console.log('Selected ID:', selectedData.id);
            console.log('Selected Text:', selectedData.text);
        });

        //SummerNote
        $(function() {
            $('.summernote').summernote({
                height: 280,
            });

        });

        //Select2
        $(document).ready(function() {
            $('.select2').select2();
        });
    </script>
@endpush
