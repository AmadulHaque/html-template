<div id="store_or_update_modal" class="modal fade show" role="dialog">
    <div class="modal-dialog modal-lg va-center" role="document">
        <div class="modal-content">
            <div class="modal-header py-2">
                <h5 class="modal-title" ></h5>
                <button type="button" class="close shadow-none" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body">
                <form id="store_or_update_form" method="POST">
                    @csrf
                    <input type="hidden" name="update_id" id="update_id">
                    <x-form.inputbox name="title" labelName="Title" required="required"/>
                    <x-form.textarea  labelName="Description" class="" name="description" required="required"/>
                    <x-form.selectbox name="category_name" labelName="Category Name" class="select2" required="required">
                        <option value="">Select a Category</option>
                        @foreach ($categories as $category)
                            <option value="{{ $category->id }}">{{ $category->title  }}</option>
                        @endforeach
                    </x-form.selectbox>
                    <x-form.inputbox name="meta_title" labelName="Meta Title" required="required"/>
                    <x-form.inputbox name="meta_description" labelName="Meta Description" required="required"/>

                    <div class="form-group">
                        <label for="image" class="required">Thumbnail Images</label>
                        <div class="px-0 text-center">
                            <div id="image" class="row">

                            </div>
                        </div>
                        <input type="hidden" name="old_image" id="old_image">
                    </div>
                </form>
            </div>
            <div class="modal-footer pt-0 border-0">
                <button type="button" class="btn btn-sm btn-danger rounded-0" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-sm btn-primary rounded-0" id="save-btn"></button>
            </div>
        </div>
    </div>
</div>
