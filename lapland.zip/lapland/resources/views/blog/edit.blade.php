@extends('layouts.app')
@section('site_title', $site_title)
@section('content')
    @push('styles')
        <style>
            input[type="file"] {
                display: block;
            }

            .imageThumb {
                max-height: 75px;
                border: 2px solid;
                padding: 1px;
                cursor: pointer;
            }

            .pip {
                display: inline-block;
                margin: 10px 10px 0 0;
            }

            .remove {
                display: block;
                background: #444;
                border: 1px solid black;
                color: white;
                text-align: center;
                cursor: pointer;
            }

            .remove:hover {
                background: white;
                color: black;
            }
        </style>
    @endpush
    <div class="row">
        <div class="col-md-12">
            <div class="card">

                <div class="card-body">
                    <form id="edit_form" action="{{ route('app.blog.update', $blog->id) }}" method="POST"
                        enctype="multipart/form-data">
                        @csrf

                        <div class="form-group">
                            <label for="title" class="required">Title</label>
                            <input type="text" class="form-control @error('title') is-invalid @enderror" id="title"
                                name="title" value="{{ old('title', $blog->title) }}">
                            @error('title')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="description" class="required">Description</label>
                            <textarea class="form-control @error('description') is-invalid @enderror" id="description" name="description">{{ old('description', $blog->description) }}</textarea>
                            @error('description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="winter" class="required">Winter</label>
                            <textarea class="form-control @error('winter') is-invalid @enderror" id="winter" name="winter">{{ old('winter', $blog->winter) }}</textarea>
                            @error('winter')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="kids" class="required">Kids</label>
                            <textarea class="form-control @error('kids') is-invalid @enderror" id="kids" name="kids">{{ old('kids', $blog->kids) }}</textarea>
                            @error('kids')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="pets" class="required">Pets</label>
                            <textarea class="form-control @error('pets') is-invalid @enderror" id="pets" name="pets">{{ old('pets', $blog->pets) }}</textarea>
                            @error('pets')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="summer" class="required">Summer</label>
                            <textarea class="form-control @error('summer') is-invalid @enderror" id="summer" name="summer">{{ old('summer', $blog->summer) }}</textarea>
                            @error('summer')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="category_id" class="required">Category Name</label>
                            <select class="form-control select2 @error('category_id') is-invalid @enderror" id="category_id"
                                name="category_id">
                                <option value="">Select a Category</option>
                                @foreach ($categories as $category)
                                    <option value="{{ $category->id }}" @if ($category->id == old('category_id', $blog->category_id)) selected @endif>
                                        {{ $category->title }}</option>
                                @endforeach
                            </select>
                            @error('category_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="meta_title" class="required">Meta Title</label>
                            <input type="text" class="form-control @error('meta_title') is-invalid @enderror"
                                id="meta_title" name="meta_title" value="{{ old('meta_title', $blog->meta_title) }}">
                            @error('meta_title')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="meta_description">Meta Description</label>
                            <textarea class="form-control @error('meta_description') is-invalid @enderror" id="meta_description"
                                name="meta_description">{{ old('meta_description', $blog->meta_description) }}</textarea>
                            @error('meta_description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="thumbnails" class="required">Thumbnail Images</label>
                            <input type="file" class="form-control-file @error('thumbnails') is-invalid @enderror"
                                id="thumbnails" name="thumbnails[]" multiple>
                            <small class="form-text text-muted">(Max 10 images, Max Size Per file: 5MB)</small>
                            @error('thumbnails')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            @if (!empty($blog->thumbnail_image))
                                <div class="mt-3">
                                    @forelse (json_decode($blog->thumbnail_image) as $thumbnail)
                                        <span class="pip">
                                            <img class="imageThumb" src="{{ uploaded_asset($thumbnail) }}"
                                                data-id="{{ $thumbnail }}" title="undefined">
                                            <br>
                                            <span class="remove" id="remove">Remove image</span>
                                        </span>
                                    @empty
                                    @endforelse
                                    <span class="latestImage"></span>
                                </div>
                            @endif
                        </div>

                        @if (!empty($blog->thumbnail_image))
                            @foreach (json_decode($blog->thumbnail_image) as $thumbnail)
                                <input type="hidden" name="existing_thumbnails[]" value="{{ $thumbnail }}"
                                    data-id="{{ $thumbnail }}">
                            @endforeach
                        @endif
                        <hr>
                        <div class="form-group">
                            <label for="banner_image" class="required">Banner Image</label>
                            <input type="file" class="form-control-file @error('banner_image') is-invalid @enderror"
                                id="banner_image" name="banner_image">
                            <small class="form-text text-muted">(Max Size 5MB)</small>
                            @error('banner_image')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            @if (!empty($blog->banner_image))
                                <div class="mt-3">
                                    <div id="banner_image_preview">
                                        <span class="pip">
                                            <img class="imageThumb" style="width: 80px"
                                                src="{{ uploaded_asset($blog->banner_image) }}" data-id=""
                                                title="undefined">

                                        </span>
                                    </div>

                                </div>
                            @endif
                        </div>
                        <hr>

                        <div class="form-group">
                            <label for="video" class="required">Thumbnail Video</label>
                            <input type="file" class="form-control-file @error('video') is-invalid @enderror"
                                id="video" name="video">
                            <small class="form-text text-muted">(Max Size 10MB)</small>
                            @error('video')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            @if (!empty($blog->thumbnail_video))
                                <div class="mt-3" id="video-preview">
                                    <video controls style="width: 280px">
                                        <source src="{{ uploaded_asset($blog->thumbnail_video) }}" type="video/mp4">
                                        Your browser does not support the video tag.
                                    </video>
                                </div>
                            @endif
                        </div>

                        <div class="form-group text-center">
                            <input type="submit" id="submitBtn" class="btn btn-info btn-sm" value="Update">
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

@endsection

@push('scripts')
    <script src="{{ asset('/') }}js/spartan-multi-image-picker-min.js"></script>
    <script>
        //Thumbnail Images
        $(document).ready(function() {
            $(".remove").click(function() {
                var thumbnailToRemove = $(this).parent(".pip").find(".imageThumb").data('id');
                console.log(thumbnailToRemove);
                $("input[name='existing_thumbnails[]'][data-id='" + thumbnailToRemove + "']").remove();

                $(this).parent(".pip").remove();
            });
            if (window.File && window.FileList && window.FileReader) {
                $("#thumbnails").on("change", function(e) {
                    var files = e.target.files,
                        filesLength = files.length;
                    var maxFileSize = 5120;
                    var maxFileLimit = 10;
                    for (var i = 0; i < filesLength; i++) {
                        var f = files[i];
                        var fileSize = f.size / 1024;
                        if (fileSize > maxFileSize) {
                            $(this).val('');
                            alert("File size exceeds the limit of 5MB.");
                            continue;
                        }

                        if (filesLength >= maxFileLimit) {
                            $(this).val('');
                            alert("You can only upload a maximum of 10 files.");
                            break;
                        }

                        var fileReader = new FileReader();
                        fileReader.onload = (function(e) {
                            var file = e.target;
                            $("<span class=\"pip\">" +
                                "<img class=\"imageThumb\" src=\"" + e.target.result +
                                "\" title=\"" + file.name + "\"/>" +
                                "<br/><span class=\"remove\">Remove image</span>" +
                                "</span>").insertAfter(".latestImage");
                            $(".remove").click(function() {
                                var thumbnailToRemove = $(this).data('thumbnail');
                                $("input[name='existing_thumbnails[]'][value='" +
                                    thumbnailToRemove + "']").remove();
                                $(this).parent(".pip").remove();
                            });
                        });
                        fileReader.readAsDataURL(f);
                    }
                    console.log(files);
                });
            } else {
                alert("Your browser doesn't support to File API")
            }
        });

        //Banner Image
        $(document).ready(function() {
            if (window.File && window.FileList && window.FileReader) {
                $("#banner_image").on("change", function(e) {
                    var files = e.target.files,
                        filesLength = files.length;

                    var maxFileSize = 5120;
                    var maxFileLimit = 2;
                    for (var i = 0; i < filesLength; i++) {
                        var f = files[i];
                        var fileSize = f.size / 1024;
                        if (fileSize > maxFileSize) {
                            $(this).val('');
                            alert("File size exceeds the limit of 5MB.");
                            continue;
                        }

                        if (filesLength >= maxFileLimit) {
                            $(this).val('');
                            alert("You can only upload a maximum of 1 file.");
                            break;
                        }

                        var fileReader = new FileReader();
                        fileReader.onload = (function(e) {
                            var file = e.target;
                            $("#banner_image_preview").html("");
                            $("#banner_image_preview").html(
                                "<img class=\"imageThumb\" src=\"" + e.target.result +
                                "\" title=\"" + file.name + "\"/>"
                            );
                        });
                        fileReader.readAsDataURL(f);
                    }
                    console.log(files);
                });
            } else {
                alert("Your browser doesn't support to File API")
            }
        });

        //Thumbnail Video

        $(document).ready(function() {
            if (window.File && window.FileList && window.FileReader) {
                $("#video").on("change", function(e) {
                    var video = e.target.files[0];

                    // Set maximum file size in bytes (10MB)
                    var maxFileSize = 10 * 1024 * 1024;

                    if (video) {
                        var fileSize = video.size;

                        if (fileSize > maxFileSize) {
                            alert("Video size exceeds the limit of 10MB.");
                            $(this).val('');
                            return;
                        }

                        var videoType = video.type.split('/')[0];

                        if (videoType !== 'video') {
                            alert("Please select a valid video file.");
                            $(this).val('');
                            return;
                        }

                        var videoURL = URL.createObjectURL(video);
                        $("#video-preview").html(`<video controls style="width: 280px">
                    <source src="${videoURL}" type="video/mp4">
                    Your browser does not support the video tag.
                </video>`).show();
                    }
                });
            } else {
                alert("Your browser doesn't support the File API");
            }
        });

        //SummerNote
        $(function() {
            $('#description').summernote({
                height: 280,
            });

        });
        //Select2
        $(document).ready(function() {
            $('#category_name').select2();
        });
    </script>
@endpush
