@extends('layouts.app')
@section('site_title', $site_title)
@section('content')
    @push('styles')
    @endpush
    @php
        // dd($booking->bookingDetails->tours);
    @endphp

    <div class="row">
        <div class="col-12">
            {{-- <div class="callout callout-info">
            <h5><i class="fas fa-info"></i> Note:</h5>
            This page has been enhanced for printing. Click the print button at the bottom of the invoice to test.
          </div> --}}

            <!-- Main content -->
            <div class="invoice p-3 mb-3 print">
                <!-- title row -->
                <div class="row">
                    <div class="col-12">
                        <h4>
                            <i class="fas fa-globe"></i> {{ env('APP_NAME') }}
                            <small class="float-right">Date: {{ $booking->created_at }}</small>
                        </h4>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- info row -->
                <div class="row invoice-info">
                    <div class="col-sm-4 invoice-col">
                        From
                        <address>
                            <strong>{{ env('APP_NAME') }}</strong><br>
                            795 Folsom Ave, Suite 600<br>
                            San Francisco, CA 94107<br>
                            Phone: (804) 123-5432<br>
                            Email: info@lapland.com
                        </address>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-4 invoice-col">
                        To
                        <address>
                            <strong>{{ $booking->bookedBy->name }}</strong><br>
                            {{ $booking->bookedBy->address }}<br>
                            Phone: {{ $booking->bookedBy->mobile_no }}<br>
                            Email: {{ $booking->bookedBy->email }}
                        </address>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-4 invoice-col">
                        {{-- <b>Invoice #007612</b><br>
                        <br> --}}
                        <b>Booking Number:</b> {{ $booking->booking_number }}<br>
                        <b>Booked Due:</b> 2/22/2014<br>

                        @if ($booking->payment_status == 1)
                            <b>Payment Status:</b> PAID <br>
                            @if ($booking->successfulPayment && $booking->successfulPayment->type == 'card')
                            @else
                                <b>Account:</b> {{ $booking->successfulPayment->account_number ?? null }}
                            @endif
                        @else
                            <b>Payment Status:</b> UNPAID <br>
                        @endif
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->

                <!-- Table row -->
                <div class="row">
                    <div class="col-12 table-responsive">
                        <table class=" table-striped table-bordered w-100">
                            <thead>
                                <tr>
                                    <th>Serial</th>
                                    <th>Tour</th>
                                    <th>Date</th>
                                    <th>Details</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $grandTotal = 0;
                                @endphp
                                @foreach ($booking->bookingDetails as $key => $details)
                                    <tr>
                                        <td>{{ $key + 1 }}</td>
                                        <td>{{ $details->tour->title }}</td>
                                        @if ($details->tour->end_date_time)
                                            <td class="small">
                                                {{ $details->tour->start_date_time }}
                                                <br>
                                                to
                                                <br>
                                                {{ $details->tour->end_date_time }}
                                            </td>
                                        @else
                                            <td class="small">
                                                {{ $details->tour->start_date_time }}
                                            </td>
                                        @endif
                                        <td class="small p-1">
                                            Adult: {{ $details->adult_quantity }} x
                                            {{ config('settings.currency_icon') . $details->per_adult_price }} =
                                            {{ config('settings.currency_icon') . calculateSubtotal($details->adult_quantity, $details->per_adult_price) }}<br>
                                            Child: {{ $details->child_quantity }} x
                                            {{ config('settings.currency_icon') . $details->per_child_price }} =
                                            {{ config('settings.currency_icon') . calculateSubtotal($details->child_quantity, $details->per_child_price) }}<br>
                                            Infant: {{ $details->infant_quantity }} x
                                            {{ config('settings.currency_icon') . $details->per_infant_price }} =
                                            {{ config('settings.currency_icon') . calculateSubtotal($details->infant_quantity, $details->per_infant_price) }}<br>
                                            Pet: {{ $details->pet_quantity }} x
                                            {{ config('settings.currency_icon') . $details->per_pet_price }} =
                                            {{ config('settings.currency_icon') . calculateSubtotal($details->pet_quantity, $details->per_pet_price) }}<br>
                                        </td>
                                        <td class="small text-center">
                                            @php
                                                
                                                $grandTotal += calculateTotalPrice($details);
                                            @endphp
                                            {{ config('settings.currency_icon') . calculateTotalPrice($details) }}
                                        </td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->

                <div class="row">
                    <!-- accepted bookings column -->
                    <div class="col-9">
                        {{-- <p class="lead">booking Methods:</p>
                        <img src="../../dist/img/credit/visa.png" alt="Visa">
                        <img src="../../dist/img/credit/mastercard.png" alt="Mastercard">
                        <img src="../../dist/img/credit/american-express.png" alt="American Express">
                        <img src="../../dist/img/credit/paypal2.png" alt="Paypal">

                        <p class="text-muted well well-sm shadow-none" style="margin-top: 10px;">
                            Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles, weebly ning heekya handango
                            imeem
                            plugg
                            dopplr jibjab, movity jajah plickers sifteo edmodo ifttt zimbra.
                        </p> --}}
                    </div>
                    <!-- /.col -->
                    <div class="col-3">
                        {{-- <p class="lead">Amount Due 2/22/2014</p> --}}

                        <div class="table-responsive">
                            <table class="table">
                                <tr>
                                    <th style="width:100%">Subtotal:</th>
                                    <td>
                                        {{ config('settings.currency_icon') . $grandTotal }}

                                    </td>
                                </tr>
                                {{-- <tr>
                                    <th>Tax (15%)</th>
                                    <td>$0.00</td>
                                </tr> --}}
                                <tr>
                                    <th>Total:</th>
                                    <td>
                                        {{ config('settings.currency_icon') . $grandTotal }}
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->

                <!-- this row will not appear when printing -->
                <div class="row no-print">
                    <div class="col-12">
                        <button id="printButton"><i class="fas fa-print"></i> Print</button>
                        {{-- <a href="invoice-print.html" rel="noopener" target="_blank" class="btn btn-default"> Print</a> --}}
                        {{-- <button type="button" class="btn btn-success float-right"><i class="far fa-credit-card"></i> Submit
                            booking
                        </button>
                        <button type="button" class="btn btn-primary float-right" style="margin-right: 5px;">
                            <i class="fas fa-download"></i> Generate PDF
                        </button> --}}
                    </div>
                </div>
            </div>
            <!-- /.invoice -->
        </div><!-- /.col -->
    </div><!-- /.row -->
@endsection

@push('scripts')
    <script src="{{ asset('/') }}js/spartan-multi-image-picker-min.js"></script>
    <script>
        $('#printButton').click(function() {
            window.print();
            return false;
        });
    </script>
@endpush
