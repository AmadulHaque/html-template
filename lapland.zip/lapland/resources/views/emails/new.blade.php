<div style="padding: 3px; margin-bottom: 3px;" class="invoice print">
    <!-- title row -->
    <div style="display: flex; flex-direction: row; align-items: center;">
        <div style="flex: 1;">
            <h4 style="margin: 0; padding: 0;">
                <i style="margin-right: 5px;" class="fas fa-globe"></i> {{ env('APP_NAME') }}
                <small style="float: right;">Date: {{ $booking->created_at }}</small>
            </h4>
        </div>
    </div>
    <!-- info row -->
    <div style="display: flex; flex-direction: row;">
        <div style="flex: 1;">
            <p>From</p>
            <address>
                <strong>{{ env('APP_NAME') }}</strong><br>
                795 Folsom Ave, Suite 600<br>
                San Francisco, CA 94107<br>
                Phone: (804) 123-5432<br>
                Email: info@lapland.com
            </address>
        </div>
        <div style="flex: 1;">
            <p>To</p>
            <address>
                <strong>{{ $booking->bookedBy->name }}</strong><br>
                {{ $booking->bookedBy->address }}<br>
                Phone: {{ $booking->bookedBy->mobile_no }}<br>
                Email: {{ $booking->bookedBy->email }}
            </address>
        </div>
        <div style="flex: 1;">
            <p><b>Booking Number:</b> {{ $booking->booking_number }}</p>
            <p><b>Booked Due:</b> 2/22/2014</p>
            @if ($booking->payment_status == 1)
                <p><b>Payment Status:</b> PAID</p>
                @if ($booking->successfulPayment && $booking->successfulPayment->type == 'card')
                @else
                    <p><b>Account:</b> {{ $booking->successfulPayment->account_number ?? null }}</p>
                @endif
            @else
                <p><b>Payment Status:</b> UNPAID</p>
            @endif
        </div>
    </div>
    <!-- Table row -->
    <div style="display: flex; flex-direction: row;">
        <div style="flex: 1;">
            <table style="width: 100%;">
                <thead>
                    <tr>
                        <th>Serial</th>
                        <th>Tour</th>
                        <th>Date</th>
                        <th>Details</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $grandTotal = 0;
                    @endphp
                    @foreach ($booking->bookingDetails as $key => $details)
                        <tr>
                            <td>{{ $key + 1 }}</td>
                            <td>{{ $details->tour->title }}</td>
                            @if ($details->tour->end_date_time)
                                <td class="small">
                                    {{ $details->tour->start_date_time }}
                                    <br>
                                    to
                                    <br>
                                    {{ $details->tour->end_date_time }}
                                </td>
                            @else
                                <td class="small">
                                    {{ $details->tour->start_date_time }}
                                </td>
                            @endif
                            <td class="small" style="padding: 1px;">
                                Adult: {{ $details->adult_quantity }} x
                                {{ config('settings.currency_icon') . $details->per_adult_price }} =
                                {{ config('settings.currency_icon') . calculateSubtotal($details->adult_quantity, $details->per_adult_price) }}<br>
                                Child: {{ $details->child_quantity }} x
                                {{ config('settings.currency_icon') . $details->per_child_price }} =
                                {{ config('settings.currency_icon') . calculateSubtotal($details->child_quantity, $details->per_child_price) }}<br>
                                Infant: {{ $details->infant_quantity }} x
                                {{ config('settings.currency_icon') . $details->per_infant_price }} =
                                {{ config('settings.currency_icon') . calculateSubtotal($details->infant_quantity, $details->per_infant_price) }}<br>
                                Pet: {{ $details->pet_quantity }} x
                                {{ config('settings.currency_icon') . $details->per_pet_price }} =
                                {{ config('settings.currency_icon') . calculateSubtotal($details->pet_quantity, $details->per_pet_price) }}<br>
                            </td>
                            <td class="small text-center">
                                @php
                                    $grandTotal += calculateTotalPrice($details);
                                @endphp
                                {{ config('settings.currency_icon') . calculateTotalPrice($details) }}
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    <div style="display: flex; flex-direction: row;">
        <div style="flex: 1;">
        </div>
        <div style="flex: 1;">
            <div style="width: 100%;">
                <table style="width: 100%;">
                    <tr>
                        <th style="width: 100%;">Subtotal:</th>
                        <td>
                            {{ config('settings.currency_icon') . $grandTotal }}
                        </td>
                    </tr>
                    <tr>
                        <th>Total:</th>
                        <td>
                            {{ config('settings.currency_icon') . $grandTotal }}
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <!-- this row will not appear when printing -->
    <div style="display: flex; flex-direction: row;">
        <div style="flex: 1;">
        </div>
        <div style="flex: 1;">
            <button id="printButton" style="border: none; background-color: transparent;"><i class="fas fa-print"></i> Print</button>
        </div>
    </div>
</div>
