@extends('frontend.master')
@section('main_content')
            <!-- Banner Start -->
            <div class="banner-area py-40">
                <div class="container-xl">
                    <div class="row">
                        <div class="col-12">
                        <h3>Latest Tours of: {{$category->title}}</h3>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Banner End -->
    
            <!-- Popular Area Start -->
            <section class="popular-area">
    
            </section>
            <!-- Popular Area End -->
    
            <!-- Tour Area Start -->
            <section class="tour-area py-40">
                <div class="container-xl">
                    <div class="row g-4">
                        @forelse ($tours as $tour)
                        {{-- <a  href="{{route('tour.show',$tour->slug)}}" target="_blank"> --}}
                        <div class="col-md-4">
                            <div class="tour-slider-row owl-carousel">
                                @foreach (json_decode($tour->thumbnail_images) as $thumbnail)
                                <div class="tour-slider-box">
                                    <img src="{{uploaded_asset($thumbnail)}}" alt="">
                                </div>   
                                @endforeach

                            </div>
                            <div class="tour-content">
                                <span>{{$tour->tour_location}}</span>
                                <a  href="{{route('tour.show',$tour->slug)}}" target="_blank">
                                    <h2>{{$tour->title}}</h2>
                                </a>
                                <p><strong><i class="fas fa-euro-sign"></i> {{$tour->tour_base_price}}</strong> {{$tour->default_adult_quantity + $tour->default_children_quantity + $tour->default_infant_quantity}} persons</p>
                            </div>
                        </div>
                    {{-- </a> --}}
                    @empty
                    <h4>No Auction Found</h4>
                        @endforelse
                        
          
                    </div>
                </div>
            </section>
            <!-- Tour Area End -->
    
@endsection