<div class="main-navbar">
    <div class="row">
        <div class="col-12">
            <nav>
                <ul class="d-flex">
                    <li>
                        <a href="{{route('home')}}">
                            <img src="{{uploaded_asset(config('settings.site_logo'))}}" alt="">
                            <span>All</span>
                        </a>
                    </li>
                    @foreach ($tourCategories as $tourCategory)
                    <li>
                        <a href="{{route('tour.category.show',$tourCategory->slug)}}">
                            <img src="{{uploaded_asset($tourCategory->image)}}" alt="">
                            <span>{{$tourCategory->title}}</span>
                        </a>
                    </li> 
                    @endforeach
                   
                   
                </ul>
            </nav>
        </div>
    </div>
</div>