<div class="header-top" style="color: red">
    <div class="row" >
        <div class="col-md-6">
            <div class="header-left d-flex align-items-center">
                <button type="button" class="menu-bar-btn"><i class="fas fa-ellipsis-v"></i></button>
                <div class="logo-area">
                    <img src="{{asset('frontend')}}/assets/img/logo/logo.png" alt="logo">
                </div>
                <div class="action-btn">
                    <a href="" class="book-btn active">Book</a>
                    <a href="" class="inspiration-btn">Inspiration</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="travel-plan-btn text-end">
                @auth
                <a href="" class="plan-btn">
                    <img src="{{asset('frontend')}}/assets/img/icon/add-to-basket.png" class="mr-2" alt="">
                    <span>Travel Plan</span>
                    <span class="btn-badge-circle rounded-circle primary-bg text-light">2</span> 
                </a>
               <span class="text-dark">
                | Welcome {{auth()->user()->name}} |
               </span>
                    <a href="{{ route('logout') }}" onclick="event.preventDefault();document.getElementById('logout-form').submit();" >
                        <i class="fas fa-sign-out-alt mr-1 text-secondary fa-sm"></i> Logout
                    </a>
                <form id="logout-form" action="{{ route('logout') }}" class="d-none" method="POST">
                    @csrf
                </form>
                   @else
                   <div class="action-btn">
                    <a href="{{route('login')}}" class="book-btn active">Login</a>
                </div> 
                @endauth
                
              
            </div>
        </div>
    </div>
</div>