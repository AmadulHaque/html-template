<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- Title -->
    <title>Travel</title>
    <link rel="icon" type="image/x-icon" href="{{uploaded_asset(config('settings.site_favicon')) ?? null}}">

    <!-- Fontawesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <!-- Owl Carousel -->
    <link rel="stylesheet" href="{{ asset('frontend') }}/assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="{{ asset('frontend') }}/assets/css/owl.theme.default.min.css">
    <!-- stylesheet -->
    <link rel="stylesheet" href="{{ asset('frontend') }}/assets/css/style.css">
    <link rel="stylesheet" href="{{ asset('frontend') }}/assets/css/responsive.css">
    @yield('extra_css')
</head>

<body>

    <!-- Header Start -->
    <header>
        <div class="container-xl">
            <!-- Header Top -->
            @include('frontend.include.header')

            <!-- Navbar -->
            @include('frontend.include.navbar')
        </div>
    </header>
    <!-- Header End -->

    <!-- Main Content Start -->
    <main>
        @yield('main_content')
    </main>
    <!-- Main Content End -->

    <!-- Footer Start -->
    <footer>
        <div class="container-xl">
            <div class="row">
                <div class="col-12">
                    <div class="footer-top">
                        <div class="row">
                            <div class="col-md-8 col-12 mx-auto">

                            </div>
                        </div>
                    </div>
                    <div class="copyright">
                        <div class="row">
                            <div class="col-md-6">

                            </div>
                            <div class="col-md-6">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer End -->

    <!--Jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Owl Carousel -->
    <script src="{{ asset('frontend') }}/assets/js/owl.carousel.min.js"></script>
    <!-- Main JS -->
    <script src="{{ asset('frontend') }}/assets/js/main.js"></script>
    @yield('extra_js')
</body>

</html>
