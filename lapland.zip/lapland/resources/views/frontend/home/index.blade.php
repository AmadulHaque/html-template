@extends('frontend.master')
@section('main_content')
            <!-- Banner Start -->
            <div class="banner-area py-40">
                <div class="container-xl">
                    <div class="row">
                        <div class="col-12">
                            <div class="banner position-relative h-100">
                                <div class="content text-center position-absolute top-50 start-50 translate-middle">
                                    <h5>All & everything about the Lapland</h5>
                                    <button><img src="{{asset('frontend')}}/assets/img/icon/location.svg" alt=""> Where to Travel?</button>
                                </div>
                                <div class="video-content">
                                    <video width="100%" height="100%" src="{{config('settings.home_page_video')}}" autoplay loop muted></video>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Banner End -->
    
            <!-- Popular Area Start -->
            <section class="popular-area">
    
            </section>
            <!-- Popular Area End -->
    
            <!-- Tour Area Start -->
            <section class="tour-area py-40">
                <div class="container-xl">
                    <div class="row g-4">
                        @foreach ($latestTours as $latestTour)
                        {{-- <a  href="{{route('tour.show',$latestTour->slug)}}" target="_blank"> --}}
                        <div class="col-md-4">
                            <div class="tour-slider-row owl-carousel">
                                @foreach (json_decode($latestTour->thumbnail_images) as $thumbnail)
                                <div class="tour-slider-box">
                                    <img src="{{uploaded_asset($thumbnail)}}" alt="">
                                </div>   
                                @endforeach

                            </div>
                            <div class="tour-content">
                                <span>{{$latestTour->tour_location}}</span>
                                <a  href="{{route('tour.show',$latestTour->slug)}}" target="_blank">
                                    <h2>{{$latestTour->title}}</h2>
                                </a>
                                <p><strong><i class="fas fa-euro-sign"></i> {{$latestTour->tour_base_price}}</strong> {{$latestTour->default_adult_quantity + $latestTour->default_children_quantity + $latestTour->default_infant_quantity}} persons</p>
                            </div>
                        </div>
                    {{-- </a> --}}
                        @endforeach
                        
          
                    </div>
                </div>
            </section>
            <!-- Tour Area End -->
    
            <!-- Tour Tab Area Start -->
            <section class="tour-tab-area py-40">
                <div class="container-xl">
                    <div class="row">
                        <div class="col-12">
                            <div class="tour-tab-row p-3">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="tour-tab-slider owl-carousel">
                                            @forelse (json_decode(config('settings.feature_tours')) as $featureTourId)
                                            @php
                                                $featureTour= App\Tour::where('id',$featureTourId)->first();
                                                $thumbnails=json_decode($featureTour->thumbnail_images);
                                            @endphp
                                            <div class="tour-slider-box position-relative">
                                                <img src="{{uploaded_asset( $thumbnails[0])}}" alt="">
                                                <div class="tour-tab-content position-absolute">
                                                    <span>Rovaniemi</span>
                                                    <h2>{{$featureTour->title}}</h2>
                                                </div>
                                            </div>
                                            @empty
                                                No Tour Found
                                            @endforelse
                                            

                                        </div>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="tour-tab">
                                            <nav>
                                                <div class="nav nav-tabs border-0" id="nav-tab" role="tablist">
                                                  <button class="nav-link active" id="family-travel-tab" data-bs-toggle="tab" data-bs-target="#family-travel" type="button" role="tab" aria-controls="family-travel" aria-selected="true">{{config('settings.tab1_title')}}</button>
    
                                                  <button class="nav-link" id="treat-ourselve-tab" data-bs-toggle="tab" data-bs-target="#treat-ourselve" type="button" role="tab" aria-controls="treat-ourselve" aria-selected="false">{{config('settings.tab2_title')}}</button>
    
                                                  <button class="nav-link" id="go-adventure-tab" data-bs-toggle="tab" data-bs-target="#go-adventure" type="button" role="tab" aria-controls="go-adventure" aria-selected="false">{{config('settings.tab3_title')}}</button>
                                                </div>
                                              </nav>
                                              <div class="tab-content mt-4" id="nav-tabContent">
                                                <div class="tab-pane fade show active" id="family-travel" role="tabpanel" aria-labelledby="family-travel-tab" tabindex="0">
                                                    <div class="tour-tab-box p-3">
                                                        <div class="row g-3">
                                                            @forelse (json_decode(config('settings.tab1_tours')) as $tab1TourId )
                                                            @php
                                                                $tab1Tour= App\Tour::where('id',$tab1TourId)->first();
                                                                $thumbnails=json_decode($tab1Tour->thumbnail_images);
                                                            @endphp
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="{{uploaded_asset($thumbnails[0])}}" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>{{$tab1Tour->tour_location}}</span>
                                                                        <h2>{{$tab1Tour->title}}</h2>
                                                                        <p><strong>{{config('settings.currency_icon')}} {{$tab1Tour->tour_base_price}}</strong> {{$tab1Tour->default_adult_quantity + $tab1Tour->default_children_quantity + $tab1Tour->default_infant_quantity }} persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            @empty
                                                                No Tour Found
                                                            @endforelse
                                                            
                                                           
                                                        </div>
                                                    </div>
                                                </div>
    
                                                <div class="tab-pane fade" id="treat-ourselve" role="tabpanel" aria-labelledby="treat-ourselve-tab" tabindex="0">
                                                    <div class="tour-tab-box p-3">
                                                        <div class="row g-3">
                                                            @forelse (json_decode(config('settings.tab2_tours')) as $tab2TourId )
                                                            @php
                                                                $tab2Tour= App\Tour::where('id',$tab2TourId)->first();
                                                                $thumbnails=json_decode($tab2Tour->thumbnail_images);
                                                            @endphp
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="{{uploaded_asset($thumbnails[0])}}" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>{{$tab2Tour->tour_location}}</span>
                                                                        <h2>{{$tab2Tour->title}}</h2>
                                                                        <p><strong>{{config('settings.currency_icon')}} {{$tab2Tour->tour_base_price}}</strong> {{$tab2Tour->default_adult_quantity + $tab2Tour->default_children_quantity + $tab2Tour->default_infant_quantity }} persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            @empty
                                                                No Tour Found
                                                            @endforelse
                                                        </div>
                                                    </div>
                                                </div>
    
                                                <div class="tab-pane fade" id="go-adventure" role="tabpanel" aria-labelledby="go-adventure-tab" tabindex="0">
                                                    <div class="tour-tab-box p-3">
                                                        <div class="row g-3">
                                                            @forelse (json_decode(config('settings.tab3_tours')) as $tab3TourId )
                                                            @php
                                                                $tab3Tour= App\Tour::where('id',$tab3TourId)->first();
                                                                $thumbnails=json_decode($tab3Tour->thumbnail_images);
                                                            @endphp
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="{{uploaded_asset($thumbnails[0])}}" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>{{$tab3Tour->tour_location}}</span>
                                                                        <h2>{{$tab3Tour->title}}</h2>
                                                                        <p><strong>{{config('settings.currency_icon')}} {{$tab3Tour->tour_base_price}}</strong> {{$tab3Tour->default_adult_quantity + $tab3Tour->default_children_quantity + $tab3Tour->default_infant_quantity }} persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            @empty
                                                                No Tour Found
                                                            @endforelse
                                                        </div>
                                                    </div>
                                                </div>
                                              </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Tour Tab Area End -->
    
            <!-- Tour Area Start -->
            <section class="tour-area py-40">
                <div class="container-xl">
                    <div class="row g-4">
                        @foreach ($latestTours as $latestTour)
                        {{-- <a  href="{{route('tour.show',$latestTour->slug)}}" target="_blank"> --}}
                        <div class="col-md-4">
                            <div class="tour-slider-row owl-carousel">
                                @foreach (json_decode($latestTour->thumbnail_images) as $thumbnail)
                                <div class="tour-slider-box">
                                    <img src="{{uploaded_asset($thumbnail)}}" alt="">
                                </div>   
                                @endforeach

                            </div>
                            <div class="tour-content">
                                <span>{{$latestTour->tour_location}}</span>
                                <a  href="{{route('tour.show',$latestTour->slug)}}" target="_blank">
                                    <h2>{{$latestTour->title}}</h2>
                                </a>
                                <p><strong><i class="fas fa-euro-sign"></i> {{$latestTour->tour_base_price}}</strong> {{$latestTour->default_adult_quantity + $latestTour->default_children_quantity + $latestTour->default_infant_quantity}} persons</p>
                            </div>
                        </div>
                    {{-- </a> --}}
                        @endforeach
                    </div>
                </div>
            </section>
            <!-- Tour Area End -->
@endsection