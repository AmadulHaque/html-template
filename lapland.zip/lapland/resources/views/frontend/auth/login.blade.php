@extends('frontend.master')
@section('main_content')
<style>
    .container-bg {
        background-image: url('https://i2-prod.mirror.co.uk/incoming/article30349559.ece/ALTERNATES/s1200d/0_TUI-already-has-Lapland-2024-holidays-on-sale.jpg');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        height: 100vh;
    }
</style>
    {{-- Login form Start --}}
    <div class="container-xl mt-2">

        <div class="row justify-content-center align-items-center"  >
            <div class="col-md-6">
                <div class="card rounded-5  mt-3" style="border-radius: 1rem;" >
                    <div class="card-body bg-default" >
                        <p class="login-box-msg">Sign in to start your session</p>
                        <form action="{{ route('login') }}" method="post">
                            @csrf
                            <div class="input-group mb-3">
                                <input type="email" class="form-control @error('email') is-invalid @enderror" name="email"
                                    placeholder="Email" style="border-radius: 1rem;">
                                
                            </div>
                            @error('email')
                                <small class="text-danger d-block">{{ $message }}</small>
                            @enderror
                            <div class="input-group mb-3">
                                <input type="password" class="form-control @error('password') is-invalid @enderror" name="password"
                                    placeholder="Password" style="border-radius: 1rem;">
                               
                            </div>
                            @error('password')
                                <small class="text-danger d-block">{{ $message }}</small>
                            @enderror
                            <div class="row">
                                <div class="col-8">
                                    <div class="form-checkbox">
                                        <input type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
                                        <label for="remember" class="mb-0">
                                            Remember Me
                                        </label>
                                    </div>
                                </div>
                                <div class="col-12 text-center">
                                    <button type="submit" class="btn btn-primary  btn-block" style="border-radius: 2rem;">Sign In</button>
                                </div>
                            </div>
                        </form>
                        <p class="mb-1">
                            <a href="forgot-password.html">I forgot my password</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    {{-- Login form End --}}
@endsection
