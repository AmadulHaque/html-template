@extends('layouts.app')
@section('site_title', $site_title)
@section('content')
    @push('styles')
  
    @endpush
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header py-2">
                    <h4 class="mb-0 cd-title d-flex align-items-center justify-content-between">{{ $title }}
                        @permission('app.user.create')
                            <a href="{{route('app.tour.category.create')}}" class="btn btn-sm btn-primary rounded-0"><i class="fas fa-plus fa-sm"></i> Add Category</a>
                        @endpermission
                    </h4>
                </div>
                <div class="card-body">
                    <table class="table table-borderless w-100 table-sm table-hover table-striped" id="blog-datatable">
                        <thead>
                            @permission('app.user.bulk-delete')
                                <th>
                                    <div class="form-checkbox">
                                        <input type="checkbox" class="form-check-input" id="select_all" onclick="select_all()">
                                        <label class="form-check-label" for="select_all"></label>
                                    </div>
                                </th>
                            @endpermission
                            <th>SL</th>
                            <th>Title</th>
                            <th>Image</th>
                            <th>Status</th>
                            <th>Created by</th>
                            <th>Created at</th>
                            @if (Gate::allows('app.user.view') || Gate::allows('app.user.edit') || Gate::allows('app.user.delete'))
                                <th>Action</th>
                            @endif
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script src="{{ asset('/') }}js/spartan-multi-image-picker-min.js"></script>
    <script>
        table = $('#blog-datatable').DataTable({
            processing: true,
            serverSide: true,
            responsive: true,
            order: [], //Initial no order
            bInfo: true, //TO show the total number of data
            bFilter: false, //For datatable default search box show/hide
            ordering: false,
            lengthMenu: [
                [5, 10, 15, 25, 50, 100, -1],
                [5, 10, 15, 25, 50, 100, "All"]
            ],
            pageLength: 10, //number of data show per page
            ajax: {
                url: "{{ route('app.tour.category.index') }}",
                type: "GET",
                dataType: "JSON",
                data: function(d) {
                    d._token = _token;
                    d.search = $('input[name="search_here"]').val();
                },
            },
            columns: [
                @permission('app.user.bulk-delete')
                    {
                        data: 'bulk_check'
                    },
                @endpermission {
                    data: 'DT_RowIndex'
                },
                {
                    data: 'title'
                },
                {
                    data: 'image'
                },
                {
                    data: 'status'
                },
                {
                    data: 'created_by'
                },
                {
                    data: 'created_at'
                },
                @if (Gate::allows('app.user.view') || Gate::allows('app.user.edit') || Gate::allows('app.user.delete'))
                    {
                        data: 'action'
                    },
                @endpermission
            ],
            language: {
                processing: '<img src="{{ asset('img/table-loading.svg') }}">',
                emptyTable: '<strong class="text-danger">No Data Found</strong>',
                infoEmpty: '',
                zeroRecords: '<strong class="text-danger">No Data Found</strong>',
                oPaginate: {
                    sPrevious: "Previous", // This is the link to the previous page
                    sNext: "Next", // This is the link to the next page
                },
                lengthMenu: `<div class='d-flex align-items-center w-100 justify-content-between'>_MENU_
                        <button type='button' style='min-width: 110px;' class='btn btn-sm btn-danger d-none rounded-0 delete_btn ml-2 px-3' onclick='multi_delete()'>Bulk Delete</button>

                        <input name='search_here' class='form-control-s ml-2' placeholder="Blog Title, Description, Category, Created By Search Here" autocomplete="off"/>
                    </div>`,
            }
        });

        @permission('app.user.create')
            // user modal
            function showUserFormModal(modal_title, btn_text) {
                $('#store_or_update_form')[0].reset();
                $('#store_or_update_form #update_id').val('');
                $('#store_or_update_form').find('.is-invalid').removeClass('is-invalid');
                $('#store_or_update_form').find('.error').remove();
                $('#store_or_update_modal').modal({
                    keyboard: false,
                    backdrop: 'static',
                });
                $('#store_or_update_modal .modal-title').html(modal_title);
                $('#store_or_update_modal #save-btn').html('<span></span> ' + btn_text);
            }
        @endpermission

        @if (Gate::allows('app.user.create') || Gate::allows('app.user.edit'))
            // save user
            $(document).on('click', '#save-btn', function() {
                var form_data = document.getElementById('store_or_update_form');
                var form = new FormData(form_data);
                let url = "{{ route('app.user.store.or.update') }}";
                let id = $('#update_id').val();
                let method;
                if (id) {
                    method = 'update';
                } else {
                    method = 'add';
                }
                $.ajax({
                    url: url,
                    type: "POST",
                    data: form,
                    dataType: "JSON",
                    contentType: false,
                    processData: false,
                    cache: false,
                    beforeSend: function() {
                        $('#save-btn span').addClass('spinner-border spinner-border-sm text-light');
                    },
                    complete: function() {
                        $('#save-btn span').removeClass('spinner-border spinner-border-sm text-light');
                    },
                    success: function(data) {
                        $('#store_or_update_form').find('.is-invalid').removeClass('is-invalid');
                        $('#store_or_update_form').find('.error').remove();
                        if (data.status == false) {
                            $.each(data.errors, function(key, value) {
                                $('#store_or_update_form input#' + key).addClass('is-invalid');
                                $('#store_or_update_form textarea#' + key).addClass(
                                    'is-invalid');
                                $('#store_or_update_form select#' + key).parent().addClass(
                                    'is-invalid');
                                if (key == 'password' || key == 'password_confirmation') {
                                    $('#store_or_update_form #' + key).parents('.form-group')
                                        .append(
                                            '<small class="error text-danger">' + value +
                                            '</small>');
                                } else {
                                    $('#store_or_update_form #' + key).parent().append(
                                        '<small class="error text-danger">' + value +
                                        '</small>');
                                }

                            });
                        } else {
                            notification(data.status, data.message);
                            if (data.status == 'success') {
                                if (method == 'update') {
                                    table.ajax.reload(null, false);
                                } else {
                                    table.ajax.reload();
                                }
                                $('#store_or_update_modal').modal('hide');
                            }
                        }

                    },
                    error: function(xhr, ajaxOption, thrownError) {
                        console.log(thrownError + '\r\n' + xhr.statusText + '\r\n' + xhr.responseText);
                    }
                });
            });
        @endif






        @permission('app.user.bulk-delete')
            // multi delete
            function multi_delete() {
                let ids = [];
                let rows;
                $('.select_data:checked').each(function() {
                    ids.push($(this).val());
                    rows = table.rows($('.select_data:checked').parents('tr'));
                });

                if (ids.length == 0) {
                    Swal.fire({
                        type: 'error',
                        title: 'Error',
                        text: 'Please checked at least one row of table!',
                        icon: 'warning',
                    });
                } else {
                    let url = "{{ route('app.user.bulk.delete') }}";
                    bulk_delete(ids, url, rows);
                }
            }
        @endpermission

        $('#image').spartanMultiImagePicker({
            fieldName: 'image[]',
            maxCount: 5,
            rowHeight: '150px',
            groupClassName: 'col-md-12 com-sm-12 com-xs-12 px-0',
            maxFileSize: '',
            dropFileLabel: 'Drop Here',
            allowExt: 'png|jpg|jpeg',
            onExtensionErr: function(index, file) {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Only png,jpg,jpeg file format allowed!'
                });
            }
        });

        $('input[name="image"]').prop('required', true);
        $('input[name="image[]"]').prop('multiple', true);
        $('.remove-files').on('click', function() {
            $(this).parents('.col-md-12').remove();
        });

        // status changes
        $(document).on('click', '.change_status', function() {
            var id = $(this).data('id');
            var name = $(this).data('name');
            var status = $(this).data('status');
            var url = "{{ route('app.tour.category.status.change') }}"
            change_status(id, status, name, url);
        });


      
    </script>
@endpush
