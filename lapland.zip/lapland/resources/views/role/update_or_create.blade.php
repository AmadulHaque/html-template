@extends('layouts.app')
@section('site_title', $site_title)
@push('styles')
    <style>
        .module-title {
            font-size: 15px;
            font-weight: 600;
        }
    </style>
@endpush
@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header py-2">
                    <h4 class="mb-0 cd-title">{{ $title }}</h4>
                </div>
                <div class="card-body">
                    <form action="{{ isset($role) ? route('app.role.update', $role->id) : route('app.role.store') }}" method="POST">
                        @csrf
                        @isset($role)
                        @method('PUT')
                        @endisset
                        <x-form.inputbox name="name" labelName="Role Name" required="required" value="{{ $role->name ?? '' }}" placeholder="Enter role name" error="name"/>
                            @isset($role)
                            @php
                                $all_count = DB::table('permissions')->count();
                            @endphp
                            @endisset
                        <div class="row">
                            <div class="col-md-12">
                                @error('permission')
                                    <small class="text-danger d-block text-center">{{ $message }}</small>
                                @enderror
                            </div>
                            <div class="col-md-12 mb-3">
                                <div class="form-checkbox">
                                    <input type="checkbox" class="form-check-input" @isset($role) {{ $all_count == $role->permissions->count() ? 'checked' : '' }} @endisset id="all">
                                    <label class="form-check-label" for="all">Select All</label>
                                </div>
                            </div>

                            @forelse ($modules->chunk(4) as $module)
                                @foreach ($module as $value)
                                    <div class="col-md-3 mb-4">
                                        <h6 class="mb-0 module-title">{{ $value->name }}</h6>
                                        <div class="mt-2">
                                            @foreach ($value->permissions as $permission)
                                                <div class="form-checkbox mb-1">
                                                    <input type="checkbox" class="form-check-input" name="permission[]" value="{{ $permission->id }}" id="single-role-{{ $permission->id }}"
                                                    @isset($role)
                                                        @foreach ($role->permissions as $r_permission)
                                                            {{ $r_permission->id == $permission->id ? 'checked' : '' }}
                                                        @endforeach
                                                    @endisset
                                                    >
                                                    <label class="form-check-label" for="single-role-{{ $permission->id }}">{{ $permission->name }}</label>
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>
                                @endforeach
                            @empty

                            @endforelse
                        </div>

                        <div class="text-right">
                            <button type="submit" class="btn btn-sm btn-primary rounded-0">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
<script>
    $(document).on('click', 'input#all', function(){
        if (this.checked) {
            $(':checkbox').each(function(){
                this.checked = true;
            })
        }else{
            $(':checkbox').each(function(){
                this.checked = false;
            })
        }
    });
</script>
@endpush
