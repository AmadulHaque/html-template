@extends('layouts.app')
@section('site_title', $site_title)
@section('content')
    @push('styles')
        <style>
            input[type="file"] {
                display: block;
            }

            .imageThumb {
                max-height: 75px;
                border: 2px solid;
                padding: 1px;
                cursor: pointer;
            }

            .pip {
                display: inline-block;
                margin: 10px 10px 0 0;
            }

            .remove {
                display: block;
                background: #444;
                border: 1px solid black;
                color: white;
                text-align: center;
                cursor: pointer;
            }

            .remove:hover {
                background: white;
                color: black;
            }
        </style>
    @endpush
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <form id="createTourForm" action="{{ route('app.tour.store') }}" method="POST"
                        enctype="multipart/form-data">
                        @csrf

                           <div class="row">
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="is_bokun" class="required">Is Bokun Tour</label>
                                    <select class="form-control  @error('is_bokun') is-invalid @enderror" id="bokunSelect"
                                        name="is_bokun">
                                        <option value="2" {{ old('is_bokun') == '2' ? 'selected' : '' }}>OFF</option>
                                        <option value="1" {{ old('is_bokun') == '1' ? 'selected' : '' }}>ON</option>
                                    </select>
                                    @error('is_bokun')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                           </div>

                            <div class="form-group" id="bokunDiv" style="display: none;">
                                <label for="bokun_code" class="required">Bokun Code</label>
                            <input type="text" class="form-control @error('bokun_code') is-invalid @enderror"
                                id="bokun_code" name="bokun_code" value="{{ old('bokun_code') }}">
                            @error('tour_title')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            </div>
                   

                        <div class="form-group">
                            <label for="title" class=" required">Tour Title</label>
                            <input type="text" class="form-control @error('title') is-invalid @enderror"
                                id="title" name="title" value="{{ old('title') }}">
                            @error('tour_title')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="tour_category_id" class="required">Tour Category</label><br>
                                    <select class="form-control select2 @error('tour_category_id') is-invalid @enderror"
                                        id="tour_category_id" name="tour_category_id">
                                        <option value="">Select a Category</option>
                                        @foreach ($tourCategories as $tourCategory)
                                            <option value="{{ $tourCategory->id }}"
                                                {{ old('tour_category_id') == $tourCategory->id ? 'selected' : '' }}>
                                                {{ $tourCategory->title }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('tour_category_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="start_date_time" class="required">Start Date and Time</label>
                                    <input type="datetime-local"
                                        class="form-control @error('start_date_time') is-invalid @enderror"
                                        id="start_date_time" name="start_date_time" value="{{ old('start_date_time') }}">
                                    @error('start_date_time')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="end_date_time" class="required">End Date and Time</label>
                                    <input type="datetime-local"
                                        class="form-control @error('end_date_time') is-invalid @enderror"
                                        id="end_date_time" name="end_date_time" value="{{ old('end_date_time') }}">
                                    @error('end_date_time')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="thumbnail_images" class="required">Thumbnail Images</label>
                            <input type="file" class="form-control-file @error('thumbnail_images') is-invalid @enderror"
                                id="thumbnail_images" name="thumbnail_images[]" multiple>
                            <small class="form-text text-muted">(Max 10 images, Max Size Per file: 5MB)</small>
                            @error('thumbnail_images')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>


                        <div class="form-group">
                            <label for="banner_images" class="required">Banner Image</label>
                            <input type="file" class="form-control-file @error('banner_images') is-invalid @enderror"
                                id="banner_images" name="banner_images[]" multiple>
                            <small class="form-text text-muted">(Max Size 5MB)</small>
                            @error('banner_images')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>


                        <div class="form-group">
                            <label for="tour_location" class="required">Tour Location</label>
                            <input type="text" class="form-control @error('tour_location') is-invalid @enderror"
                                id="tour_location" name="tour_location" value="{{ old('tour_location') }}">
                            @error('tour_location')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>


                        <div class="form-group">
                            <label for="time_slot_ids" class="required">Time Slots</label>

                            <select class="form-control select2 @error('time_slot_ids') is-invalid @enderror" id="time_slot_ids" name="time_slot_ids[]" multiple>
                                @foreach ($timeSlots as $timeSlot)
                                    <option value="{{ $timeSlot->id }}" {{ in_array($timeSlot->id, old('time_slot_ids', [])) ? 'selected' : '' }}>
                                        {{ $timeSlot->title }}
                                    </option>
                                @endforeach
                            </select>
                            @error('time_slot_ids')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>


                        <div class="row">
                            <div class="col-md-3 border border-info  ">
                                <div class="form-group">
                                    <label for="adult" class="required">Adult</label>
                                    <select class="form-control select-toggle @error('adult') is-invalid @enderror" id="adult"
                                        name="adult">
                                        <option value="1" {{ old('adult') == '1' ? 'selected' : '' }}>ON</option>
                                        <option value="2" {{ old('adult') == '2' ? 'selected' : '' }}>OFF</option>
                                    </select>
                                    @error('adult')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="default_adult_quantity">Default Adult Quantity</label>
                                    <input type="number"
                                        class="form-control @error('default_adult_quantity') is-invalid @enderror"
                                        id="default_adult_quantity" name="default_adult_quantity"
                                        value="{{ old('default_adult_quantity') }}">
                                    @error('default_adult_quantity')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="extra_adult_price" class="required">Extra Adult Price</label>
                                    <input type="number"
                                        class="form-control @error('extra_adult_price') is-invalid @enderror"
                                        id="extra_adult_price" name="extra_adult_price"
                                        value="{{ old('extra_adult_price') }}">
                                    @error('extra_adult_price')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="form-group">
                                    <label for="max_adult_allowed" class="required">Max Adult Allowed</label>
                                    <input type="number"
                                        class="form-control @error('max_adult_allowed') is-invalid @enderror"
                                        id="max_adult_allowed" name="max_adult_allowed"
                                        value="{{ old('max_adult_allowed') }}">
                                    @error('max_adult_allowed')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                            </div>
                            <div class="col-md-3 border border-info ">
                                <div class="form-group">
                                    <label for="children" class="required">Children</label>
                                    <select class="form-control select-toggle @error('children') is-invalid @enderror" id="children"
                                        name="children">
                                        <option value="1" {{ old('children') == '1' ? 'selected' : '' }}>ON</option>
                                        <option value="2" {{ old('children') == '2' ? 'selected' : '' }}>OFF</option>
                                    </select>
                                    @error('children')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="default_children_quantity">Default Children Quantity</label>
                                    <input type="number"
                                        class="form-control @error('default_children_quantity') is-invalid @enderror"
                                        id="default_children_quantity" name="default_children_quantity"
                                        value="{{ old('default_children_quantity') }}">
                                    @error('default_children_quantity')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="extra_children_price" class="required">Extra Children Price</label>
                                    <input type="number"
                                        class="form-control @error('extra_children_price') is-invalid @enderror"
                                        id="extra_children_price" name="extra_children_price"
                                        value="{{ old('extra_children_price') }}">
                                    @error('extra_children_price')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="max_children_allowed" class="required">Max Children Allowed</label>
                                    <input type="number"
                                        class="form-control @error('max_children_allowed') is-invalid @enderror"
                                        id="max_children_allowed" name="max_children_allowed"
                                        value="{{ old('max_children_allowed') }}">
                                    @error('max_children_allowed')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-3 border border-info ">
                                <div class="form-group">
                                    <label for="infant" class="required">Infant</label>
                                    <select class="form-control select-toggle @error('infant') is-invalid @enderror" id="infant"
                                        name="infant">
                                        <option value="1" {{ old('infant') == '1' ? 'selected' : '' }}>ON</option>
                                        <option value="2" {{ old('infant') == '2' ? 'selected' : '' }}>OFF</option>
                                    </select>
                                    @error('infant')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="default_infant_quantity">Default Infant Quantity</label>
                                    <input type="number"
                                        class="form-control @error('default_infant_quantity') is-invalid @enderror"
                                        id="default_infant_quantity" name="default_infant_quantity"
                                        value="{{ old('default_infant_quantity') }}">
                                    @error('default_infant_quantity')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="extra_infant_price" class="required">Extra Infant Price</label>
                                    <input type="number"
                                        class="form-control @error('extra_infant_price') is-invalid @enderror"
                                        id="extra_infant_price" name="extra_infant_price"
                                        value="{{ old('extra_infant_price') }}">
                                    @error('extra_infant_price')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="max_infant_allowed" class="required">Max Infant Allowed</label>
                                    <input type="number"
                                        class="form-control @error('max_infant_allowed') is-invalid @enderror"
                                        id="max_infant_allowed" name="max_infant_allowed"
                                        value="{{ old('max_infant_allowed') }}">
                                    @error('max_infant_allowed')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-3 border border-info ">
                                <div class="form-group">
                                    <label for="pet" class="required">Pet</label>
                                    <select class="form-control select-toggle @error('pet') is-invalid @enderror" id="pet"
                                        name="pet">
                                        <option value="1" {{ old('pet') == '1' ? 'selected' : '' }}>ON</option>
                                        <option value="2" {{ old('pet') == '2' ? 'selected' : '' }}>OFF</option>
                                    </select>
                                    @error('pet')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="default_pet_quantity">Default Pet Quantity</label>
                                    <input type="number"
                                        class="form-control @error('default_pet_quantity') is-invalid @enderror"
                                        id="default_pet_quantity" name="default_pet_quantity"
                                        value="{{ old('default_pet_quantity') }}">
                                    @error('default_pet_quantity')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="form-group">
                                    <label for="extra_pet_price" class="required">Extra Pet Price</label>
                                    <input type="number"
                                        class="form-control @error('extra_pet_price') is-invalid @enderror"
                                        id="extra_pet_price" name="extra_pet_price"
                                        value="{{ old('extra_pet_price') }}">
                                    @error('extra_pet_price')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="max_pet_allowed" class="required">Max Pet Allowed</label>
                                    <input type="number"
                                        class="form-control @error('max_pet_allowed') is-invalid @enderror"
                                        id="max_pet_allowed" name="max_pet_allowed"
                                        value="{{ old('max_pet_allowed') }}">
                                    @error('max_pet_allowed')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                            </div>
                        </div>

                        <div class="form-group">
                            <label for="tour_base_price" class="required">Tour Base Price</label>
                            <input type="number" class="form-control @error('tour_base_price') is-invalid @enderror" id="tour_base_price" name="tour_base_price" value="{{ old('tour_base_price') }}">
                            @error('tour_base_price')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea class="form-control summernote @error('description') is-invalid @enderror" id="description" name="description">{{ old('description') }}</textarea>
                            @error('description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="youtube_video_link">YouTube Video Link</label>
                            <input type="text" class="form-control @error('youtube_video_link') is-invalid @enderror"
                                id="youtube_video_link" name="youtube_video_link"
                                value="{{ old('youtube_video_link') }}">
                            @error('youtube_video_link')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
       
                        <div class="form-group">
                            <label for="tour_include_ids" class="required">Tour Include</label>
                            <select class="form-control select2 @error('tour_include_ids') is-invalid @enderror"
                                id="tour_include_ids" name="tour_include_ids[]" multiple>
                      
                                @foreach($tourIncludes as $tourInclude)
                                    <option value="{{ $tourInclude->id }}" {{ in_array($tourInclude->id, old('tour_include_ids', [])) ? 'selected' : '' }}>{{ $tourInclude->title }}</option>
                                @endforeach
                            </select>
                            @error('tour_include_ids')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="faq_ids" class="required">FAQs</label>
                            <select class="form-control select2 @error('faq_ids') is-invalid @enderror" id="faq_ids" name="faq_ids[]" multiple>
                                @foreach ($faqs as $faq)
                                    <option value="{{ $faq->id }}" {{ in_array($faq->id, old('faq_ids', [])) ? 'selected' : '' }}>
                                        {{ $faq->question }}
                                    </option>
                                @endforeach
                            </select>
                            @error('faq_ids')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                            
                        <div class="form-group">
                            <label for="booking_in_advanced">Booking in Advanced</label>
                            <input type="text" class="form-control @error('booking_in_advanced') is-invalid @enderror"
                                id="booking_in_advanced" name="booking_in_advanced"
                                value="{{ old('booking_in_advanced') }}">
                            @error('booking_in_advanced')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        
                        <div class="form-group">
                            <label for="contact_meeting">Contact Meeting</label>
                            <textarea class="form-control summernote @error('contact_meeting') is-invalid @enderror" id="contact_meeting"
                                name="contact_meeting">{{ old('contact_meeting') }}</textarea>
                            @error('contact_meeting')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        
                        <div class="form-group">
                            <label for="pick_up">Pick Up</label>
                            <textarea class="form-control summernote @error('pick_up') is-invalid @enderror" id="pick_up" name="pick_up">{{ old('pick_up') }}</textarea>
                            @error('pick_up')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        
                        <div class="form-group">
                            <label for="map_link" class="required">Map Link</label>
                            <input type="text" class="form-control @error('map_link') is-invalid @enderror"
                                id="map_link" name="map_link" value="{{ old('map_link') }}">
                            @error('map_link')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="change_date_policy">Change Date Policy</label>
                                    <select class="form-control @error('change_date_policy') is-invalid @enderror"
                                        id="change_date_policy" name="change_date_policy">
                                        <option value="1" {{ old('change_date_policy') == '1' ? 'selected' : '' }}>YES
                                        </option>
                                        <option value="2" {{ old('change_date_policy') == '2' ? 'selected' : '' }}>NO
                                        </option>
                                    </select>
                                    @error('change_date_policy')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="status" class="required">Status</label>
                                    <select class="form-control @error('status') is-invalid @enderror" id="status"
                                        name="status">
                                        <option value="1" {{ old('status') == '1' ? 'selected' : '' }}>Active</option>
                                        <option value="2" {{ old('status') == '2' ? 'selected' : '' }}>Inactive</option>
                                    </select>
                                    @error('status')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        

                        <div class="form-group text-center">
                            <button type="submit" class="btn btn-info btn-sm">Create Tour</button>
                        </div>
                    </form>
                {{--  --}}
                <script type="text/javascript" src="https://widgets.bokun.io/assets/javascripts/apps/build/BokunWidgetsLoader.js?bookingChannelUUID=b278aba1-ee65-4bed-b8c9-fa10df9f3e62" async></script>
                    <style> #bokun_e0c2f868_4e39_4cee_86ef_f7b5b97df6fd { display: inline-block; padding: 10px 20px; background: #408C3D; border-radius: 5px; box-shadow: none; font-weight: 600; font-size: 16px; text-decoration: none; text-align: center; color: #FFFFFF; border:none; cursor: pointer; transition: background .2s ease; } #bokun_e0c2f868_4e39_4cee_86ef_f7b5b97df6fd:hover{ background: #285726; } #bokun_e0c2f868_4e39_4cee_86ef_f7b5b97df6fd:active{ background: #30682e; } </style> <button class="bokunButton" disabled id=bokun_e0c2f868_4e39_4cee_86ef_f7b5b97df6fd data-src="https://widgets.bokun.io/online-sales/b278aba1-ee65-4bed-b8c9-fa10df9f3e62/experience/801980?partialView=1" data-testid="widget-book-button" > Book now </button> 
                {{--  --}}

                </div>
            </div>
        </div>
    </div>

@endsection

@push('scripts')
    <script src="{{ asset('/') }}js/spartan-multi-image-picker-min.js"></script>
    <script>
        //Thumbnail Images
        $(document).ready(function() {
            if (window.File && window.FileList && window.FileReader) {
                $("#thumbnail_images").on("change", function(e) {
                    var files = e.target.files,
                        filesLength = files.length;

                    var maxFileSize = 5120;
                    var maxFileLimit = 10;
                    for (var i = 0; i < filesLength; i++) {
                        var f = files[i];
                        var fileSize = f.size / 1024;
                        if (fileSize > maxFileSize) {
                            $(this).val('');
                            alert("File size exceeds the limit of 5MB.");
                            continue;
                        }

                        if (filesLength >= maxFileLimit) {
                            $(this).val('');
                            alert("You can only upload a maximum of 10 files.");
                            break;
                        }

                        var fileReader = new FileReader();
                        fileReader.onload = (function(e) {
                            var file = e.target;
                            $("<span class=\"pip\">" +
                                "<img class=\"imageThumb\" src=\"" + e.target.result +
                                "\" title=\"" + file.name + "\"/>" +
                                "<br/><span class=\"remove\">Remove image</span>" +
                                "</span>").insertAfter("#thumbnail_images");
                            $(".remove").click(function() {
                                $(this).parent(".pip").remove();
                            });
                        });
                        fileReader.readAsDataURL(f);
                    }
                    console.log(files);
                });
            } else {
                alert("Your browser doesn't support to File API")
            }
        });

        //Banner Image
        $(document).ready(function() {
            if (window.File && window.FileList && window.FileReader) {
                $("#banner_images").on("change", function(e) {
                    var files = e.target.files,
                        filesLength = files.length;

                    var maxFileSize = 5120;
                    var maxFileLimit = 10;
                    for (var i = 0; i < filesLength; i++) {
                        var f = files[i];
                        var fileSize = f.size / 1024;
                        if (fileSize > maxFileSize) {
                            $(this).val('');
                            alert("File size exceeds the limit of 5MB.");
                            continue;
                        }

                        if (filesLength >= maxFileLimit) {
                            $(this).val('');
                            alert("You can only upload a maximum of 1 file.");
                            break;
                        }

                        var fileReader = new FileReader();
                        fileReader.onload = (function(e) {
                            var file = e.target;
                            $("<span class=\"pip\">" +
                                "<img class=\"imageThumb\" src=\"" + e.target.result +
                                "\" title=\"" + file.name + "\"/>" +
                                "<br/><span class=\"remove\">Remove image</span>" +
                                "</span>").insertAfter("#banner_images");
                            $(".remove").click(function() {
                                $(this).parent(".pip").remove();
                            });
                        });
                        fileReader.readAsDataURL(f);
                    }
                    console.log(files);
                });
            } else {
                alert("Your browser doesn't support to File API")
            }
        });

        //Thumbnail Video

        $(document).ready(function() {
            if (window.File && window.FileList && window.FileReader) {
                $("#video").on("change", function(e) {
                    var video = e.target.files[0];

                    // Set maximum file size in bytes (10MB)
                    var maxFileSize = 10 * 1024 * 1024;

                    if (video) {
                        var fileSize = video.size;

                        if (fileSize > maxFileSize) {
                            alert("Video size exceeds the limit of 10MB.");
                            $(this).val('');
                            return;
                        }

                        var videoType = video.type.split('/')[0]; // Get the video type (e.g., "video")

                        if (videoType !== 'video') {
                            alert("Please select a valid video file.");
                            $(this).val('');
                            return;
                        }

                        var videoURL = URL.createObjectURL(video);
                        $("#video-preview").attr("src", videoURL).show();
                    }
                });
            } else {
                alert("Your browser doesn't support the File API");
            }
        });

        //Search Reloevant Tours
        // const $searchSelect = $('#searchSelect');

        // $searchSelect.select2({
        //     placeholder: 'Search',
        //     minimumInputLength: 2,
        //     ajax: {
        //         url: 'url',
        //         dataType: 'json',
        //         delay: 250,
        //         data: function(params) {
        //             return {
        //                 query: params.term
        //             };
        //         },
        //         processResults: function(data) {
        //             return {
        //                 results: data.map(item => ({
        //                     id: item.id,
        //                     text: item.value
        //                 }))
        //             };
        //         }
        //     }
        // });

        // $searchSelect.on('select2:open', function() {
        //     $searchSelect.select2('close');
        // });

        // $searchSelect.on('select2:select', function(e) {
        //     const selectedData = e.params.data;
        //     console.log('Selected ID:', selectedData.id);
        //     console.log('Selected Text:', selectedData.text);
        // });

        //SummerNote
        $(function() {
            $('.summernote').summernote({
                height: 280,
            });

        });

      

        //is bokun or not
        $('#bokunSelect').change(function () {
        var selectedOption = $(this).val();

        if (selectedOption === '1') {
            $('#bokunDiv').show();
        } else {
            $('#bokunDiv').hide();
        }
    });
    </script>
    <script>
        $(document).ready(function() {
            $('.select-toggle').change(function() {
                var selectedValue = $(this).val();
        
                var parentColumn = $(this).closest('.col-md-3');
                parentColumn.find('.form-group:not(:first)').toggle(selectedValue === '1'); 
            });
        
            $('.select-toggle').trigger('change');
        });
        </script>
@endpush
