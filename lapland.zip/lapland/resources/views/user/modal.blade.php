<div id="store_or_update_modal" class="modal fade show" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header py-2">
                <h5 class="modal-title" ></h5>
                <button type="button" class="close shadow-none" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body">
                <form id="store_or_update_form" method="POST" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="update_id" id="update_id">
                    <x-form.inputbox name="name" labelName="Name" required="required"/>
                    <x-form.inputbox type="email" labelName="Email" name="email" required="required"/>
                    <x-form.inputbox name="mobile_no" labelName="Mobile No"/>
                    <x-form.inputbox name="address" labelName="Address"/>
                    <x-form.inputbox type="password" name="password" labelName="Password" required="required"/>
                    <x-form.inputbox type="password" name="password_confirmation" labelName="Confirm Password" required="required"/>
                    <x-form.selectbox name="gender" labelName="Gender" required="required">
                    <option value="">Select Gender</option>
                        @foreach (GENDER as $key=>$value)
                            <option value="{{ $key }}">{{ $value }}</option>
                    @endforeach
                    </x-form.selectbox>
                    <x-form.selectbox name="role_id" labelName="Role" required="required">
                        <option value="">Select Role</option>
                        @foreach ($roles as $value)
                            <option value="{{ $value->id }}">{{ $value->name }}</option>
                        @endforeach
                    </x-form.selectbox>
                    <div class="form-group">
                        <label for="image" class="required">Profile</label>
                        <div class="px-0 text-center">
                            <div id="image">

                            </div>
                        </div>
                        <input type="hidden" name="old_image" id="old_image">
                    </div>
                </form>
            </div>
            <div class="modal-footer pt-0 border-0">
                <button type="button" class="btn btn-sm btn-danger rounded-0" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-sm btn-primary rounded-0" id="save-btn"></button>
            </div>
        </div>
    </div>
</div>
