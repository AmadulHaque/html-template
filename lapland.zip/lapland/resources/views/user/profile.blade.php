@extends('layouts.app')
@section('site_title',$site_title)
@push('styles')

@endpush

@section('content')
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="card">
                <div class="card-body pt-2">
                    <ul class="nav nav-tabs mb-3" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link text-uppercase active" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="true">Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-uppercase" id="password-tab" data-toggle="tab" href="#password" role="tab" aria-controls="password" aria-selected="false">Password</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade active show" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <form id="profile-form" method="POST" enctype="multipart/form-data">
                                @csrf
                                <x-form.inputbox name="name" labelName="Name" value="{{ auth()->user()->name }}"/>
                                <x-form.inputbox type="email" name="email" labelName="Email" value="{{ auth()->user()->email }}"/>
                                <x-form.inputbox type="number" name="mobile_no" labelName="Mobile No" value="{{ auth()->user()->mobile_no }}"/>
                                <div class="form-group">
                                    <div class="custom-control custom-radio custom-control-inline pl-0">
                                        Gender:
                                    </div>
                                    <div class="custom-control custom-radio custom-control-inline">
                                        <input type="radio" id="male" name="gender" {{ auth()->user()->gender == '1' ? 'checked' : '' }} value="1" class="custom-control-input">
                                        <label class="custom-control-label" for="male">Male</label>
                                    </div>
                                    <div class="custom-control custom-radio custom-control-inline">
                                        <input type="radio" id="female" name="gender" {{ auth()->user()->gender == '2' ? 'checked' : '' }} value="2" class="custom-control-input">
                                        <label class="custom-control-label" for="female">Female</label>
                                    </div>
                                    <div id="gender"></div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="image">Profile</label>
                                            <div class="px-0 text-center">
                                                <div id="image">

                                                </div>
                                            </div>
                                            <input type="hidden" name="old_avatar" id="old_avatar" value="{{ Auth::user()->avatar }}">
                                        </div>
                                    </div>
                                </div>
                            </form>

                            <div class="text-right">
                                <button type="button" class="btn btn-sm btn-primary rounded-0" id="save-profile" onclick="save_data('profile')"><span></span>Save Change</button>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="password" role="tabpanel" aria-labelledby="password-tab">
                            <form id="password-form" method="POST">
                                @csrf
                                <x-form.inputbox type="password" name="current_password" labelName="Current Password"/>
                                <x-form.inputbox type="password" name="password" labelName="Password"/>
                                <x-form.inputbox type="password" name="password_confirmation" labelName="Confirm Password"/>
                            </form>

                            <div class="text-right">
                                <button type="button" class="btn btn-sm btn-primary rounded-0" id="save-password" onclick="save_data('password')"><span></span>Save Change</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('scripts')
    <script src="{{ asset('/') }}js/spartan-multi-image-picker-min.js"></script>
    <script>
        $('#image').spartanMultiImagePicker({
            fieldName: 'image',
            maxCount: 1,
            rowHeight: '200px',
            groupClassName: 'col-md-12 com-sm-12 com-xs-12 pl-0',
            maxFileSize: '',
            dropFileLabel: 'Drop Here',
            allowExt: 'png|jpg|jpeg',
            onExtensionErr: function(index, file){
                Swal.fire({icon:'error',title:'Oops...',text: 'Only png,jpg,jpeg file format allowed!'});
            }
        });

        $('input[name="image"]').prop('required',true);
        $('.remove-files').on('click', function(){
            $(this).parents('.col-md-12').remove();
        });

        @if(Auth::user()->avatar)
            $('#profile-form #image img.spartan_image_placeholder').css('display','none');
            $('#profile-form #image .spartan_remove_row').css('display','none');
            $('#profile-form #image .img_').css('display','block');
            $('#profile-form #image .img_').attr('src',"{{ asset('storage/'.USER_AVATAR_PATH.Auth::user()->avatar)}}");
        @endif

        function save_data(form_id){
            let form = document.getElementById(form_id+'-form');
            let formData = new FormData(form);
            let url;
            let id = $('#update_id').val();
            let method;
            if (form_id == 'profile') {
                url = '{{ route("app.profile.update") }}';
            } else if(form_id == 'password'){
                url = '{{ route("app.password.update") }}';
            }
            $.ajax({
                url: url,
                type: "POST",
                data: formData,
                dataType: "JSON",
                contentType: false,
                processData: false,
                cache: false,
                beforeSend: function(){
                    $('#save-'+form_id+' span').addClass('spinner-border spinner-border-sm text-light');
                },
                complete: function(){
                    $('#save-'+form_id+' span').removeClass('spinner-border spinner-border-sm text-light');
                },
                success: function (data) {
                    $('#'+form_id+'-form').find('.is-invalid').removeClass(
                        'is-invalid');
                    $('#'+form_id+'-form').find('.error').remove();
                    if (data.status == false) {
                        $.each(data.errors, function (key, value) {
                            $('#'+form_id+'-form input#' + key).addClass('is-invalid');
                            $('#'+form_id+'-form #' + key).parent().addClass('is-invalid');
                            if (key == 'password' || key == 'password_confirmation') {
                                $('#'+form_id+'-form #' + key).parents('.form-group').append(
                                    '<small class="error text-danger">' +
                                    value + '</small>');
                            } else {
                                $('#'+form_id+'-form #' + key).parent().append(
                                    '<small class="error text-danger">' +
                                    value + '</small>');
                            }
                        });
                    } else {
                        notification(data.status, data.message);
                        if (data.status == 'success') {
                            setInterval(() => {
                                window.location.reload();
                            }, 1000);
                        }
                    }

                },
                error: function (xhr, ajaxOption, thrownError) {
                    console.log(thrownError + '\r\n' + xhr.statusText + '\r\n' + xhr
                        .responseText);
                }
            });

        }
    </script>
@endpush
