<table class="details-table w-100">
    <tr>
        <td>Profile</td>
        <td>:</td>
        <td>{!! user_image($user->gender,USER_AVATAR_PATH,$user->avatar,$user->name) !!}</td>
    </tr>
    <tr>
        <td>Role</td>
        <td>:</td>
        <td><span class="badge badge-sm badge-success">{{ $user->role->name }}</span></td>
    </tr>
    <tr>
        <td>Name</td>
        <td>:</td>
        <td>{{ $user->name }}</td>
    </tr>
    <tr>
        <td>Email</td>
        <td>:</td>
        <td>{{ $user->email }}</td>
    </tr>
    <tr>
        <td>Mobile No</td>
        <td>:</td>
        <td>{{ $user->mobile_no }}</td>
    </tr>
    <tr>
        <td>Gender</td>
        <td>:</td>
        <td>{{ GENDER[$user->gender] }}</td>
    </tr>
    <tr>
        <td>Created By</td>
        <td>:</td>
        <td>{{ $user->created_by }}</td>
    </tr>
    <tr>
        <td>Updated By</td>
        <td>:</td>
        <td>{{ $user->updated_by }}</td>
    </tr>
    <tr>
        <td>Created At</td>
        <td>:</td>
        <td>{{ date('Y-m-d', strtotime($user->created_at)) }}</td>
    </tr>
</table>
