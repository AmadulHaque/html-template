$(document).ready(function(){
    // owl carusel 
    $('.tour-slider-row').owlCarousel({
        loop:true,
        autoplay:true,
        margin:0,
        items:1,
        nav:true,
        dots:true,  
        navText: [
            '<i class="fa fa-angle-left text-dark"></i>',
            '<i class="fa fa-angle-right text-dark"></i>'
        ],
    });

    // tour slider 
    $('.tour-tab-slider').owlCarousel({
        loop:true,
        autoplay:true,
        margin:0,
        items:1,
        nav:true,
        dots:true,  
        navText: [
            '<i class="fa fa-angle-left text-dark"></i>',
            '<i class="fa fa-angle-right text-dark"></i>'
        ],
    });
});