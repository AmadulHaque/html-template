<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomeController@index')->name('home');

Auth::routes([
    'register'         => false,   // 404 disabled
    'password.confirm' => false,   // 404 disabled
    'password.email'   => false,   // 404 disabled
]);


Route::get('tour/details/{slug}', 'TourController@show')->name('tour.show');
Route::get('tour/category/{slug}', 'TourController@categoryShow')->name('tour.category.show');

Route::group(['prefix' => 'admin/', 'as' => 'app.', 'middleware' => ['auth', 'account_access', 'permission']], function () {
    // Dashboard Routes
    Route::get('/', 'DashboardController@index')->name('dashboard');

    // Role Routes
    Route::group(['as' => 'role.', 'prefix' => 'role/'], function () {
        Route::get('/', 'RoleController@index')->name('index');
        Route::get('create', 'RoleController@create')->name('create');
        Route::post('store', 'RoleController@store')->name('store');
        Route::get('edit/{id}', 'RoleController@edit')->name('edit');
        Route::put('update/{id}', 'RoleController@update')->name('update');
        Route::post('delete', 'RoleController@delete')->name('delete');
        Route::post('bulk-delete', 'RoleController@bulk_delete')->name('bulk.delete');
    });

    // User Routes
    Route::group(['as' => 'user.', 'prefix' => 'user/'], function () {
        Route::get('/', 'UserController@index')->name('index');
        Route::post('store-or-update', 'UserController@store_or_update_data')->name('store.or.update');
        Route::post('view', 'UserController@view')->name('view');
        Route::post('edit', 'UserController@edit')->name('edit');
        Route::post('update', 'UserController@update')->name('update');
        Route::post('delete', 'UserController@delete')->name('delete');
        Route::post('bulk-delete', 'UserController@bulk_delete')->name('bulk.delete');
        Route::post('status-change', 'UserController@status_change')->name('status.change');
    });

    // Blog Routes
    Route::group(['as' => 'blog.', 'prefix' => 'blog/'], function () {
        Route::get('/', 'BlogController@index')->name('index');
        Route::get('/create', 'BlogController@create')->name('create');
        Route::post('/store', 'BlogController@store')->name('store');
        Route::get('/edit/{id}', 'BlogController@edit')->name('edit');
        Route::post('/update/{id}', 'BlogController@update')->name('update');
        Route::post('status-change', 'BlogController@status_change')->name('status.change');
    });

    // Blog Category Routes
    Route::group(['as' => 'blog.category.', 'prefix' => 'blog-category/'], function () {
        Route::get('/', 'BlogCategoryController@index')->name('index');
        Route::get('/create', 'BlogCategoryController@create')->name('create');
        Route::post('/store', 'BlogCategoryController@store')->name('store');
        Route::get('/edit/{id}', 'BlogCategoryController@edit')->name('edit');
        Route::post('/update/{id}', 'BlogCategoryController@update')->name('update');
        Route::post('status-change', 'BlogCategoryController@status_change')->name('status.change');
    });

    // Tour  Routes
    Route::group(['as' => 'tour.', 'prefix' => 'tour/'], function () {
        Route::get('/', 'TourController@index')->name('index');
        Route::get('/create', 'TourController@create')->name('create');
        Route::post('/store', 'TourController@store')->name('store');
        Route::get('/edit/{id}', 'TourController@edit')->name('edit');
        Route::post('/update/{id}', 'TourController@update')->name('update');
      
        Route::post('status-change', 'TourController@status_change')->name('status.change');
    });

    // Tour Category Routes
    Route::group(['as' => 'tour.category.', 'prefix' => 'tour-category/'], function () {
        Route::get('/', 'TourCategoryController@index')->name('index');
        Route::get('/create', 'TourCategoryController@create')->name('create');
        Route::post('/store', 'TourCategoryController@store')->name('store');
        Route::get('/edit/{id}', 'TourCategoryController@edit')->name('edit');
        Route::post('/update/{id}', 'TourCategoryController@update')->name('update');
        Route::post('status-change', 'TourCategoryController@status_change')->name('status.change');
    });

    // Faq Routes
    Route::group(['as' => 'faq.', 'prefix' => 'faq/'], function () {
        Route::get('/', 'FaqController@index')->name('index');
        Route::get('/create', 'FaqController@create')->name('create');
        Route::post('/store', 'FaqController@store')->name('store');
        Route::get('/edit/{id}', 'FaqController@edit')->name('edit');
        Route::post('/update/{id}', 'FaqController@update')->name('update');
        Route::post('status-change', 'FaqController@status_change')->name('status.change');
    });

    // Time Slot Routes
    Route::group(['as' => 'time-slot.', 'prefix' => 'time-slot/'], function () {
        Route::get('/', 'TimeSlotController@index')->name('index');
        Route::get('/create', 'TimeSlotController@create')->name('create');
        Route::post('/store', 'TimeSlotController@store')->name('store');
        Route::get('/edit/{id}', 'TimeSlotController@edit')->name('edit');
        Route::post('/update/{id}', 'TimeSlotController@update')->name('update');
        Route::post('status-change', 'TimeSlotController@status_change')->name('status.change');
    });

    // Tour Include Routes
    Route::group(['as' => 'tour-include.', 'prefix' => 'tour-include/'], function () {
        Route::get('/', 'TourIncludeController@index')->name('index');
        Route::get('/create', 'TourIncludeController@create')->name('create');
        Route::post('/store', 'TourIncludeController@store')->name('store');
        Route::get('/edit/{id}', 'TourIncludeController@edit')->name('edit');
        Route::post('/update/{id}', 'TourIncludeController@update')->name('update');
        Route::post('status-change', 'TourIncludeController@status_change')->name('status.change');
    });

    // Settings Routes
    Route::group(['as' => 'setting.', 'prefix' => 'setting/'], function () {
        Route::get('/', 'SettingController@index')->name('index');
        Route::post('/update', 'SettingController@update')->name('update');
    });

    //Payment Test Purpuse
    Route::group(['as' => 'payment.', 'prefix' => 'payment/'], function () {
        Route::get('/', 'PaymentController@index')->name('index');
        Route::get('/shojeeb', 'PaymentController@showPaymentForm')->name('payment');
        Route::post('/process-payment', 'PaymentController@processPayment')->name('process-payment');
        Route::get('/test', 'PaymentController@sendEmail')->name('test.invoice');
    });

    //Booking Routes Test Purpose
    Route::group(['as' => 'booking.', 'prefix' => 'booking/'], function () {
        Route::get('/invoice/{id}', 'BookingController@getBookingInvoice')->name('invoice');
        Route::get('/', 'BookingController@index')->name('index');
        Route::get('/shojeeb', 'BookingController@test')->name('booking.test');
    });

    // Profile Routes
    Route::get('my-profile', 'ProfileController@my_profile')->name('profile.index');
    Route::post('my-profile/update', 'ProfileController@my_profile_update')->name('profile.update');
    Route::post('password-update', 'ProfileController@change_password')->name('password.update');
});
