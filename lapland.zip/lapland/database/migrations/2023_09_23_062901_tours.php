<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Tours extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tours', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('slug');
            $table->bigInteger('tour_category_id');
            $table->string('thumbnail_images');
            $table->string('banner_images');
            $table->string('tour_location');
            $table->string('time_slot_ids');
            $table->timestamp('start_date_time')->nullable();
            $table->timestamp('end_date_time')->nullable();
            $table->enum('adult', [1,2])->default(1);
            $table->enum('children', [1,2])->default(1);
            $table->enum('infant', [1,2])->default(1);
            $table->enum('pet', [1,2])->default(1);
            $table->integer('default_adult_quantity')->default(0)->nullable();
            $table->integer('default_children_quantity')->default(0)->nullable();
            $table->integer('default_infant_quantity')->default(0)->nullable();
            $table->integer('default_pet_quantity')->default(0)->nullable();
            $table->integer('max_adult_allowed')->default(0);
            $table->integer('max_children_allowed')->default(0);
            $table->integer('max_infant_allowed')->default(0);
            $table->integer('max_pet_allowed')->default(0);
            $table->integer('tour_base_price')->default(0);
            $table->decimal('extra_adult_price', 8,2)->default(0);
            $table->decimal('extra_children_price', 8,2)->default(0);
            $table->decimal('extra_infant_price', 8,2)->default(0);
            $table->decimal('extra_pet_price', 8,2)->default(0);
            $table->text('description')->nullable();
            $table->string('youtube_video_link')->nullable();
            $table->string('tour_include_ids')->nullable();
            $table->string('faq_ids')->nullable();
            $table->string('booking_in_advanced')->nullable();
            $table->enum('change_date_policy', [1,2])->nullable();
            $table->text('contact_meeting')->nullable();
            $table->text('pick_up')->nullable();
            $table->text('map_link');
            $table->enum('is_bokun', [1,2])->default(2);
            $table->text('bokun_code')->nullable();
            $table->bigInteger('created_by')->nullable();
            $table->enum('status', [1,2,3])->default(1);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
