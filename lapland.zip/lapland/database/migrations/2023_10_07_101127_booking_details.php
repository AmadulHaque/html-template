<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class BookingDetails extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('booking_details', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('booking_id')->nullable();
            $table->bigInteger('tour_id')->nullable();
            $table->timestamp('start_date')->nullable();
            $table->timestamp('end_date')->nullable();
            $table->bigInteger('time_slot_id')->nullable();
            $table->integer('adult_quantity')->nullable();
            $table->double('per_adult_price', 8, 2)->nullable();
            $table->integer('child_quantity')->nullable();
            $table->double('per_child_price', 8, 2)->nullable();
            $table->integer('infant_quantity')->nullable();
            $table->double('per_infant_price', 8, 2)->nullable();
            $table->integer('pet_quantity')->nullable();
            $table->double('per_pet_price', 8, 2)->nullable();
            $table->double('total_price', 8, 2)->nullable();
            $table->enum('status', [1, 2, 3])->default(1);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
