<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Blogs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('blogs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('category_id')->constrained('blog_categories')->cascadeOnDelete();
            $table->string('title', 255);
            $table->string('slug', 255);
            $table->string('thumbnail_image', 255)->nullable();
            $table->string('thumbnail_video', 255)->nullable();
            $table->longText('description');
            $table->longText('winter')->nullable();
            $table->longText('kids')->nullable();
            $table->longText('pets')->nullable();
            $table->longText('summer')->nullable();
            $table->integer('banner_image');
            $table->integer('tag')->nullable();
            $table->string('relevant_tours')->nullable();
            $table->string('meta_title', 255)->nullable();
            $table->string('meta_description', 255)->nullable();
            $table->enum('status', [1, 2, 3])->default(1);
            $table->unsignedInteger('created_by');
            $table->timestamps();
            $table->timestamp('deleted_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
