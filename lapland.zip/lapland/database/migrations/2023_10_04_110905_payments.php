<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Payments extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('booking_id')->nullable();
            $table->bigInteger('user_id')->nullable();
            $table->longText('api_response')->nullable();
            $table->string('stripe_payment_id')->nullable();
            $table->enum('stripe_payment_status', ['succeeded', 'pending', 'failed', 'canceled'])->default('succeeded');
            $table->string('type')->nullable(); 
            $table->string('card_brand')->nullable(); 
            $table->string('last_four_digits')->nullable(); 
            $table->unsignedInteger('exp_month')->nullable(); 
            $table->unsignedInteger('exp_year')->nullable(); 
            $table->string('routing_number')->nullable(); 
            $table->string('account_number')->nullable(); 
            $table->string('account_holder_name')->nullable(); 
            $table->integer('amount')->nullable();
            $table->integer('amount_captured')->nullable();
            $table->integer('amount_refunded')->nullable();
            $table->string('balance_transaction')->nullable();
            $table->boolean('captured')->default(true);
            $table->timestamp('created')->nullable();
            $table->string('currency')->nullable();
            $table->string('description')->nullable();
            $table->string('invoice_id')->nullable(); 
            $table->boolean('livemode')->default(false);
            $table->string('metadata')->nullable();
            $table->string('payment_method')->nullable();
            $table->string('payment_intent')->nullable();
            $table->string('receipt_number')->nullable();
            $table->string('receipt_url')->nullable();
            $table->boolean('refunded')->default(false);
            $table->string('source_transfer')->nullable();
            $table->string('statement_descriptor')->nullable();
            $table->string('statement_descriptor_suffix')->nullable();
            $table->string('failure_code')->nullable(); 
            $table->string('failure_message')->nullable();
            $table->enum('status', [1,2,3])->default(1);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
