<?php

use App\User;
use App\Models\Role;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $super_role = Role::where(['name'=>'Super Admin'])->first();
        User::create([
            'role_id'  => $super_role->id,
            'name'     => 'Myolbd',
            'email'    => 'shojeebcse@gmail.com',
            'password' => 123456
        ]);

        $admin_role = Role::where(['name'=>'Admin'])->first();
        User::create([
            'role_id'  => $admin_role->id,
            'name'     => 'Admin',
            'email'    => 'admin@gmail.com',
            'password' => 123456
        ]);
    }
}
