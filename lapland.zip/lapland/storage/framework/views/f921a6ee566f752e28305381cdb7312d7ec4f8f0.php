<div class="form-group <?php echo e($groupClass ?? ''); ?>">
    <label for="<?php echo e($name); ?>" class="<?php echo e($required ?? ''); ?>"><?php echo e($labelName); ?></label>
    <select name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" class="form-control form-control-sm <?php echo e($class ?? ''); ?>" <?php if(!empty($onchange)): ?> onchange="<?php echo e($onchange); ?>" <?php endif; ?>>
        <?php echo e($slot); ?>

    </select>
    <?php if(isset($error)): ?>
        <?php $__errorArgs = [$error];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger d-block"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\lapland\resources\views/components/form/selectbox.blade.php ENDPATH**/ ?>