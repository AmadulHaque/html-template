
<?php $__env->startSection('site_title', $site_title); ?>
<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('styles'); ?>
    <?php $__env->stopPush(); ?>
    <?php
        // dd($booking->bookingDetails->tours);
    ?>

    <div class="row">
        <div class="col-12">
            

            <!-- Main content -->
            <div class="invoice p-3 mb-3 print">
                <!-- title row -->
                <div class="row">
                    <div class="col-12">
                        <h4>
                            <i class="fas fa-globe"></i> <?php echo e(env('APP_NAME')); ?>

                            <small class="float-right">Date: <?php echo e($booking->created_at); ?></small>
                        </h4>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- info row -->
                <div class="row invoice-info">
                    <div class="col-sm-4 invoice-col">
                        From
                        <address>
                            <strong><?php echo e(env('APP_NAME')); ?></strong><br>
                            795 Folsom Ave, Suite 600<br>
                            San Francisco, CA 94107<br>
                            Phone: (804) 123-5432<br>
                            Email: info@lapland.com
                        </address>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-4 invoice-col">
                        To
                        <address>
                            <strong><?php echo e($booking->bookedBy->name); ?></strong><br>
                            <?php echo e($booking->bookedBy->address); ?><br>
                            Phone: <?php echo e($booking->bookedBy->mobile_no); ?><br>
                            Email: <?php echo e($booking->bookedBy->email); ?>

                        </address>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-4 invoice-col">
                        
                        <b>Booking Number:</b> <?php echo e($booking->booking_number); ?><br>
                        <b>Booked Due:</b> 2/22/2014<br>

                        <?php if($booking->payment_status == 1): ?>
                            <b>Payment Status:</b> PAID <br>
                            <?php if($booking->successfulPayment && $booking->successfulPayment->type == 'card'): ?>
                            <?php else: ?>
                                <b>Account:</b> <?php echo e($booking->successfulPayment->account_number ?? null); ?>

                            <?php endif; ?>
                        <?php else: ?>
                            <b>Payment Status:</b> UNPAID <br>
                        <?php endif; ?>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->

                <!-- Table row -->
                <div class="row">
                    <div class="col-12 table-responsive">
                        <table class=" table-striped table-bordered w-100">
                            <thead>
                                <tr>
                                    <th>Serial</th>
                                    <th>Tour</th>
                                    <th>Date</th>
                                    <th>Details</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $grandTotal = 0;
                                ?>
                                <?php $__currentLoopData = $booking->bookingDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($details->tour->title); ?></td>
                                        <?php if($details->tour->end_date_time): ?>
                                            <td class="small">
                                                <?php echo e($details->tour->start_date_time); ?>

                                                <br>
                                                to
                                                <br>
                                                <?php echo e($details->tour->end_date_time); ?>

                                            </td>
                                        <?php else: ?>
                                            <td class="small">
                                                <?php echo e($details->tour->start_date_time); ?>

                                            </td>
                                        <?php endif; ?>
                                        <td class="small p-1">
                                            Adult: <?php echo e($details->adult_quantity); ?> x
                                            <?php echo e(config('settings.currency_icon') . $details->per_adult_price); ?> =
                                            <?php echo e(config('settings.currency_icon') . calculateSubtotal($details->adult_quantity, $details->per_adult_price)); ?><br>
                                            Child: <?php echo e($details->child_quantity); ?> x
                                            <?php echo e(config('settings.currency_icon') . $details->per_child_price); ?> =
                                            <?php echo e(config('settings.currency_icon') . calculateSubtotal($details->child_quantity, $details->per_child_price)); ?><br>
                                            Infant: <?php echo e($details->infant_quantity); ?> x
                                            <?php echo e(config('settings.currency_icon') . $details->per_infant_price); ?> =
                                            <?php echo e(config('settings.currency_icon') . calculateSubtotal($details->infant_quantity, $details->per_infant_price)); ?><br>
                                            Pet: <?php echo e($details->pet_quantity); ?> x
                                            <?php echo e(config('settings.currency_icon') . $details->per_pet_price); ?> =
                                            <?php echo e(config('settings.currency_icon') . calculateSubtotal($details->pet_quantity, $details->per_pet_price)); ?><br>
                                        </td>
                                        <td class="small text-center">
                                            <?php
                                                
                                                $grandTotal += calculateTotalPrice($details);
                                            ?>
                                            <?php echo e(config('settings.currency_icon') . calculateTotalPrice($details)); ?>

                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->

                <div class="row">
                    <!-- accepted bookings column -->
                    <div class="col-9">
                        
                    </div>
                    <!-- /.col -->
                    <div class="col-3">
                        

                        <div class="table-responsive">
                            <table class="table">
                                <tr>
                                    <th style="width:100%">Subtotal:</th>
                                    <td>
                                        <?php echo e(config('settings.currency_icon') . $grandTotal); ?>


                                    </td>
                                </tr>
                                
                                <tr>
                                    <th>Total:</th>
                                    <td>
                                        <?php echo e(config('settings.currency_icon') . $grandTotal); ?>

                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->

                <!-- this row will not appear when printing -->
                <div class="row no-print">
                    <div class="col-12">
                        <button id="printButton"><i class="fas fa-print"></i> Print</button>
                        
                        
                    </div>
                </div>
            </div>
            <!-- /.invoice -->
        </div><!-- /.col -->
    </div><!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('/')); ?>js/spartan-multi-image-picker-min.js"></script>
    <script>
        $('#printButton').click(function() {
            window.print();
            return false;
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lapland\resources\views/emails/confirmation.blade.php ENDPATH**/ ?>