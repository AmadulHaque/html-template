
<?php $__env->startSection('site_title',$site_title); ?>
<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="card">
                <div class="card-body pt-2">
                    <ul class="nav nav-tabs mb-3" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link text-uppercase active" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="true">Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-uppercase" id="password-tab" data-toggle="tab" href="#password" role="tab" aria-controls="password" aria-selected="false">Password</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade active show" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <form id="profile-form" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.inputbox','data' => ['name' => 'name','labelName' => 'Name','value' => ''.e(auth()->user()->name).'']]); ?>
<?php $component->withName('form.inputbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'name','labelName' => 'Name','value' => ''.e(auth()->user()->name).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.inputbox','data' => ['type' => 'email','name' => 'email','labelName' => 'Email','value' => ''.e(auth()->user()->email).'']]); ?>
<?php $component->withName('form.inputbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'email','name' => 'email','labelName' => 'Email','value' => ''.e(auth()->user()->email).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.inputbox','data' => ['type' => 'number','name' => 'mobile_no','labelName' => 'Mobile No','value' => ''.e(auth()->user()->mobile_no).'']]); ?>
<?php $component->withName('form.inputbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'number','name' => 'mobile_no','labelName' => 'Mobile No','value' => ''.e(auth()->user()->mobile_no).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                <div class="form-group">
                                    <div class="custom-control custom-radio custom-control-inline pl-0">
                                        Gender:
                                    </div>
                                    <div class="custom-control custom-radio custom-control-inline">
                                        <input type="radio" id="male" name="gender" <?php echo e(auth()->user()->gender == '1' ? 'checked' : ''); ?> value="1" class="custom-control-input">
                                        <label class="custom-control-label" for="male">Male</label>
                                    </div>
                                    <div class="custom-control custom-radio custom-control-inline">
                                        <input type="radio" id="female" name="gender" <?php echo e(auth()->user()->gender == '2' ? 'checked' : ''); ?> value="2" class="custom-control-input">
                                        <label class="custom-control-label" for="female">Female</label>
                                    </div>
                                    <div id="gender"></div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="image">Profile</label>
                                            <div class="px-0 text-center">
                                                <div id="image">

                                                </div>
                                            </div>
                                            <input type="hidden" name="old_avatar" id="old_avatar" value="<?php echo e(Auth::user()->avatar); ?>">
                                        </div>
                                    </div>
                                </div>
                            </form>

                            <div class="text-right">
                                <button type="button" class="btn btn-sm btn-primary rounded-0" id="save-profile" onclick="save_data('profile')"><span></span>Save Change</button>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="password" role="tabpanel" aria-labelledby="password-tab">
                            <form id="password-form" method="POST">
                                <?php echo csrf_field(); ?>
                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.inputbox','data' => ['type' => 'password','name' => 'current_password','labelName' => 'Current Password']]); ?>
<?php $component->withName('form.inputbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'password','name' => 'current_password','labelName' => 'Current Password']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.inputbox','data' => ['type' => 'password','name' => 'password','labelName' => 'Password']]); ?>
<?php $component->withName('form.inputbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'password','name' => 'password','labelName' => 'Password']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.inputbox','data' => ['type' => 'password','name' => 'password_confirmation','labelName' => 'Confirm Password']]); ?>
<?php $component->withName('form.inputbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'password','name' => 'password_confirmation','labelName' => 'Confirm Password']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </form>

                            <div class="text-right">
                                <button type="button" class="btn btn-sm btn-primary rounded-0" id="save-password" onclick="save_data('password')"><span></span>Save Change</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('/')); ?>js/spartan-multi-image-picker-min.js"></script>
    <script>
        $('#image').spartanMultiImagePicker({
            fieldName: 'image',
            maxCount: 1,
            rowHeight: '200px',
            groupClassName: 'col-md-12 com-sm-12 com-xs-12 pl-0',
            maxFileSize: '',
            dropFileLabel: 'Drop Here',
            allowExt: 'png|jpg|jpeg',
            onExtensionErr: function(index, file){
                Swal.fire({icon:'error',title:'Oops...',text: 'Only png,jpg,jpeg file format allowed!'});
            }
        });

        $('input[name="image"]').prop('required',true);
        $('.remove-files').on('click', function(){
            $(this).parents('.col-md-12').remove();
        });

        <?php if(Auth::user()->avatar): ?>
            $('#profile-form #image img.spartan_image_placeholder').css('display','none');
            $('#profile-form #image .spartan_remove_row').css('display','none');
            $('#profile-form #image .img_').css('display','block');
            $('#profile-form #image .img_').attr('src',"<?php echo e(asset('storage/'.USER_AVATAR_PATH.Auth::user()->avatar)); ?>");
        <?php endif; ?>

        function save_data(form_id){
            let form = document.getElementById(form_id+'-form');
            let formData = new FormData(form);
            let url;
            let id = $('#update_id').val();
            let method;
            if (form_id == 'profile') {
                url = '<?php echo e(route("app.profile.update")); ?>';
            } else if(form_id == 'password'){
                url = '<?php echo e(route("app.password.update")); ?>';
            }
            $.ajax({
                url: url,
                type: "POST",
                data: formData,
                dataType: "JSON",
                contentType: false,
                processData: false,
                cache: false,
                beforeSend: function(){
                    $('#save-'+form_id+' span').addClass('spinner-border spinner-border-sm text-light');
                },
                complete: function(){
                    $('#save-'+form_id+' span').removeClass('spinner-border spinner-border-sm text-light');
                },
                success: function (data) {
                    $('#'+form_id+'-form').find('.is-invalid').removeClass(
                        'is-invalid');
                    $('#'+form_id+'-form').find('.error').remove();
                    if (data.status == false) {
                        $.each(data.errors, function (key, value) {
                            $('#'+form_id+'-form input#' + key).addClass('is-invalid');
                            $('#'+form_id+'-form #' + key).parent().addClass('is-invalid');
                            if (key == 'password' || key == 'password_confirmation') {
                                $('#'+form_id+'-form #' + key).parents('.form-group').append(
                                    '<small class="error text-danger">' +
                                    value + '</small>');
                            } else {
                                $('#'+form_id+'-form #' + key).parent().append(
                                    '<small class="error text-danger">' +
                                    value + '</small>');
                            }
                        });
                    } else {
                        notification(data.status, data.message);
                        if (data.status == 'success') {
                            setInterval(() => {
                                window.location.reload();
                            }, 1000);
                        }
                    }

                },
                error: function (xhr, ajaxOption, thrownError) {
                    console.log(thrownError + '\r\n' + xhr.statusText + '\r\n' + xhr
                        .responseText);
                }
            });

        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lapland\resources\views/user/profile.blade.php ENDPATH**/ ?>