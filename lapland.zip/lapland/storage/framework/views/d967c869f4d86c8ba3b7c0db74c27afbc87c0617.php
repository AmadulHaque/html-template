<div class="form-group <?php echo e($groupClass ?? ''); ?>">
    <label for="<?php echo e($name); ?>" class="<?php echo e($required ?? ''); ?>"><?php echo e($labelName); ?></label>
    <textarea class="form-control form-control-sm <?php echo e($class ?? ''); ?>" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" placeholder="<?php echo e($placeholder ?? ''); ?>" rows="<?php echo e($rows ?? '3'); ?>"><?php echo e($value ?? ''); ?></textarea>
    <?php if(isset($error)): ?>
        <?php $__errorArgs = [$error];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger d-block"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\lapland\resources\views/components/form/textarea.blade.php ENDPATH**/ ?>