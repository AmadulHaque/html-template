
<?php $__env->startSection('site_title', $site_title); ?>
<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header py-2">
                <h4 class="mb-0 cd-title d-flex align-items-center justify-content-between"><?php echo e($title); ?>

                    <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'app.role.create')): ?>
                    <a href="<?php echo e(route('app.role.create')); ?>" type="button" class="btn btn-sm btn-primary rounded-0"><i class="fas fa-plus fa-sm"></i> Add Role</a>
                    <?php endif; ?>
                </h4>
            </div>
            <div class="card-body">
                <table class="table table-borderless w-100 table-sm table-hover table-striped" id="role-datatable">
                    <thead>
                        <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'app.role.bulk-delete')): ?>
                        <th>
                            <div class="form-checkbox">
                                <input type="checkbox" class="form-check-input" id="select_all" onclick="select_all()">
                                <label class="form-check-label" for="select_all"></label>
                            </div>
                        </th>
                        <?php endif; ?>
                        <th>SL</th>
                        <th>Name</th>
                        <th>Permission</th>
                        <th>Created by</th>
                        <th>Created at</th>
                        <?php if(Gate::allows('app.role.edit') || Gate::allows('app.role.delete')): ?>
                        <th class="text-right">Action</th>
                        <?php endif; ?>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        table = $('#role-datatable').DataTable({
            processing: true,
            serverSide: true,
            responsive: true,
            order: [], //Initial no order
            bInfo: true, //TO show the total number of data
            bFilter: false, //For datatable default search box show/hide
            ordering: false,
            lengthMenu: [
                [5, 10, 15, 25, 50, 100, -1],
                [5, 10, 15, 25, 50, 100, "All"]
            ],
            pageLength: 10, //number of data show per page
            ajax: {
                url: "<?php echo e(route('app.role.index')); ?>",
                type: "GET",
                dataType: "JSON",
                data: function(d) {
                    d._token = _token;
                    d.search_text = $('input[name="search_here"]').val();
                },
            },
            columns: [
                {data: 'bulk_check'},
                {data: 'DT_RowIndex'},
                {data: 'name'},
                {data: 'permission_count'},
                {data: 'created_by'},
                {data: 'created_at'},
                {data: 'action'}
            ],
            language: {
                processing: '<img src="<?php echo e(asset("img/table-loading.svg")); ?>">',
                emptyTable: '<strong class="text-danger">No Data Found</strong>',
                infoEmpty: '',
                zeroRecords: '<strong class="text-danger">No Data Found</strong>',
                oPaginate: {
                    sPrevious: "Previous", // This is the link to the previous page
                    sNext: "Next", // This is the link to the next page
                },
                lengthMenu: `<div class='d-flex align-items-center w-100 justify-content-between'>_MENU_
                        <button type='button' style='min-width: 110px;' class='btn btn-sm btn-danger d-none rounded-0 delete_btn ml-2 px-3' onclick='multi_delete()'>Bulk Delete</button>

                        <input name='search_here' class='form-control-s ml-2' placeholder="Name Search Here..." autocomplete="off"/>
                    </div>`,
            }
        });

    // single delete
    $(document).on('click', '.delete_data', function () {
        let id = $(this).data('id');
        let name = $(this).data('name');
        let row = table.row($(this).parent('tr'));
        let url = "<?php echo e(route('app.role.delete')); ?>";
        delete_data(id,url,row,name);
    });

    // multi delete
    function multi_delete(){
        let ids = [];
        let rows;
        $('.select_data:checked').each(function(){
            ids.push($(this).val());
            rows = table.rows($('.select_data:checked').parents('tr'));
        });

        if(ids.length == 0){
            Swal.fire({
                type:'error',
                title:'Error',
                text:'Please checked at least one row of table!',
                icon: 'warning',
            });
        }else{
            let url = "<?php echo e(route('app.role.bulk.delete')); ?>";
            bulk_delete(ids,url,rows);
        }
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lapland\resources\views/role/index.blade.php ENDPATH**/ ?>