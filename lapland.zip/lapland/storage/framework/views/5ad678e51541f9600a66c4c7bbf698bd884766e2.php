<?php $__env->startSection('site_title', $site_title); ?>
<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('styles'); ?>
        <style>
            input[type="file"] {
                display: block;
            }

            .imageThumb {
                max-height: 75px;
                border: 2px solid;
                padding: 1px;
                cursor: pointer;
            }

            .pip {
                display: inline-block;
                margin: 10px 10px 0 0;
            }

            .remove {
                display: block;
                background: #444;
                border: 1px solid black;
                color: white;
                text-align: center;
                cursor: pointer;
            }

            .remove:hover {
                background: white;
                color: black;
            }
        </style>
    <?php $__env->stopPush(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <form id="createTourForm" action="<?php echo e(route('app.tour.store')); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                           <div class="row">
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="is_bokun" class="required">Is Bokun Tour</label>
                                    <select class="form-control  <?php $__errorArgs = ['is_bokun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bokunSelect"
                                        name="is_bokun">
                                        <option value="2" <?php echo e(old('is_bokun') == '2' ? 'selected' : ''); ?>>OFF</option>
                                        <option value="1" <?php echo e(old('is_bokun') == '1' ? 'selected' : ''); ?>>ON</option>
                                    </select>
                                    <?php $__errorArgs = ['is_bokun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                           </div>

                            <div class="form-group" id="bokunDiv" style="display: none;">
                                <label for="bokun_code" class="required">Bokun Code</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['bokun_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="bokun_code" name="bokun_code" value="<?php echo e(old('bokun_code')); ?>">
                            <?php $__errorArgs = ['tour_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                   

                        <div class="form-group">
                            <label for="title" class=" required">Tour Title</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="title" name="title" value="<?php echo e(old('title')); ?>">
                            <?php $__errorArgs = ['tour_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="tour_category_id" class="required">Tour Category</label><br>
                                    <select class="form-control select2 <?php $__errorArgs = ['tour_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="tour_category_id" name="tour_category_id">
                                        <option value="">Select a Category</option>
                                        <?php $__currentLoopData = $tourCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tourCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tourCategory->id); ?>"
                                                <?php echo e(old('tour_category_id') == $tourCategory->id ? 'selected' : ''); ?>>
                                                <?php echo e($tourCategory->title); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['tour_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="start_date_time" class="required">Start Date and Time</label>
                                    <input type="datetime-local"
                                        class="form-control <?php $__errorArgs = ['start_date_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="start_date_time" name="start_date_time" value="<?php echo e(old('start_date_time')); ?>">
                                    <?php $__errorArgs = ['start_date_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="end_date_time" class="required">End Date and Time</label>
                                    <input type="datetime-local"
                                        class="form-control <?php $__errorArgs = ['end_date_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="end_date_time" name="end_date_time" value="<?php echo e(old('end_date_time')); ?>">
                                    <?php $__errorArgs = ['end_date_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="thumbnail_images" class="required">Thumbnail Images</label>
                            <input type="file" class="form-control-file <?php $__errorArgs = ['thumbnail_images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="thumbnail_images" name="thumbnail_images[]" multiple>
                            <small class="form-text text-muted">(Max 10 images, Max Size Per file: 5MB)</small>
                            <?php $__errorArgs = ['thumbnail_images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group">
                            <label for="banner_images" class="required">Banner Image</label>
                            <input type="file" class="form-control-file <?php $__errorArgs = ['banner_images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="banner_images" name="banner_images[]" multiple>
                            <small class="form-text text-muted">(Max Size 5MB)</small>
                            <?php $__errorArgs = ['banner_images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group">
                            <label for="tour_location" class="required">Tour Location</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['tour_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="tour_location" name="tour_location" value="<?php echo e(old('tour_location')); ?>">
                            <?php $__errorArgs = ['tour_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group">
                            <label for="time_slot_ids" class="required">Time Slots</label>

                            <select class="form-control select2 <?php $__errorArgs = ['time_slot_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="time_slot_ids" name="time_slot_ids[]" multiple>
                                <?php $__currentLoopData = $timeSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeSlot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($timeSlot->id); ?>" <?php echo e(in_array($timeSlot->id, old('time_slot_ids', [])) ? 'selected' : ''); ?>>
                                        <?php echo e($timeSlot->title); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['time_slot_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="row">
                            <div class="col-md-3 border border-info  ">
                                <div class="form-group">
                                    <label for="adult" class="required">Adult</label>
                                    <select class="form-control select-toggle <?php $__errorArgs = ['adult'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="adult"
                                        name="adult">
                                        <option value="1" <?php echo e(old('adult') == '1' ? 'selected' : ''); ?>>ON</option>
                                        <option value="2" <?php echo e(old('adult') == '2' ? 'selected' : ''); ?>>OFF</option>
                                    </select>
                                    <?php $__errorArgs = ['adult'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="default_adult_quantity">Default Adult Quantity</label>
                                    <input type="number"
                                        class="form-control <?php $__errorArgs = ['default_adult_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="default_adult_quantity" name="default_adult_quantity"
                                        value="<?php echo e(old('default_adult_quantity')); ?>">
                                    <?php $__errorArgs = ['default_adult_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="extra_adult_price" class="required">Extra Adult Price</label>
                                    <input type="number"
                                        class="form-control <?php $__errorArgs = ['extra_adult_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="extra_adult_price" name="extra_adult_price"
                                        value="<?php echo e(old('extra_adult_price')); ?>">
                                    <?php $__errorArgs = ['extra_adult_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="max_adult_allowed" class="required">Max Adult Allowed</label>
                                    <input type="number"
                                        class="form-control <?php $__errorArgs = ['max_adult_allowed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="max_adult_allowed" name="max_adult_allowed"
                                        value="<?php echo e(old('max_adult_allowed')); ?>">
                                    <?php $__errorArgs = ['max_adult_allowed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>
                            <div class="col-md-3 border border-info ">
                                <div class="form-group">
                                    <label for="children" class="required">Children</label>
                                    <select class="form-control select-toggle <?php $__errorArgs = ['children'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="children"
                                        name="children">
                                        <option value="1" <?php echo e(old('children') == '1' ? 'selected' : ''); ?>>ON</option>
                                        <option value="2" <?php echo e(old('children') == '2' ? 'selected' : ''); ?>>OFF</option>
                                    </select>
                                    <?php $__errorArgs = ['children'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="default_children_quantity">Default Children Quantity</label>
                                    <input type="number"
                                        class="form-control <?php $__errorArgs = ['default_children_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="default_children_quantity" name="default_children_quantity"
                                        value="<?php echo e(old('default_children_quantity')); ?>">
                                    <?php $__errorArgs = ['default_children_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="extra_children_price" class="required">Extra Children Price</label>
                                    <input type="number"
                                        class="form-control <?php $__errorArgs = ['extra_children_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="extra_children_price" name="extra_children_price"
                                        value="<?php echo e(old('extra_children_price')); ?>">
                                    <?php $__errorArgs = ['extra_children_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="max_children_allowed" class="required">Max Children Allowed</label>
                                    <input type="number"
                                        class="form-control <?php $__errorArgs = ['max_children_allowed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="max_children_allowed" name="max_children_allowed"
                                        value="<?php echo e(old('max_children_allowed')); ?>">
                                    <?php $__errorArgs = ['max_children_allowed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3 border border-info ">
                                <div class="form-group">
                                    <label for="infant" class="required">Infant</label>
                                    <select class="form-control select-toggle <?php $__errorArgs = ['infant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="infant"
                                        name="infant">
                                        <option value="1" <?php echo e(old('infant') == '1' ? 'selected' : ''); ?>>ON</option>
                                        <option value="2" <?php echo e(old('infant') == '2' ? 'selected' : ''); ?>>OFF</option>
                                    </select>
                                    <?php $__errorArgs = ['infant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="default_infant_quantity">Default Infant Quantity</label>
                                    <input type="number"
                                        class="form-control <?php $__errorArgs = ['default_infant_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="default_infant_quantity" name="default_infant_quantity"
                                        value="<?php echo e(old('default_infant_quantity')); ?>">
                                    <?php $__errorArgs = ['default_infant_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="extra_infant_price" class="required">Extra Infant Price</label>
                                    <input type="number"
                                        class="form-control <?php $__errorArgs = ['extra_infant_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="extra_infant_price" name="extra_infant_price"
                                        value="<?php echo e(old('extra_infant_price')); ?>">
                                    <?php $__errorArgs = ['extra_infant_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="max_infant_allowed" class="required">Max Infant Allowed</label>
                                    <input type="number"
                                        class="form-control <?php $__errorArgs = ['max_infant_allowed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="max_infant_allowed" name="max_infant_allowed"
                                        value="<?php echo e(old('max_infant_allowed')); ?>">
                                    <?php $__errorArgs = ['max_infant_allowed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3 border border-info ">
                                <div class="form-group">
                                    <label for="pet" class="required">Pet</label>
                                    <select class="form-control select-toggle <?php $__errorArgs = ['pet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pet"
                                        name="pet">
                                        <option value="1" <?php echo e(old('pet') == '1' ? 'selected' : ''); ?>>ON</option>
                                        <option value="2" <?php echo e(old('pet') == '2' ? 'selected' : ''); ?>>OFF</option>
                                    </select>
                                    <?php $__errorArgs = ['pet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="default_pet_quantity">Default Pet Quantity</label>
                                    <input type="number"
                                        class="form-control <?php $__errorArgs = ['default_pet_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="default_pet_quantity" name="default_pet_quantity"
                                        value="<?php echo e(old('default_pet_quantity')); ?>">
                                    <?php $__errorArgs = ['default_pet_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="extra_pet_price" class="required">Extra Pet Price</label>
                                    <input type="number"
                                        class="form-control <?php $__errorArgs = ['extra_pet_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="extra_pet_price" name="extra_pet_price"
                                        value="<?php echo e(old('extra_pet_price')); ?>">
                                    <?php $__errorArgs = ['extra_pet_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="max_pet_allowed" class="required">Max Pet Allowed</label>
                                    <input type="number"
                                        class="form-control <?php $__errorArgs = ['max_pet_allowed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="max_pet_allowed" name="max_pet_allowed"
                                        value="<?php echo e(old('max_pet_allowed')); ?>">
                                    <?php $__errorArgs = ['max_pet_allowed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>
                        </div>

                        <div class="form-group">
                            <label for="tour_base_price" class="required">Tour Base Price</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['tour_base_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tour_base_price" name="tour_base_price" value="<?php echo e(old('tour_base_price')); ?>">
                            <?php $__errorArgs = ['tour_base_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea class="form-control summernote <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="description" name="description"><?php echo e(old('description')); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="youtube_video_link">YouTube Video Link</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['youtube_video_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="youtube_video_link" name="youtube_video_link"
                                value="<?php echo e(old('youtube_video_link')); ?>">
                            <?php $__errorArgs = ['youtube_video_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
       
                        <div class="form-group">
                            <label for="tour_include_ids" class="required">Tour Include</label>
                            <select class="form-control select2 <?php $__errorArgs = ['tour_include_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="tour_include_ids" name="tour_include_ids[]" multiple>
                      
                                <?php $__currentLoopData = $tourIncludes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tourInclude): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tourInclude->id); ?>" <?php echo e(in_array($tourInclude->id, old('tour_include_ids', [])) ? 'selected' : ''); ?>><?php echo e($tourInclude->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['tour_include_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="faq_ids" class="required">FAQs</label>
                            <select class="form-control select2 <?php $__errorArgs = ['faq_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="faq_ids" name="faq_ids[]" multiple>
                                <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($faq->id); ?>" <?php echo e(in_array($faq->id, old('faq_ids', [])) ? 'selected' : ''); ?>>
                                        <?php echo e($faq->question); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['faq_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                            
                        <div class="form-group">
                            <label for="booking_in_advanced">Booking in Advanced</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['booking_in_advanced'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="booking_in_advanced" name="booking_in_advanced"
                                value="<?php echo e(old('booking_in_advanced')); ?>">
                            <?php $__errorArgs = ['booking_in_advanced'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="contact_meeting">Contact Meeting</label>
                            <textarea class="form-control summernote <?php $__errorArgs = ['contact_meeting'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="contact_meeting"
                                name="contact_meeting"><?php echo e(old('contact_meeting')); ?></textarea>
                            <?php $__errorArgs = ['contact_meeting'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="pick_up">Pick Up</label>
                            <textarea class="form-control summernote <?php $__errorArgs = ['pick_up'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pick_up" name="pick_up"><?php echo e(old('pick_up')); ?></textarea>
                            <?php $__errorArgs = ['pick_up'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="map_link" class="required">Map Link</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['map_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="map_link" name="map_link" value="<?php echo e(old('map_link')); ?>">
                            <?php $__errorArgs = ['map_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="change_date_policy">Change Date Policy</label>
                                    <select class="form-control <?php $__errorArgs = ['change_date_policy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="change_date_policy" name="change_date_policy">
                                        <option value="1" <?php echo e(old('change_date_policy') == '1' ? 'selected' : ''); ?>>YES
                                        </option>
                                        <option value="2" <?php echo e(old('change_date_policy') == '2' ? 'selected' : ''); ?>>NO
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['change_date_policy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="status" class="required">Status</label>
                                    <select class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status"
                                        name="status">
                                        <option value="1" <?php echo e(old('status') == '1' ? 'selected' : ''); ?>>Active</option>
                                        <option value="2" <?php echo e(old('status') == '2' ? 'selected' : ''); ?>>Inactive</option>
                                    </select>
                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        

                        <div class="form-group text-center">
                            <button type="submit" class="btn btn-info btn-sm">Create Tour</button>
                        </div>
                    </form>
                
                <script type="text/javascript" src="https://widgets.bokun.io/assets/javascripts/apps/build/BokunWidgetsLoader.js?bookingChannelUUID=b278aba1-ee65-4bed-b8c9-fa10df9f3e62" async></script>
                    <style> #bokun_e0c2f868_4e39_4cee_86ef_f7b5b97df6fd { display: inline-block; padding: 10px 20px; background: #408C3D; border-radius: 5px; box-shadow: none; font-weight: 600; font-size: 16px; text-decoration: none; text-align: center; color: #FFFFFF; border:none; cursor: pointer; transition: background .2s ease; } #bokun_e0c2f868_4e39_4cee_86ef_f7b5b97df6fd:hover{ background: #285726; } #bokun_e0c2f868_4e39_4cee_86ef_f7b5b97df6fd:active{ background: #30682e; } </style> <button class="bokunButton" disabled id=bokun_e0c2f868_4e39_4cee_86ef_f7b5b97df6fd data-src="https://widgets.bokun.io/online-sales/b278aba1-ee65-4bed-b8c9-fa10df9f3e62/experience/801980?partialView=1" data-testid="widget-book-button" > Book now </button> 
                

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('/')); ?>js/spartan-multi-image-picker-min.js"></script>
    <script>
        //Thumbnail Images
        $(document).ready(function() {
            if (window.File && window.FileList && window.FileReader) {
                $("#thumbnail_images").on("change", function(e) {
                    var files = e.target.files,
                        filesLength = files.length;

                    var maxFileSize = 5120;
                    var maxFileLimit = 10;
                    for (var i = 0; i < filesLength; i++) {
                        var f = files[i];
                        var fileSize = f.size / 1024;
                        if (fileSize > maxFileSize) {
                            $(this).val('');
                            alert("File size exceeds the limit of 5MB.");
                            continue;
                        }

                        if (filesLength >= maxFileLimit) {
                            $(this).val('');
                            alert("You can only upload a maximum of 10 files.");
                            break;
                        }

                        var fileReader = new FileReader();
                        fileReader.onload = (function(e) {
                            var file = e.target;
                            $("<span class=\"pip\">" +
                                "<img class=\"imageThumb\" src=\"" + e.target.result +
                                "\" title=\"" + file.name + "\"/>" +
                                "<br/><span class=\"remove\">Remove image</span>" +
                                "</span>").insertAfter("#thumbnail_images");
                            $(".remove").click(function() {
                                $(this).parent(".pip").remove();
                            });
                        });
                        fileReader.readAsDataURL(f);
                    }
                    console.log(files);
                });
            } else {
                alert("Your browser doesn't support to File API")
            }
        });

        //Banner Image
        $(document).ready(function() {
            if (window.File && window.FileList && window.FileReader) {
                $("#banner_images").on("change", function(e) {
                    var files = e.target.files,
                        filesLength = files.length;

                    var maxFileSize = 5120;
                    var maxFileLimit = 10;
                    for (var i = 0; i < filesLength; i++) {
                        var f = files[i];
                        var fileSize = f.size / 1024;
                        if (fileSize > maxFileSize) {
                            $(this).val('');
                            alert("File size exceeds the limit of 5MB.");
                            continue;
                        }

                        if (filesLength >= maxFileLimit) {
                            $(this).val('');
                            alert("You can only upload a maximum of 1 file.");
                            break;
                        }

                        var fileReader = new FileReader();
                        fileReader.onload = (function(e) {
                            var file = e.target;
                            $("<span class=\"pip\">" +
                                "<img class=\"imageThumb\" src=\"" + e.target.result +
                                "\" title=\"" + file.name + "\"/>" +
                                "<br/><span class=\"remove\">Remove image</span>" +
                                "</span>").insertAfter("#banner_images");
                            $(".remove").click(function() {
                                $(this).parent(".pip").remove();
                            });
                        });
                        fileReader.readAsDataURL(f);
                    }
                    console.log(files);
                });
            } else {
                alert("Your browser doesn't support to File API")
            }
        });

        //Thumbnail Video

        $(document).ready(function() {
            if (window.File && window.FileList && window.FileReader) {
                $("#video").on("change", function(e) {
                    var video = e.target.files[0];

                    // Set maximum file size in bytes (10MB)
                    var maxFileSize = 10 * 1024 * 1024;

                    if (video) {
                        var fileSize = video.size;

                        if (fileSize > maxFileSize) {
                            alert("Video size exceeds the limit of 10MB.");
                            $(this).val('');
                            return;
                        }

                        var videoType = video.type.split('/')[0]; // Get the video type (e.g., "video")

                        if (videoType !== 'video') {
                            alert("Please select a valid video file.");
                            $(this).val('');
                            return;
                        }

                        var videoURL = URL.createObjectURL(video);
                        $("#video-preview").attr("src", videoURL).show();
                    }
                });
            } else {
                alert("Your browser doesn't support the File API");
            }
        });

        //Search Reloevant Tours
        // const $searchSelect = $('#searchSelect');

        // $searchSelect.select2({
        //     placeholder: 'Search',
        //     minimumInputLength: 2,
        //     ajax: {
        //         url: 'url',
        //         dataType: 'json',
        //         delay: 250,
        //         data: function(params) {
        //             return {
        //                 query: params.term
        //             };
        //         },
        //         processResults: function(data) {
        //             return {
        //                 results: data.map(item => ({
        //                     id: item.id,
        //                     text: item.value
        //                 }))
        //             };
        //         }
        //     }
        // });

        // $searchSelect.on('select2:open', function() {
        //     $searchSelect.select2('close');
        // });

        // $searchSelect.on('select2:select', function(e) {
        //     const selectedData = e.params.data;
        //     console.log('Selected ID:', selectedData.id);
        //     console.log('Selected Text:', selectedData.text);
        // });

        //SummerNote
        $(function() {
            $('.summernote').summernote({
                height: 280,
            });

        });

        //Select2
        $(document).ready(function() {
            $('.select2').select2();
        });


        //is bokun or not
        $('#bokunSelect').change(function () {
        var selectedOption = $(this).val();

        if (selectedOption === '1') {
            $('#bokunDiv').show();
        } else {
            $('#bokunDiv').hide();
        }
    });
    </script>
    <script>
        $(document).ready(function() {
            $('.select-toggle').change(function() {
                var selectedValue = $(this).val();
        
                var parentColumn = $(this).closest('.col-md-3');
                parentColumn.find('.form-group:not(:first)').toggle(selectedValue === '1'); 
            });
        
            $('.select-toggle').trigger('change');
        });
        </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lapland\resources\views/tour/create.blade.php ENDPATH**/ ?>