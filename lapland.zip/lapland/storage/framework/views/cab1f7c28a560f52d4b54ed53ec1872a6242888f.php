
<?php $__env->startSection('main_content'); ?>
            <!-- Banner Start -->
            <div class="banner-area py-40">
                <div class="container-xl">
                    <div class="row">
                        <div class="col-12">
                        <h3>Latest Tours of: <?php echo e($category->title); ?></h3>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Banner End -->
    
            <!-- Popular Area Start -->
            <section class="popular-area">
    
            </section>
            <!-- Popular Area End -->
    
            <!-- Tour Area Start -->
            <section class="tour-area py-40">
                <div class="container-xl">
                    <div class="row g-4">
                        <?php $__empty_1 = true; $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        
                        <div class="col-md-4">
                            <div class="tour-slider-row owl-carousel">
                                <?php $__currentLoopData = json_decode($tour->thumbnail_images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thumbnail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(uploaded_asset($thumbnail)); ?>" alt="">
                                </div>   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <div class="tour-content">
                                <span><?php echo e($tour->tour_location); ?></span>
                                <a  href="<?php echo e(route('tour.show',$tour->slug)); ?>" target="_blank">
                                    <h2><?php echo e($tour->title); ?></h2>
                                </a>
                                <p><strong><i class="fas fa-euro-sign"></i> <?php echo e($tour->tour_base_price); ?></strong> <?php echo e($tour->default_adult_quantity + $tour->default_children_quantity + $tour->default_infant_quantity); ?> persons</p>
                            </div>
                        </div>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h4>No Auction Found</h4>
                        <?php endif; ?>
                        
          
                    </div>
                </div>
            </section>
            <!-- Tour Area End -->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lapland\resources\views/frontend/tour_category/index.blade.php ENDPATH**/ ?>