<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- Title -->
    <title>Travel</title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(uploaded_asset(config('settings.site_favicon')) ?? null); ?>">

    <!-- Fontawesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <!-- Owl Carousel -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/owl.theme.default.min.css">
    <!-- stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/responsive.css">
    <?php echo $__env->yieldContent('extra_css'); ?>
</head>

<body>

    <!-- Header Start -->
    <header>
        <div class="container-xl">
            <!-- Header Top -->
            <?php echo $__env->make('frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Navbar -->
            <?php echo $__env->make('frontend.include.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </header>
    <!-- Header End -->

    <!-- Main Content Start -->
    <main>
        <?php echo $__env->yieldContent('main_content'); ?>
    </main>
    <!-- Main Content End -->

    <!-- Footer Start -->
    <footer>
        <div class="container-xl">
            <div class="row">
                <div class="col-12">
                    <div class="footer-top">
                        <div class="row">
                            <div class="col-md-8 col-12 mx-auto">

                            </div>
                        </div>
                    </div>
                    <div class="copyright">
                        <div class="row">
                            <div class="col-md-6">

                            </div>
                            <div class="col-md-6">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer End -->

    <!--Jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Owl Carousel -->
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/owl.carousel.min.js"></script>
    <!-- Main JS -->
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/main.js"></script>
    <?php echo $__env->yieldContent('extra_js'); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\lapland\resources\views/frontend/master.blade.php ENDPATH**/ ?>