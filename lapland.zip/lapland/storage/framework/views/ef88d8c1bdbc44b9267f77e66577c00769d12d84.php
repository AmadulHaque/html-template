<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('app.dashboard')); ?>" class="brand-link">
        <img src="<?php echo e(asset('/')); ?>img/AdminLTELogo.png" alt="Logo" class="brand-image img-circle elevation-3"
            style="opacity: .8">
        <span class="brand-text font-weight-light">Visit Lapland
        </span>
    </a>
    <!-- Sidebar -->
    <div class="sidebar px-0">

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                data-accordion="false">
                <li class="nav-item">
                    <a href="<?php echo e(route('app.dashboard')); ?>" class="nav-link <?php echo e(request()->is('/') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-home">
                        </i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <?php if(Gate::allows('app.role.index') || Gate::allows('app.user.index')): ?>
                <li class="nav-item <?php echo e(request()->is('role*') || request()->is('user*') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link <?php echo e(request()->is('role*') || request()->is('user*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-th-list"></i>
                        <p>
                            Administration
                            <i class="right fas fa-angle-left fa-sm"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'app.role.index')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('app.role.index')); ?>" class="nav-link <?php echo e(request()->is('role*') ? 'active' : ''); ?>">
                                <p>Role & Permissions</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'app.user.index')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('app.user.index')); ?>" class="nav-link <?php echo e(request()->is('user*') ? 'active' : ''); ?>">
                                <p>Users</p>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>
                
                <li class="nav-item <?php echo e(request()->is('blog*') || request()->is('blog.category*') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link <?php echo e(request()->is('blog*') || request()->is('blog.category*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-th-list"></i>
                        <p>
                            Blogs Management
                            <i class="right fas fa-angle-left fa-sm"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'app.role.index')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('app.blog.index')); ?>" class="nav-link <?php echo e(request()->is('blog*') ? 'active' : ''); ?>">
                                <p>Blogs</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'app.user.index')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('app.blog.category.index')); ?>" class="nav-link  <?php echo e(request()->is('blog.category*') ? 'active' : ''); ?>">
                                <p>Blog Categories</p>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>
                

                
                <li class="nav-item <?php echo e(request()->is('tour*') || request()->is('tour*') || request()->is('faq*') || request()->is('time-slot*')|| request()->is('tour-include*') ? 'menu-open'  : ''); ?>">
                    <a href="#" class="nav-link <?php echo e(request()->is('tour*') || request()->is('tour.category*') || request()->is('faq*') || request()->is('time-slot*')|| request()->is('tour-include*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-th-list"></i>
                        <p>
                            Tour Management
                            <i class="right fas fa-angle-left fa-sm"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'app.role.index')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('app.tour.index')); ?>" class="nav-link <?php echo e(request()->is('tour*') ? 'active' : ''); ?>">
                                <p>Tours</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'app.user.index')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('app.tour.category.index')); ?>" class="nav-link  <?php echo e(request()->is('tour*') ? 'active' : ''); ?>">
                                <p>Tour Categories</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'app.user.index')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('app.faq.index')); ?>" class="nav-link  <?php echo e(request()->is('faq*') ? 'active' : ''); ?>">
                                <p>Faqs</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'app.user.index')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('app.time-slot.index')); ?>" class="nav-link  <?php echo e(request()->is('time-slot*') ? 'active' : ''); ?>">
                                <p>Time Slots</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'app.user.index')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('app.tour-include.index')); ?>" class="nav-link  <?php echo e(request()->is('tour-include*') ? 'active' : ''); ?>">
                                <p>Tour Includes</p>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>
                

                    
                    <li class="nav-item <?php echo e(request()->is('app.payment*') || request()->is('app.payment*') ? 'menu-open' : ''); ?>">
                        <a href="#" class="nav-link <?php echo e(request()->is('app.payment*') || request()->is('app.payment*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-th-list"></i>
                            <p>
                                Payment Management
                                <i class="right fas fa-angle-left fa-sm"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'app.role.index')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('app.payment.index')); ?>" class="nav-link <?php echo e(request()->is('app.payment*') ? 'active' : ''); ?>">
                                    <p>Payments</p>
                                </a>
                            </li>
                            <?php endif; ?> 
                        </ul>
                    </li>
                    

                          
                          <li class="nav-item <?php echo e(request()->is('app.booking*') || request()->is('app.booking*') ? 'menu-open' : ''); ?>">
                            <a href="#" class="nav-link <?php echo e(request()->is('app.booking*') || request()->is('app.booking*') ? 'active' : ''); ?>">
                                <i class="nav-icon fas fa-th-list"></i>
                                <p>
                                    Bookings
                                    <i class="right fas fa-angle-left fa-sm"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                                <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'app.role.index')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('app.booking.index')); ?>" class="nav-link <?php echo e(request()->is('app.booking*') ? 'active' : ''); ?>">
                                        <p>All Bookings</p>
                                    </a>
                                </li>
                                <?php endif; ?> 
                            </ul>
                        </li>
                        

                          
                          <li class="nav-item <?php echo e(request()->routeIs('app.setting.index') ? 'menu-open' : ''); ?>">
                            <a href="#" class="nav-link <?php echo e(request()->routeIs('app.setting.index') ? 'active' : ''); ?>">
                                <i class="nav-icon fas fa-th-list"></i>
                                <p>
                                    Settings
                                    <i class="right fas fa-angle-left fa-sm"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                                <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'app.role.index')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('app.setting.index')); ?>" class="nav-link <?php echo e(request()->routeIs('app.setting.index') ? 'active' : ''); ?>">
                                        <p>All Settings</p>
                                    </a>
                                </li>
                                <?php endif; ?> 
                            </ul>
                        </li>
                        
                        
                        
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\laragon\www\lapland\resources\views/include/sidebar.blade.php ENDPATH**/ ?>