
<?php $__env->startSection('main_content'); ?>
      
    <style>
     .tour-details-banner img {
    display: block;
    width: 1500px;
    height: 460px;
   
}
.slider-form {
    width: 540px;
    height: 404px;
    position: absolute;
    top: 174px;
    right: 0; 
    padding: 20px 24px 20px 24px;
    border-radius: 20px;
    gap: 24px;
    background: red;
}

    </style>
            <!-- Popular Area Start -->
            <section class="popular-area">
    
            </section>
            <!-- Popular Area End -->
    
            <!-- Tour Area Start -->
            <section class=" py-40 h-1">
                <div class="container-xl">
                    <div class="row">
                        <div class="col-md-12" style=" position: relative;">
                            <div class="tour-slider-row owl-carousel tour-details-banner ">
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                            </div>
                            
                        </div>
                
                    </div>
                    <div class="slider-form">

                </div>
                </div>
            </section>
            <!-- Tour Area End -->
    
            <!-- Tour Tab Area Start -->
            <section class="tour-tab-area py-40">
                <div class="container-xl">
                    <div class="row">
                        <div class="col-12">
                            <div class="tour-tab-row p-3">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="tour-tab-slider owl-carousel">
                                            <div class="tour-slider-box position-relative">
                                                <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/Inspiration-card.png" alt="">
                                                <div class="tour-tab-content position-absolute">
                                                    <span>Rovaniemi</span>
                                                    <h2>Ice Swimming and Sauna Experience (Winter)</h2>
                                                </div>
                                            </div>
                                            <div class="tour-slider-box position-relative">
                                                <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/Inspiration-card.png" alt="">
                                                <div class="tour-tab-content position-absolute">
                                                    <span>Rovaniemi</span>
                                                    <h2>Ice Swimming and Sauna Experience (Winter)</h2>
                                                </div>
                                            </div>
                                            <div class="tour-slider-box position-relative">
                                                <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/Inspiration-card.png" alt="">
                                                <div class="tour-tab-content position-absolute">
                                                    <span>Rovaniemi</span>
                                                    <h2>Ice Swimming and Sauna Experience (Winter)</h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="tour-tab">
                                            <nav>
                                                <div class="nav nav-tabs border-0" id="nav-tab" role="tablist">
                                                  <button class="nav-link active" id="family-travel-tab" data-bs-toggle="tab" data-bs-target="#family-travel" type="button" role="tab" aria-controls="family-travel" aria-selected="true">Family Travel</button>
    
                                                  <button class="nav-link" id="treat-ourselve-tab" data-bs-toggle="tab" data-bs-target="#treat-ourselve" type="button" role="tab" aria-controls="treat-ourselve" aria-selected="false">Treat Ourselves</button>
    
                                                  <button class="nav-link" id="go-adventure-tab" data-bs-toggle="tab" data-bs-target="#go-adventure" type="button" role="tab" aria-controls="go-adventure" aria-selected="false">Go Adventure</button>
                                                </div>
                                              </nav>
                                              <div class="tab-content mt-4" id="nav-tabContent">
                                                <div class="tab-pane fade show active" id="family-travel" role="tabpanel" aria-labelledby="family-travel-tab" tabindex="0">
                                                    <div class="tour-tab-box p-3">
                                                        <div class="row g-3">
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
    
                                                <div class="tab-pane fade" id="treat-ourselve" role="tabpanel" aria-labelledby="treat-ourselve-tab" tabindex="0">
                                                    <div class="tour-tab-box p-3">
                                                        <div class="row g-3">
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
    
                                                <div class="tab-pane fade" id="go-adventure" role="tabpanel" aria-labelledby="go-adventure-tab" tabindex="0">
                                                    <div class="tour-tab-box p-3">
                                                        <div class="row g-3">
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="tour-tab-item">
                                                                    <div class="tour-image float-start me-2">
                                                                        <img class="h-100 rounded-default" src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                                                    </div>
                                                                    <div class="tour-tab-item-content">
                                                                        <span>Rovaniemi</span>
                                                                        <h2>Ice Swimming and Sauna Experience (Winter Swimming)</h2>
                                                                        <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                              </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Tour Tab Area End -->
    
            <!-- Tour Area Start -->
            <section class=" py-40">
                <div class="container-xl">
                    <div class="row g-4">
                        <div class="col-md-4">
                            <div class="tour-slider-row owl-carousel">
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                            </div>
                            <div class="tour-content">
                                <span>Rovaniemi</span>
                                <h2>Ice Swimming and Sauna Experience (Winter)</h2>
                                <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="tour-slider-row owl-carousel">
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                            </div>
                            <div class="tour-content">
                                <span>Rovaniemi</span>
                                <h2>Ice Swimming and Sauna Experience (Winter)</h2>
                                <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="tour-slider-row owl-carousel">
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                            </div>
                            <div class="tour-content">
                                <span>Rovaniemi</span>
                                <h2>Ice Swimming and Sauna Experience (Winter)</h2>
                                <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="tour-slider-row owl-carousel">
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                            </div>
                            <div class="tour-content">
                                <span>Rovaniemi</span>
                                <h2>Ice Swimming and Sauna Experience (Winter)</h2>
                                <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="tour-slider-row owl-carousel">
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                            </div>
                            <div class="tour-content">
                                <span>Rovaniemi</span>
                                <h2>Ice Swimming and Sauna Experience (Winter)</h2>
                                <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="tour-slider-row owl-carousel">
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                            </div>
                            <div class="tour-content">
                                <span>Rovaniemi</span>
                                <h2>Ice Swimming and Sauna Experience (Winter)</h2>
                                <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="tour-slider-row owl-carousel">
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                            </div>
                            <div class="tour-content">
                                <span>Rovaniemi</span>
                                <h2>Ice Swimming and Sauna Experience (Winter)</h2>
                                <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="tour-slider-row owl-carousel">
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                            </div>
                            <div class="tour-content">
                                <span>Rovaniemi</span>
                                <h2>Ice Swimming and Sauna Experience (Winter)</h2>
                                <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="tour-slider-row owl-carousel">
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                                <div class="tour-slider-box">
                                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/slider/slider.jpg" alt="">
                                </div>
                            </div>
                            <div class="tour-content">
                                <span>Rovaniemi</span>
                                <h2>Ice Swimming and Sauna Experience (Winter)</h2>
                                <p><strong><i class="fas fa-euro-sign"></i> 500</strong> 4 persons</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Tour Area End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lapland\resources\views/frontend/tour/details.blade.php ENDPATH**/ ?>