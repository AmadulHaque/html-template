<div class="main-navbar">
    <div class="row">
        <div class="col-12">
            <nav>
                <ul class="d-flex">
                    <li>
                        <a href="<?php echo e(route('home')); ?>">
                            <img src="<?php echo e(uploaded_asset(config('settings.site_logo'))); ?>" alt="">
                            <span>All</span>
                        </a>
                    </li>
                    <?php $__currentLoopData = $tourCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tourCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('tour.category.show',$tourCategory->slug)); ?>">
                            <img src="<?php echo e(uploaded_asset($tourCategory->image)); ?>" alt="">
                            <span><?php echo e($tourCategory->title); ?></span>
                        </a>
                    </li> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                   
                </ul>
            </nav>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\lapland\resources\views/frontend/include/navbar.blade.php ENDPATH**/ ?>