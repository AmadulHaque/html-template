<div class="header-top" style="color: red">
    <div class="row" >
        <div class="col-md-6">
            <div class="header-left d-flex align-items-center">
                <button type="button" class="menu-bar-btn"><i class="fas fa-ellipsis-v"></i></button>
                <div class="logo-area">
                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/logo/logo.png" alt="logo">
                </div>
                <div class="action-btn">
                    <a href="" class="book-btn active">Book</a>
                    <a href="" class="inspiration-btn">Inspiration</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="travel-plan-btn text-end">
                <?php if(auth()->guard()->check()): ?>
                <a href="" class="plan-btn">
                    <img src="<?php echo e(asset('frontend')); ?>/assets/img/icon/add-to-basket.png" class="mr-2" alt="">
                    <span>Travel Plan</span>
                    <span class="btn-badge-circle rounded-circle primary-bg text-light">2</span> 
                </a>
               <span class="text-dark">
                | Welcome <?php echo e(auth()->user()->name); ?> |
               </span>
                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();" >
                        <i class="fas fa-sign-out-alt mr-1 text-secondary fa-sm"></i> Logout
                    </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" class="d-none" method="POST">
                    <?php echo csrf_field(); ?>
                </form>
                   <?php else: ?>
                   <div class="action-btn">
                    <a href="<?php echo e(route('login')); ?>" class="book-btn active">Login</a>
                </div> 
                <?php endif; ?>
                
              
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\lapland\resources\views/frontend/include/header.blade.php ENDPATH**/ ?>