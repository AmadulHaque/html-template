<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    </head>
    <body>

        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">Make a Payment</div>
        
                        <div class="card-body">
                            <form action="<?php echo e(route('app.payment.process-payment')); ?>" method="POST" id="payment-form">
                                <?php echo csrf_field(); ?>
        
                                <div class="form-group">
                                    <label for="amount">Amount (in cents):</label>
                                    <input type="text" id="amount" name="amount" class="form-control">
                                </div>
        
                                <div class="form-group">
                                    <label for="card-element">Card Information:</label>
                                    <div id="card-element" class="form-control"></div>
                                    <!-- Used to display form errors. -->
                                    <div id="card-errors" class="text-danger" role="alert"></div>
                                </div>
                                     <br>
                                <button type="submit" class="btn btn-primary btn-sm">Submit Payment</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
        <!-- Include Stripe.js library -->
        <script src="https://js.stripe.com/v3/"></script>
    
        <!-- Add JavaScript to handle Stripe payment -->
        <script>
            var stripe = Stripe('<?php echo e(config('services.stripe.key')); ?>');
    
            var elements = stripe.elements();
    
            var card = elements.create('card');
    
            card.mount('#card-element');
    
            card.on('change', function (event) {
                var displayError = document.getElementById('card-errors');
                if (event.error) {
                    displayError.textContent = event.error.message;
                } else {
                    displayError.textContent = '';
                }
            });
    
            var form = document.getElementById('payment-form');
    
            form.addEventListener('submit', function (event) {
                event.preventDefault();
    
                stripe.createToken(card).then(function (result) {
                    if (result.error) {
        
                        var errorElement = document.getElementById('card-errors');
                        errorElement.textContent = result.error.message;
                    } else {
        
                        stripeTokenHandler(result.token);
                    }
                });
            });
    
            function stripeTokenHandler(token) {

                var form = document.getElementById('payment-form');
                var hiddenInput = document.createElement('input');
                hiddenInput.setAttribute('type', 'hidden');
                hiddenInput.setAttribute('name', 'stripeToken');
                hiddenInput.setAttribute('value', token.id);
                form.appendChild(hiddenInput);
    

                form.submit();
            }
        </script>


        
    </body>
</html>
<?php /**PATH C:\laragon\www\lapland\resources\views/payment/test.blade.php ENDPATH**/ ?>