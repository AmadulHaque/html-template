<?php

use App\File;
use App\Setting;
use Illuminate\Support\Facades\Log;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Str;

define('USER_AVATAR_PATH', 'user/');
define('LOGO_PATH', 'logo/');
define('GENDER', [1 => 'Male', 2 => 'Female']);
define('STATUS', [1 => 'Active', 2 => 'Inactive']);
define('STATUS_LABEL', [
    1 => '<span class="badge badge-sm badge-success">Active</span>',
    2 => '<span class="badge badge-sm badge-danger">Inctive</span>'
]);
define('UNAUTORIZED_BLOCK', 'Unauthorized Block!');
// define('CURRENCY_SIGN', '$');

if (!function_exists('table_checkbox')) {
    function table_checkbox($row_id)
    {
        return '<div class="form-checkbox">
            <input type="checkbox" class="form-check-input select_data" id="checkbox-' . $row_id . '" value="' . $row_id . '" onClick="select_single_item(' . $row_id . ')">
            <label class="form-check-label" for="checkbox-' . $row_id . '"></label>
        </div>';
    }
}

if (!function_exists('table_image')) {
    function table_image($path, $image, $name)
    {
        return $image ? "<img src='" . asset('/') . "storage/" . $path . $image . "' alt='" . $name . "' style='width:40px;'/>"
            : "<img src='" . asset('/') . "img/default.svg' alt='Default Image' style='width:40px;'/>";
    }
}

if (!function_exists('user_image')) {
    function user_image($gender, $path, $image, $name, $class = '', $style)
    {
        if ($image) {
            return '<img src="' . asset('/') . 'storage/' . $path . '/' . $image . '" alt="' . $name . '" style="' . $style . '" class="' . $class . '">';
        } else {
            $img = $gender == '1' ? 'male' : 'female';
            return '<img src="' . asset('/') . 'img/' . $img . '.svg" alt="' . $name . '" style="' . $style . '">';
        }
    }
}

if (!function_exists('change_status')) {
    function change_status(int $id, int $status, string $name = null)
    {
        return $status == 1 ? '<span class="badge badge-success change_status" data-id="' . $id . '" data-name="' . $name . '" data-status="2" style="cursor:pointer;">Active</span>' :
            '<span class="badge badge-danger change_status" data-id="' . $id . '" data-name="' . $name . '" data-status="1" style="cursor:pointer;">Inactive</span>';
    }
}

if (!function_exists('tooltip')) {
    function tooltip($title, $direction = 'top')
    {
        return 'data-toggle="tooltip" data-placement="' . $direction . '" title="' . $title . '"';
    }
}

if (!function_exists('uploadFile')) {
    function uploadFile($file, $height = 400, $width = 400)
    {
        if ($file->isValid()) {
            $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('uploads'), $fileName);

            $fileModel = new File();
            $fileModel->file_path = 'uploads/' . $fileName;
            $fileModel->save();

            $image = Image::make(public_path($fileModel->file_path));
            $image->resize($height, $width);
            $image->save();

            return $fileModel->id;
        }

        return null;
    }
}
if (!function_exists('uploadVideo')) {
    function uploadVideo($file)
    {
        if ($file->isValid()) {
            $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('uploads'), $fileName);

            $fileModel = new File();
            $fileModel->file_path = 'uploads/' . $fileName;
            $fileModel->type = 'video';
            $fileModel->save();

            return $fileModel->id;
        }

        return null;
    }
}

function deleteFile($fileId)
{
    $file = File::findOrfail($fileId);

    if ($file) {
        $filePath = public_path($file->file_path);

        if (file_exists($filePath)) {
            try {
                unlink($filePath);
                Log::info("File deleted at path: " . $filePath);
                $file->delete();
                Log::info("File record deleted: " . $file->file_path);
            } catch (\Exception $e) {
                Log::error("Error deleting file: " . $e->getMessage());
            }
        } else {
            Log::warning("File not found at path: " . $filePath);
        }
    } else {
        Log::warning("File record not found for ID: " . $fileId);
    }
}


if (!function_exists('uploaded_asset')) {
    function uploaded_asset($file)
    {
        $path = File::findOrfail($file)->file_path;
        return asset($path);
    }
}
if (!function_exists('trimString')) {
    function trimString($string, $length = 15)
    {
        $string = strip_tags($string);
        $data = Str::limit($string, $length, $end = '...');
        return $data;
    }
}


if (!function_exists('calculateSubtotal')) {
    function calculateSubtotal($quantity, $price)
    {
        $quantity = $quantity ?? 0;
        $price = $price ?? 0;
        
        return  ($quantity * $price);
    }
}

if (!function_exists('calculateTotalPrice')) {
    function calculateTotalPrice($details)
    {
        $adultSubtotal = calculateSubtotal($details->adult_quantity, $details->per_adult_price);
        $childSubtotal = calculateSubtotal($details->child_quantity, $details->per_child_price);
        $infantSubtotal = calculateSubtotal($details->infant_quantity, $details->per_infant_price);
        $petSubtotal = calculateSubtotal($details->pet_quantity, $details->per_pet_price);

        return $adultSubtotal + $childSubtotal + $infantSubtotal + $petSubtotal;
    }
}
