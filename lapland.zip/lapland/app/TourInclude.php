<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TourInclude extends Model
{
    protected $table = 'tour_includes';
    protected $guarded = [];
}
