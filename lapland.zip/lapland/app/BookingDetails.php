<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BookingDetails extends Model
{
    public function tour()
    {
        return $this->belongsTo(Tour::class, 'tour_id', 'id');
    }
}
