<?php

namespace App;

use App\Traits\Base;
use App\Traits\UploadAble;
use Illuminate\Database\Eloquent\Model;

class TimeSlot extends Model
{
    use UploadAble, Base;
    
    protected $table = 'time_slots';
    protected $guarded = [];
}
