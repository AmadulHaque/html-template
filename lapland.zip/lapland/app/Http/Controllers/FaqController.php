<?php

namespace App\Http\Controllers;

use App\Faq;
use App\Models\Role;
use App\Traits\Base;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Yajra\DataTables\Facades\DataTables;

class FaqController extends Controller
{
    use UploadAble, Base;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $getData = Faq::whereIn('status', [1, 2])->orderBy('created_at', 'desc');
            return DataTables::eloquent($getData)
                ->addIndexColumn()
                ->filter(function ($query) use ($request) {
                    if (!empty($request->search)) {
                        $searchTerm = '%' . $request->search . '%';
                        $query->where('question', 'LIKE', $searchTerm);
                        $query->orWhere('answer', 'LIKE', $searchTerm);
                    }
                })
                ->addColumn('question', function ($row) {
                    return $row->question;
                })
                ->addColumn('answer', function ($row) {
                    return $row->answer;
                })
                ->addColumn('status', function ($row) {
                    return change_status($row->id, $row->status, $row->question);
                })
                ->addColumn('created_at', function ($row) {
                    return date('Y-m-d', strtotime($row->created_at));
                })
                ->addColumn('bulk_check', function ($row) {
                    return table_checkbox($row->id);;
                })
                ->addColumn('action', function ($row) {
                    $action = '<div class="d-flex align-items-center ">';
                    if (Gate::allows('app.user.view')) {
                        $action .= '<button type="button" class="btn-style btn-style-view view_data ml-1" data-id="' . $row->id . '"><i class="fa fa-eye"></i></button>';
                    }
                    if (Gate::allows('app.user.edit')) {
                        $action .= '<a href="' . route('app.faq.edit', $row->id) . '" class="btn-style btn-style-edit edit_data ml-1"><i class="fa fa-edit"></i></a>';
                    }
                    if (Gate::allows('app.user.delete')) {
                        $action .= '<button type="button" class="btn-style btn-style-danger delete_data ml-1" data-id="' . $row->id . '" data-name="' . $row->role_name . '"><i class="fa fa-trash"></i></button>';
                    }
                    $action .= '</div>';

                    return $action;
                })
                ->rawColumns(['bulk_check',  'status', 'action', 'answer',])
                ->make(true);
        }

        $this->set_page_data('Faq', 'Faq');
        $breadcrumb = ['Faqs' => ''];
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
        return view('faq.index', ['roles' => $roles, 'breadcrumb' => $breadcrumb]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->set_page_data('Create Faq', 'Create');
        $breadcrumb = ['Create Faq ' => ''];
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
        return view('faq.create', ['roles' => $roles, 'breadcrumb' => $breadcrumb]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'question' => 'required|string|max:255',
            'answer' => 'required',
        ]);

        $faq = new Faq();
        $faq->question = $request->input('question');
        $faq->answer = $request->input('answer');
        $faq->save();

        return redirect()->route('app.faq.index')->with('success', 'Faq created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $this->set_page_data('Edit Faq', 'Edit');
        $breadcrumb = ['Edit Faq' => ''];
        $faq = Faq::findOrFail($id);
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
        return view('faq.edit', ['roles' => $roles, 'breadcrumb' => $breadcrumb, 'faq' => $faq]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'question' => 'required|string|max:255',
            'answer' => 'required',
        ]);
    
        $faq = Faq::findOrFail($id);
   
        $faq->question = $request->input('question');
        $faq->answer = $request->input('answer');
        $faq->save();
    
        return redirect()->route('app.faq.edit', ['id' => $id])->with('success', 'Faq updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function status_change(Request $request)
    {
        if ($request->ajax()) {
            $result = Faq::find($request->id);
            if ($result) {
                $result->update(['status' => $request->status]);
                return $this->status_message($result);
            } else {
                return $this->response_json('error', 'Failed to change status', null, 204);
            }
        }
    }
}
