<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\TourCategory;
use App\Traits\Base;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Str;

class TourCategoryController extends Controller
{
    use UploadAble, Base;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $getData = TourCategory::whereIn('status', [1, 2])->orderBy('created_at', 'desc');
            return DataTables::eloquent($getData)
                ->addIndexColumn()
                ->filter(function ($query) use ($request) {
                    if (!empty($request->search)) {
                        $searchTerm = '%' . $request->search . '%';
                        $query->where('title', 'LIKE', $searchTerm);
                    }
                })
                ->addColumn('title', function ($row) {
                    return $row->title;
                })
                ->addColumn('image', function ($row) {
                    return '<img src="' . uploaded_asset($row->image) . '" width="20px">' ?? null;
                })
                ->addColumn('status', function ($row) {
                    return change_status($row->id, $row->status, $row->title);
                })
                ->addColumn('created_at', function ($row) {
                    return date('Y-m-d', strtotime($row->created_at));
                })
                ->addColumn('created_by', function ($row) {
                    return $row->createdBy->name ?? null;
                })
                ->addColumn('bulk_check', function ($row) {
                    return table_checkbox($row->id);;
                })
                ->addColumn('action', function ($row) {
                    $action = '<div class="d-flex align-items-center justify-content-end">';
                    if (Gate::allows('app.user.view')) {
                        $action .= '<button type="button" class="btn-style btn-style-view view_data ml-1" data-id="' . $row->id . '"><i class="fa fa-eye"></i></button>';
                    }
                    if (Gate::allows('app.user.edit')) {
                        $action .= '<a href="' . route('app.tour.category.edit', $row->id) . '" class="btn-style btn-style-edit edit_data ml-1"><i class="fa fa-edit"></i></a>';
                    }
                    if (Gate::allows('app.user.delete')) {
                        $action .= '<button type="button" class="btn-style btn-style-danger delete_data ml-1" data-id="' . $row->id . '" data-name="' . $row->role_name . '"><i class="fa fa-trash"></i></button>';
                    }
                    $action .= '</div>';

                    return $action;
                })
                ->rawColumns(['bulk_check', 'image', 'status', 'action', 'created_by', 'status'])
                ->make(true);
        }

        $this->set_page_data('Tour Categories', 'Categories List');
        $breadcrumb = ['Categories' => ''];
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
        return view('tour_category.index', ['roles' => $roles, 'breadcrumb' => $breadcrumb]);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->set_page_data('Create Tour Category', 'Create');
        $breadcrumb = ['Create Tour Category' => ''];
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
        return view('tour_category.create', ['roles' => $roles, 'breadcrumb' => $breadcrumb]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'meta_title' => 'required|string|max:255',
            'meta_description' => 'required|string|max:255',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:5120', // Max size 5MB
        ]);

        $image = null;
        if ($request->file('image')) {
            $image = uploadFile($request->file('image'));
        }else{
            return redirect()->back()->with('error', 'Something went wrong with image');
        }

        $originalSlug = Str::slug($request->input('title'));
        $slug = $originalSlug;
        $counter = 1;

        while (TourCategory::where('slug', $slug)->exists()) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }

        $category = new TourCategory();
        $category->title = $request->input('title');
        $category->meta_title = $request->input('meta_title');
        $category->meta_description = $request->input('meta_description');
        $category->image = $image;
        $category->slug = $slug;
        $category->created_by = Auth::id();
        $category->save();

        return redirect()->route('app.tour.category.create')->with('success', 'Tour category created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $this->set_page_data('Edit Category', 'Edit');
        $breadcrumb = ['Create Category' => ''];
        $category = TourCategory::findOrFail($id);
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
        return view('tour_category.edit', ['roles' => $roles, 'breadcrumb' => $breadcrumb, 'category' => $category]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'meta_title' => 'required|string|max:255',
            'meta_description' => 'required|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:5120', // Max size 5MB
        ]);
    
        $category = TourCategory::findOrFail($id);

        if ($request->hasFile('image')) {
            $image = uploadFile($request->file('image'));
    
          
            if ($category->image) {
                deleteFile($category->image);
            }
    
            $category->image = $image;
        }

        $category->title = $request->input('title');
        $category->meta_title = $request->input('meta_title');
        $category->meta_description = $request->input('meta_description');
        $category->save();
    
        return redirect()->route('app.tour.category.edit', ['id' => $id])->with('success', 'Category updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function status_change(Request $request)
    {
        if ($request->ajax()) {
            $result = TourCategory::find($request->id);
            if ($result) {
                $result->update(['status' => $request->status]);
                return $this->status_message($result);
            } else {
                return $this->response_json('error', 'Failed to change status', null, 204);
            }
        }
    }
}
