<?php

namespace App\Http\Controllers;

use App\Tour;
use App\TourCategory;
use Illuminate\Http\Request;

class HomeController extends Controller
{

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $latestTours = Tour::where('status', 1)->take(6)->get();
        $tourCategories = TourCategory::where('status', '1')->get();
        return view('frontend.home.index', compact('tourCategories', 'latestTours'));
    }
}
