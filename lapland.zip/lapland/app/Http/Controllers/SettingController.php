<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Setting;
use App\Tour;
use App\Traits\Base;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;

class SettingController extends Controller
{
    use Base;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->set_page_data('Settings', 'Settings');
        $breadcrumb = ['Settings' => ''];
        $settings = Setting::all();
        $tours = Tour::where('status',1)->get();
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
       
        return view('setting.index', compact('settings','tours'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
   
        $rules = [
            'date_format' => 'required|string',
            'datetime_format' => 'required|string',
            'site_title' => 'required|string',
            'site_description' => 'required|string',
            'site_logo' => 'nullable|file|mimes:jpeg,png,jpg,gif|max:5120', 
            'site_favicon' => 'nullable|file|mimes:ico,jpeg,png,jpg,gif|max:5120', 
            'home_page_video' => 'nullable|string',
            'social_media_facebook' => 'nullable|string',
            'social_media_instagram' => 'nullable|string',
            'social_media_twitter' => 'nullable|string',
            'social_media_youtube' => 'nullable|string',
            'social_media_pinterest' => 'nullable|string',
            'mail_driver' => 'nullable|string',
            'mail_host' => 'string',
            'mail_port' => 'numeric',
            'mail_from_address' => 'email',
            'mail_from_name' => 'string',
            'mail_encryption' => 'string',
            'mail_username' => 'string',
            'mail_password' => 'string',
            'currency_icon' => 'string',
            'tab1_title' => 'string|required',
            'tab2_title' => 'string|required',
            'tab3_title' => 'string|required',
            'tab1_tours' => 'array|nullable',
            'tab2_tours' => 'array|nullable',
            'tab3_tours' => 'array|nullable',
            'feature_tours' => 'array|nullable',

        ];
    
        $validatedData = $request->validate($rules);
        foreach ($validatedData as $key => $value) {
         
            if (in_array($key, ['site_logo', 'site_favicon'])) {
          
                if ($value) {
                    $existingFileId = Setting::where('key', $key)->value('value');
                    if ($existingFileId) {
                        deleteFile($existingFileId);
                    }
                    
                    if ($key === 'site_logo') {
                        $fileId = uploadFile($value, 160, 32);
                    } elseif ($key === 'site_favicon') {
                        $fileId = uploadFile($value, 40, 40);
                    }
                    
                    Setting::updateOrCreate(['key' => $key], ['value' => $fileId]);
                    // dd($key, $value, $existingFileId, $fileId);
                    Config::set('key',$value);
                }
            } else {
                Setting::updateOrCreate(['key' => $key], ['value' => $value]);
                Config::set('key',$value);
            }
        }
    
        return redirect()->route('app.setting.index')->with('success', 'Settings updated successfully');
    }
    
    

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
