<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\Module;
use App\Traits\Base;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Yajra\DataTables\Facades\DataTables;

class RoleController extends Controller
{
    use Base;

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        Gate::authorize('app.role.index');

        if($request->ajax()){
            $getData = Role::with('permissions')
                ->where('slug','!=','super-admin')
                ->orderBy('id','asc');
            return DataTables::eloquent($getData)
                ->addIndexColumn()
                ->filter(function ($query) use ($request) {
                    if (!empty($request->search_text)) {
                        $query->where('name', 'LIKE', "%$request->search_text%");
                    }
                })
                ->addColumn('permission_count', function($row){
                    return $row->permissions->count();
                })
                ->addColumn('created_at', function($row){
                    return date('Y-m-d', strtotime($row->created_at));
                })
                ->addColumn('bulk_check', function($row){
                    return table_checkbox($row->id);;
                })
                ->addColumn('action', function($row){
                    $action = '<div class="d-flex align-items-center justify-content-end">';
                    if (Gate::allows('app.role.edit')) {
                    $action .= '<a href="'.route('app.role.edit',$row->id).'" class="btn-style btn-style-edit edit_data ml-1"><i class="fa fa-edit"></i></a>';
                    }
                    if (Gate::allows('app.role.delete')) {
                    $action .= '<button type="button" class="btn-style btn-style-danger delete_data ml-1" data-id="' . $row->id . '" data-name="' . $row->name . '"><i class="fa fa-trash"></i></button>';
                    }
                    $action .= '</div>';

                    return $action;
                })
                ->rawColumns(['bulk_check','status','action'])
                ->make(true);
        }

        $breadcrumb = ['Roles'=>''];
        $this->set_page_data('Roles','Roles');
        return view('role.index', compact('breadcrumb'));
    }

    /**
     * role with permission create
     *
     * @return \Illuminate\Http\Response
     */
    public function create(){
        // authorized
        Gate::authorize('app.role.create');

        $this->set_page_data('New Role', 'New Role');
        $modules = Module::with('permissions')->get();
        $breadcrumb = ['Roles'=>route('app.role.index'),'New Role'=>''];
        $data = [
            'breadcrumb' => $breadcrumb,
            'modules'    => $modules
        ];

        return view('role.update_or_create',$data);
    }

    /**
     * role with permission data store
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request){
        // authorized
        Gate::authorize('app.role.create');

        // validate rules
        $request->validate([
            'name'         => ['required','string','max:20','unique:roles,name'],
            'permission' => ['required','array']
        ]);

        Role::create([
            'name'       => $request->name,
            'slug'       => Str::slug($request->name),
            'created_by' => auth()->user()->name,
        ])->permissions()->sync($request->permission);

        return redirect()->route('app.role.index')->with('success','Role has been saved successfull.');
    }

    /**
     * spacified role with permission edit resource
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function edit($id){
        // authorized
        Gate::authorize('app.role.edit');

        $role = Role::with('permissions')->findOrfail($id);
        $modules = Module::with('permissions')->get();
        $this->set_page_data('Edit Role', 'Edit Role');
        $breadcrumb = ['Roles'=>route('app.role.index'),'Edit Role'=>''];
        $data = [
            'breadcrumb' => $breadcrumb,
            'modules'=>$modules,
            'role'    => $role
        ];
        return view('role.update_or_create',$data);
    }

    /**
     * spacified role with permission update
     *
     * @param \App\Models\Role $id
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, int $id){
        // authorized
        Gate::authorize('app.role.edit');

        // validate rules
        $request->validate([
            'name'         => ['required','string','max:20','unique:roles,name,'.$id],
            'permission'   => ['required','array']
        ]);

        $role = Role::findOrFail($id);
        $role->update([
            'name'       => $request->name,
            'slug'       => Str::slug($request->name),
            'updated_by' => auth()->user()->name
        ]);

        $role->permissions()->sync($request->permission);

        return redirect()->back()->with('success','Role has been updated successfull.');
    }

    /**
     * spacified role with permission delete
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function delete(Request $request){
        if ($request->ajax()) {
            if (Gate::allows('app.role.delete')) {
                $result = Role::find($request->id);
                if($result){
                    $result->delete();
                    return $this->delete_message($result);
                }else{
                    return $this->response_json('error','Data Cannot Delete',null,204);
                }
            }else{
                return $this->response_json('error','Unauthorized Block!',null,204);
            }
        }else{
            return $this->response_json('error',null,null,401);
        }
    }

    /**
     * multiple role with permission destroy
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function bulk_delete(Request $request){
        if ($request->ajax()) {
            if (Gate::allows('app.role.bulk-delete')) {
                $result = Role::destroy($request->ids);
                if($result){
                    return $this->bulk_delete_message($result);
                }else{
                    return $this->response_json('error','Data Cannot Delete',null,204);
                }
            }else{
                return $this->response_json('error','Unauthorized Block!',null,204);
            }
        }else{
            return $this->response_json('error',null,null,401);
        }
    }
}
