<?php

namespace App\Http\Controllers;

use App\BlogCategory;
use App\Faq;
use App\Models\Role;
use App\TimeSlot;
use App\Tour;
use App\TourCategory;
use App\TourInclude;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Str;
use Tours;
use Yajra\DataTables\Facades\DataTables;

class TourController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $getData = Tour::whereIn('status', [1, 2])->orderBy('created_at', 'desc');
            return DataTables::eloquent($getData)
                ->addIndexColumn()
                ->filter(function ($query) use ($request) {
                    if (!empty($request->search)) {
                        $searchTerm = '%' . $request->search . '%';
                        $query->where(function ($query) use ($searchTerm) {
                            $query->where('title', 'LIKE', $searchTerm)
                                ->orWhereHas('category', function ($query) use ($searchTerm) {
                                    $query->where('title', 'LIKE', $searchTerm);
                                })
                                ->orWhere('description', 'LIKE', $searchTerm)
                                ->orWhereHas('createdBy', function ($query) use ($searchTerm) {
                                    $query->where('name', 'LIKE', $searchTerm);
                                });
                        });
                    }
                })
                ->addColumn('title', function ($row) {
                    return $row->title;
                })
                ->addColumn('description', function ($row) {
                    return trimString($row->description);
                })
                ->addColumn('category_name', function ($row) {
                    return $row->category->title ?? null;
                })
                ->addColumn('created_at', function ($row) {
                    return date('Y-m-d', strtotime($row->created_at));
                })
                ->addColumn('status', function ($row) {
                    return change_status($row->id, $row->status, $row->title);
                })
                ->addColumn('created_by', function ($row) {
                    return $row->createdBy->name;
                })
                ->addColumn('bulk_check', function ($row) {
                    return table_checkbox($row->id);;
                })
                ->addColumn('action', function ($row) {
                    $action = '<div class="d-flex align-items-center justify-content-end">';
                    if (Gate::allows('app.user.view')) {
                        $action .= '<button type="button" class="btn-style btn-style-view view_data ml-1" data-id="' . $row->id . '"><i class="fa fa-eye"></i></button>';
                    }
                    if (Gate::allows('app.user.edit')) {
                        $action .= '<a href="' . route('app.blog.edit', $row->id) . '" class="btn-style btn-style-edit edit_data ml-1"><i class="fa fa-edit"></i></a>';
                    }
                    if (Gate::allows('app.user.delete')) {
                        $action .= '<button type="button" class="btn-style btn-style-danger delete_data ml-1" data-id="' . $row->id . '" data-name="' . $row->role_name . '"><i class="fa fa-trash"></i></button>';
                    }
                    $action .= '</div>';

                    return $action;
                })
                ->rawColumns(['bulk_check', 'category_name', 'status', 'action', 'created_by', 'status', 'description'])
                ->make(true);
        }

        $this->set_page_data('Tours', 'Tour List');
        $breadcrumb = ['Tours' => ''];
        $categories = TourCategory::where('status', 1)->orderBy('created_at', 'desc')->get();
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
        return view('tour.index', ['roles' => $roles, 'breadcrumb' => $breadcrumb, 'categories' => $categories]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        $this->set_page_data('Create Tour ', 'Create');
        $breadcrumb = ['Create Tour ' => ''];
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
        $tourCategories = TourCategory::where('status', 1)->orderBy('created_at', 'desc')->get();
        $tourIncludes = TourInclude::where('status', 1)->orderBy('created_at', 'desc')->get();
        $timeSlots = TimeSlot::where('status', 1)->orderBy('created_at', 'desc')->get();
        $faqs = Faq::where('status', 1)->orderBy('created_at', 'desc')->get();
        return view('tour.create', ['roles' => $roles, 'breadcrumb' => $breadcrumb, 'tourCategories' => $tourCategories, 'faqs' => $faqs, 'tourIncludes' => $tourIncludes, 'timeSlots' => $timeSlots]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //dd($request->all());
        $request->validate([
            'title' => 'required|string',
            'tour_category_id' => 'required|integer',
            'thumbnail_images' => 'required',
            'banner_images' => 'required',
            'tour_location' => 'required|string',
            'time_slot_ids' => 'required|array',
            'start_date_time' => 'required|date',
            'end_date_time' => 'nullable|date',
            'adult' => 'required|in:1,2',
            'children' => 'required|in:1,2',
            'infant' => 'required|in:1,2',
            'pet' => 'required|in:1,2',
            'default_adult_quantity' => $request->input('adult') == 1 ? 'required|numeric|min:0' : 'nullable|numeric',
            'default_children_quantity' => $request->input('children') == 1 ? 'required|numeric|min:0' : 'nullable|numeric',
            'default_infant_quantity' => $request->input('infant') == 1 ? 'required|numeric|min:0' : 'nullable|numeric',
            'default_pet_quantity' => $request->input('pet') == 1 ? 'required|numeric|min:0' : 'nullable|numeric',
            'max_adult_allowed' => $request->input('adult') == 1 ? 'required|numeric|min:0' : 'nullable|numeric',
            'max_children_allowed' => $request->input('children') == 1 ? 'required|numeric|min:0' : 'nullable|numeric',
            'max_infant_allowed' => $request->input('infant') == 1 ? 'required|numeric|min:0' : 'nullable|numeric',
            'max_pet_allowed' => $request->input('pet') == 1 ? 'required|numeric|min:0' : 'nullable|numeric',
            'extra_adult_price' => $request->input('adult') == 1 ? 'required|numeric|min:0' : 'nullable|numeric',
            'extra_children_price' => $request->input('children') == 1 ? 'required|numeric|min:0' : 'nullable|numeric',
            'extra_infant_price' => $request->input('infant') == 1 ? 'required|numeric|min:0' : 'nullable|numeric',
            'extra_pet_price' => $request->input('pet') == 1 ? 'required|numeric|min:0' : 'nullable|numeric',
            'tour_base_price' => 'required|numeric|min:0',
            'description' => 'required|string',
            'youtube_video_link' => 'nullable|url',
            'tour_include_ids' => 'required|array',
            'faq_ids' => 'required|array',
            'booking_in_advanced' => 'nullable|string',
            'change_date_policy' => 'nullable|in:1,2',
            'contact_meeting' => 'nullable|string',
            'pick_up' => 'nullable|string',
            'map_link' => 'required|url',
            'status' => 'required|in:1,2,3',
        ]);


        $originalSlug = Str::slug($request->input('title'));
        $slug = $originalSlug;
        $counter = 1;

        while (Tour::where('slug', $slug)->exists()) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }

        $thumbnails = [];
        if ($request->file('thumbnail_images')) {
            foreach ($request->file('thumbnail_images') as $thumbnail) {
                $thumbnails[] = uploadFile($thumbnail, 424, 306);
            }
        }

        $bannerImages = [];
        if ($request->file('banner_images')) {
            foreach ($request->file('banner_images') as $banner) {
                $bannerImages[] = uploadFile($banner, 1512, 680);
            }
        }


        $tour = new Tour();
        $tour->title = $request->input('title');
        $tour->tour_category_id = $request->input('tour_category_id');
        $tour->thumbnail_images = json_encode($thumbnails);
        $tour->banner_images = json_encode($bannerImages);
        $tour->tour_location = $request->input('tour_location');
        $tour->time_slot_ids = json_encode($request->input('time_slot_ids'));
        $tour->start_date_time = $request->input('start_date_time');
        $tour->end_date_time = $request->input('end_date_time');
        $tour->adult = $request->input('adult');
        $tour->children = $request->input('children');
        $tour->infant = $request->input('infant');
        $tour->pet = $request->input('pet');
        $tour->default_adult_quantity = $request->input('default_adult_quantity');
        $tour->default_children_quantity = $request->input('default_children_quantity');
        $tour->default_infant_quantity = $request->input('default_infant_quantity');
        $tour->default_pet_quantity = $request->input('default_pet_quantity');
        $tour->max_adult_allowed = $request->input('max_adult_allowed');
        $tour->max_children_allowed = $request->input('max_children_allowed');
        $tour->max_infant_allowed = $request->input('max_infant_allowed');
        $tour->max_pet_allowed = $request->input('max_pet_allowed');
        $tour->tour_base_price = $request->input('tour_base_price');
        $tour->extra_adult_price = $request->input('extra_adult_price');
        $tour->extra_children_price = $request->input('extra_children_price');
        $tour->extra_infant_price = $request->input('extra_infant_price');
        $tour->extra_pet_price = $request->input('extra_pet_price');
        $tour->description = $request->input('description');
        $tour->youtube_video_link = $request->input('youtube_video_link');
        $tour->tour_include_ids = json_encode($request->input('tour_include_ids'));
        $tour->faq_ids = json_encode($request->input('faq_id'));
        $tour->booking_in_advanced = $request->input('booking_in_advanced');
        $tour->change_date_policy = $request->input('change_date_policy');
        $tour->contact_meeting = $request->input('contact_meeting');
        $tour->pick_up = $request->input('pick_up');
        $tour->map_link = $request->input('map_link');
        $tour->status = $request->input('status');
        $tour->slug = $slug;
        $tour->created_by = Auth::id();
        $tour->is_bokun = $request->input('is_bokun');
        $tour->bokun_code = $request->input('bokun_code');
        $tour->save();

        return redirect()->back()->with('success', 'Tour Added Successfully');
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($slug)
    {
        $tour = Tour::where('slug', $slug)->where('status', '1')->first();
        $tourCategories = TourCategory::where('status', '1')->get();
        return view('frontend.tour.details', compact('tour', 'tourCategories'));
    }
    public function categoryShow($slug)
    {
        $category = TourCategory::where('slug', $slug)->first();
        $tours = Tour::where('tour_category_id', $category->id)->where('status', '1')->get() ?? null;
        $tourCategories = TourCategory::where('status', '1')->get();
        return view('frontend.tour_category.index', compact('tours', 'category', 'tourCategories'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
