<?php

namespace App\Http\Controllers;

use App\Booking;
use App\Models\Role;
use App\Payment;
use App\Traits\Base;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Svg\Tag\Path;
use Yajra\DataTables\Facades\DataTables;

class BookingController extends Controller
{
    use UploadAble, Base;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $getData = Booking::with('payments')->whereIn('status', [1, 2])->orderBy('created_at', 'desc');
            return DataTables::eloquent($getData)
                ->addIndexColumn()
                ->filter(function ($query) use ($request) {
                    if (!empty($request->search)) {
                        $searchTerm = '%' . $request->search . '%';
                        $query->where(function ($query) use ($searchTerm) {
                            $query->where('booking_id', 'LIKE', $searchTerm)
                                ->orWhereHas('user', function ($subQuery) use ($searchTerm) {
                                    $subQuery->where('name', 'LIKE', $searchTerm)
                                        ->orWhere('email', 'LIKE', $searchTerm);
                                })
                                ->orWhere('stripe_payment_id', 'LIKE', $searchTerm)
                                ->orWhereHas('booking', function ($subQuery) use ($searchTerm) {
                                    $subQuery->where('booking_number', 'LIKE', $searchTerm);
                                });
                        });
                    }
                })
                ->addColumn('booking_number', function ($row) {
                    return $row->booking_number;
                })
                ->addColumn('stripe_payment_id', function ($row) {
                    return  null;
                })
                // ->addColumn('tours', function ($row) {
                //     return  null;
                // })
                ->addColumn('date_of_payment', function ($row) {
                    return  $row->created_at;
                })
                ->addColumn('paid_by', function ($row) {
                    return $row->bookedBy->name;
                })
                ->addColumn('amount', function ($row) {

                    return ($row->payments->last()) ? (config('settings.currency_icon') . $row->payments->last()->amount) : null;
                })->addColumn('failure_code', function ($row) {
                    return $row->payments->first()->failure_code ?? '';
                })->addColumn('failure_message', function ($row) {
                    return $row->payments->first()->failure_message ?? '';
                })
                ->addColumn('stripe_payment_status', function ($row) {

                    $payment = $row->payments->first() ?? null;

                    if($payment){
                        if ($payment['stripe_payment_status'] && $payment['stripe_payment_status'] === 'succeeded') {
                            return '<span class="badge badge-success">' . ucfirst('Succeeded') . '</span>';
                        } elseif ($payment['stripe_payment_status'] && $payment['stripe_payment_status'] === 'failed') {
                            return '<span class="badge badge-danger">' . ucfirst('Failed') . '</span>';
                        } else {
                            return $payment->stripe_payment_status ?? null;
                        }
                    }else{
                        return '<span class="badge badge-warning">' . ucfirst('Booked') . '</span>';
                    }
                })
                ->addColumn('status', function ($row) {
                    return change_status($row->id, $row->status, $row->title);
                })
                ->addColumn('created_at', function ($row) {
                    return date('Y-m-d', strtotime($row->created_at));
                })
                ->addColumn('created_by', function ($row) {
                    return $row->createdBy->name ?? null;
                })
                ->addColumn('bulk_check', function ($row) {
                    return table_checkbox($row->id);;
                })

                ->addColumn('invoice', function ($row) {
                    return '<a href="' . route('app.booking.invoice', $row->id) . '" target="_blank" class="btn btn-info"><i class="fa fa-eye"></i></a>';
                })
                ->rawColumns(['bulk_check', 'booking_number', 'user', 'stripe_payment_status', 'action', 'created_by', 'status', 'invoice'])
                ->make(true);
        }

        $this->set_page_data('Bookings', 'Booking List');
        $breadcrumb = ['Bookings' => ''];
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
        return view('booking.index', ['roles' => $roles, 'breadcrumb' => $breadcrumb]);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function test()
    {
        return $booking = Booking::findOrFail(1)->payments;
    }
    public function getBookingInvoice($id)
    {
        $this->set_page_data('Invoice', 'Invoice');
        $breadcrumb = ['Invoice' => ''];
        $booking = Booking::findOrFail($id);
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();

        return view('emails.confirmation', ['roles' => $roles, 'breadcrumb' => $breadcrumb, 'booking' => $booking]);
    }
}
