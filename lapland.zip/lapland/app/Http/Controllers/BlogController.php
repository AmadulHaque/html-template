<?php

namespace App\Http\Controllers;

use App\Blog;
use App\BlogCategory;
use App\Models\Role;
use App\Traits\Base;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Str;

class BlogController extends Controller
{
    use UploadAble, Base;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $getData = Blog::whereIn('status', [1, 2])->orderBy('created_at', 'desc');
            return DataTables::eloquent($getData)
                ->addIndexColumn()
                ->filter(function ($query) use ($request) {
                    if (!empty($request->search)) {
                        $searchTerm = '%' . $request->search . '%';
                        $query->where(function ($query) use ($searchTerm) {
                            $query->where('title', 'LIKE', $searchTerm)
                                ->orWhereHas('category', function ($query) use ($searchTerm) {
                                    $query->where('title', 'LIKE', $searchTerm);
                                })
                                ->orWhere('description', 'LIKE', $searchTerm)
                                ->orWhereHas('createdBy', function ($query) use ($searchTerm) {
                                    $query->where('name', 'LIKE', $searchTerm);
                                });
                        });
                    }
                })
                ->addColumn('title', function ($row) {
                    return $row->title;
                })
                ->addColumn('description', function ($row) {
                    return $row->description;
                })
                ->addColumn('category_name', function ($row) {
                    return $row->category->title;
                })
                ->addColumn('created_at', function ($row) {
                    return date('Y-m-d', strtotime($row->created_at));
                })
                ->addColumn('status', function ($row) {
                    return change_status($row->id, $row->status, $row->title);
                })
                ->addColumn('created_by', function ($row) {
                    return $row->createdBy->name;
                })
                ->addColumn('bulk_check', function ($row) {
                    return table_checkbox($row->id);;
                })
                ->addColumn('action', function ($row) {
                    $action = '<div class="d-flex align-items-center justify-content-end">';
                    if (Gate::allows('app.user.view')) {
                        $action .= '<button type="button" class="btn-style btn-style-view view_data ml-1" data-id="' . $row->id . '"><i class="fa fa-eye"></i></button>';
                    }
                    if (Gate::allows('app.user.edit')) {
                        $action .= '<a href="' . route('app.blog.edit', $row->id) . '" class="btn-style btn-style-edit edit_data ml-1"><i class="fa fa-edit"></i></a>';
                    }
                    if (Gate::allows('app.user.delete')) {
                        $action .= '<button type="button" class="btn-style btn-style-danger delete_data ml-1" data-id="' . $row->id . '" data-name="' . $row->role_name . '"><i class="fa fa-trash"></i></button>';
                    }
                    $action .= '</div>';

                    return $action;
                })
                ->rawColumns(['bulk_check', 'category_name', 'status', 'action', 'created_by', 'status'])
                ->make(true);
        }

        $this->set_page_data('Blogs', 'Blog List');
        $breadcrumb = ['Blogs' => ''];
        $categories = BlogCategory::where('status', 1)->orderBy('created_at', 'desc')->get();
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
        return view('blog.index', ['roles' => $roles, 'breadcrumb' => $breadcrumb, 'categories' => $categories]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->set_page_data('Add Blog', 'Add Blog');
        $breadcrumb = ['Blogs' => ''];
        $categories = BlogCategory::where('status', 1)->orderBy('created_at', 'desc')->get();
        return view('blog.create', compact('breadcrumb', 'categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:256',
            'description' => 'required',
            'category_id' => 'required|integer|exists:blog_categories,id',
            'meta_title' => 'required|string|max:256',
            'meta_description' => 'string|max:256',
            'thumbnails' => 'required|array',
            'thumbnails.*' => 'file|max:5024',
            'banner_image' => 'required|file|image|max:10240',
            'video' => 'file|mimetypes:video/mp4,video/x-matroska',
        ]);


        $originalSlug = Str::slug($request->input('title'));
        $slug = $originalSlug;
        $counter = 1;

        while (Blog::where('slug', $slug)->exists()) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }
        $blogPost = new Blog();
        $blogPost->title = $request->input('title');
        $blogPost->description = $request->input('description');
        $blogPost->category_id = $request->input('category_id');
        $blogPost->meta_title = $request->input('meta_title');
        $blogPost->meta_description = $request->input('meta_description');
        $blogPost->slug =  $slug;
        $blogPost->created_by =  Auth::id();
        $blogPost->save();

        $thumbnails = [];
        if ($request->file('thumbnails')) {
            foreach ($request->file('thumbnails') as $thumbnail) {
                $thumbnails[] = uploadFile($thumbnail);
            }
        }

        $bannerImage = $request->file('banner_image') ? uploadFile($request->file('banner_image')) : null;
        $video = $request->file('video') ? uploadVideo($request->file('video')) : null;

        //Update Files
        $blogPost->thumbnail_image = json_encode($thumbnails);
        $blogPost->banner_image = $bannerImage;
        $blogPost->thumbnail_video =  $video;
        $blogPost->save();

        return redirect()->back()->with('success', 'Blog Added Successfully');
    }

    public function status_change(Request $request)
    {
        if ($request->ajax()) {
            $result = Blog::find($request->id);
            if ($result) {
                $result->update(['status' => $request->status]);
                return $this->status_message($result);
            } else {
                return $this->response_json('error', 'Failed to change status', null, 204);
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $this->set_page_data('Edit Blogs', 'Edit Blog');
        $breadcrumb = ['Blogs' => ''];
        $categories = BlogCategory::where('status', 1)->orderBy('created_at', 'desc')->get();
        $blog = Blog::findOrFail($id);
        return view('blog.edit', compact('blog', 'categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:256',
            'description' => 'required',
            'category_id' => 'required|integer|exists:blog_categories,id',
            'meta_title' => 'required|string|max:256',
            'meta_description' => 'string|max:256',
            'thumbnails.*' => 'file|max:5024',
            'banner_image' => 'file|image|max:10240',
            'video' => 'file|mimetypes:video/mp4,video/x-matroska',
        ]);

        $blogPost = Blog::findOrFail($id);

        $originalSlug = Str::slug($request->input('title'));
        $slug = $originalSlug;
        $counter = 1;

        while (Blog::where('slug', $slug)->where('id', '!=', $id)->exists()) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }

        $blogPost->title = $request->input('title');
        $blogPost->description = $request->input('description');
        $blogPost->category_id = $request->input('category_id');
        $blogPost->meta_title = $request->input('meta_title');
        $blogPost->meta_description = $request->input('meta_description');
        $blogPost->slug = $slug;

        // Handle Banner Image
        if ($request->hasFile('banner_image')) {
            if ($blogPost->banner_image) {
                deleteFile($blogPost->banner_image);
            }
            $bannerImage = uploadFile($request->file('banner_image'));
            $blogPost->banner_image = $bannerImage;
        }

        // Handle Video File
        if ($request->hasFile('video')) {
            if ($blogPost->thumbnail_video) {
                deleteFile($blogPost->thumbnail_video);
            }
            $video = uploadVideo($request->file('video'));
            $blogPost->thumbnail_video = $video;
        }

        // Handle Thumbnail Images
        $newThumbnails = [];
        $oldThumbnails = $request->existing_thumbnails;
        if (!$oldThumbnails) {
            return redirect()->back()->with('error', 'Atleast 1 thumbnail image required');
        }
        // Calculate deleted thumbnails
        $deletedThumbnails = [];
        $blogThumbnails = json_decode($blogPost->thumbnail_image);

        foreach ($blogThumbnails as $blogThumbnail) {
            if (!in_array($blogThumbnail, $oldThumbnails)) {
                $deletedThumbnails[] = $blogThumbnail;
            }
        }

        if ($deletedThumbnails) {
            foreach ($deletedThumbnails as $deletedThumbnail) {
                deleteFile($deletedThumbnail);
            }
        }

        // Handle new thumbnails
        if ($request->hasFile('thumbnails')) {
            foreach ($request->file('thumbnails') as $thumbnail) {
                $newThumbnail = uploadFile($thumbnail);
                $newThumbnails[] = $newThumbnail;
            }
        } elseif (empty($blogThumbnails)) {
            $newThumbnails = [];
        } else {
            $newThumbnails = $oldThumbnails;
        }
        $newThumbnails = array_merge($oldThumbnails, $newThumbnails);
        $newThumbnails = array_unique($newThumbnails);
        $blogPost->thumbnail_image = json_encode($newThumbnails);
        $blogPost->save();

        return redirect()->back()->with('success', 'Blog Updated Successfully');
    }
}
