<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\TimeSlot;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Yajra\DataTables\Facades\DataTables;

class TimeSlotController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $getData = TimeSlot::whereIn('status', [1, 2])->orderBy('created_at', 'desc');
            return DataTables::eloquent($getData)
                ->addIndexColumn()
                ->filter(function ($query) use ($request) {
                    if (!empty($request->search)) {
                        $searchTerm = '%' . $request->search . '%';
                        $query->where('title', 'LIKE', $searchTerm);
                    }
                })
                ->addColumn('title', function ($row) {
                    return $row->title;
                })
                ->addColumn('date_time', function ($row) {
                    return $row->date_time;
                })
                ->addColumn('status', function ($row) {
                    return change_status($row->id, $row->status, $row->question);
                })
                ->addColumn('created_at', function ($row) {
                    return date('Y-m-d', strtotime($row->created_at));
                })
                ->addColumn('bulk_check', function ($row) {
                    return table_checkbox($row->id);;
                })
                ->addColumn('action', function ($row) {
                    $action = '<div class="d-flex align-items-center ">';
                    if (Gate::allows('app.user.view')) {
                        $action .= '<button type="button" class="btn-style btn-style-view view_data ml-1" data-id="' . $row->id . '"><i class="fa fa-eye"></i></button>';
                    }
                    if (Gate::allows('app.user.edit')) {
                        $action .= '<a href="' . route('app.time-slot.edit', $row->id) . '" class="btn-style btn-style-edit edit_data ml-1"><i class="fa fa-edit"></i></a>';
                    }
                    if (Gate::allows('app.user.delete')) {
                        $action .= '<button type="button" class="btn-style btn-style-danger delete_data ml-1" data-id="' . $row->id . '" data-name="' . $row->role_name . '"><i class="fa fa-trash"></i></button>';
                    }
                    $action .= '</div>';

                    return $action;
                })
                ->rawColumns(['bulk_check',  'status', 'action', 'answer',])
                ->make(true);
        }

        $this->set_page_data('Time Slots', 'Time Slot');
        $breadcrumb = ['Time Slot' => ''];
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
        return view('time_slot.index', ['roles' => $roles, 'breadcrumb' => $breadcrumb]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->set_page_data('Create Time Slot', 'Create');
        $breadcrumb = ['Create Time Slot' => ''];
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
        return view('time_slot.create', ['roles' => $roles, 'breadcrumb' => $breadcrumb]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'date_time' => 'required|date|string|max:255',
            'time_zone' => 'required',
        ]);
        
        $faq = new TimeSlot();
        $faq->title = $request->input('title');
        $faq->date_time = $request->input('date_time');
        $faq->time_zone = $request->input('time_zone');
        $faq->save();

        return redirect()->route('app.time-slot.index')->with('success', 'Time Slot created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit( $id)
    {
        $this->set_page_data('Edit Time Slot', 'Edit');
        $breadcrumb = ['Edit Time Slot' => ''];
        $timeSlot = TimeSlot::findOrFail($id);
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
        return view('time_slot.edit', ['roles' => $roles, 'breadcrumb' => $breadcrumb, 'timeSlot' => $timeSlot]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'date_time' => 'required|date|string|max:255',
            'time_zone' => 'required',
        ]);
        
        $timeSlot = TimeSlot::find($id);
        $timeSlot->title = $request->input('title');
        $timeSlot->date_time = $request->input('date_time');
        $timeSlot->time_zone = $request->input('time_zone');
        $timeSlot->save();

        return redirect()->route('app.time-slot.index')->with('success', 'Time Slot updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
