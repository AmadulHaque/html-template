<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\TourInclude;
use App\Traits\Base;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Yajra\DataTables\Facades\DataTables;

class TourIncludeController extends Controller
{
    use UploadAble, Base;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $getData = TourInclude::whereIn('status', [1, 2])->orderBy('created_at', 'desc');
            return DataTables::eloquent($getData)
                ->addIndexColumn()
                ->filter(function ($query) use ($request) {
                    if (!empty($request->search)) {
                        $searchTerm = '%' . $request->search . '%';
                        $query->where('title', 'LIKE', $searchTerm);
                    }
                })
                ->addColumn('title', function ($row) {
                    return $row->title;
                })
                ->addColumn('status', function ($row) {
                    return change_status($row->id, $row->status, $row->title);
                })
                ->addColumn('created_at', function ($row) {
                    return date('Y-m-d', strtotime($row->created_at));
                })
                ->addColumn('bulk_check', function ($row) {
                    return table_checkbox($row->id);;
                })
                ->addColumn('action', function ($row) {
                    $action = '<div class="d-flex align-items-center ">';
                    if (Gate::allows('app.user.view')) {
                        $action .= '<button type="button" class="btn-style btn-style-view view_data ml-1" data-id="' . $row->id . '"><i class="fa fa-eye"></i></button>';
                    }
                    if (Gate::allows('app.user.edit')) {
                        $action .= '<a href="' . route('app.tour-include.edit', $row->id) . '" class="btn-style btn-style-edit edit_data ml-1"><i class="fa fa-edit"></i></a>';
                    }
                    if (Gate::allows('app.user.delete')) {
                        $action .= '<button type="button" class="btn-style btn-style-danger delete_data ml-1" data-id="' . $row->id . '" data-name="' . $row->role_name . '"><i class="fa fa-trash"></i></button>';
                    }
                    $action .= '</div>';

                    return $action;
                })
                ->rawColumns(['bulk_check',  'status', 'action', 'answer',])
                ->make(true);
        }

        $this->set_page_data('Tour Includes', 'Tour Include');
        $breadcrumb = ['Tour Include' => ''];
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
        return view('tour_include.index', ['roles' => $roles, 'breadcrumb' => $breadcrumb]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->set_page_data('Create Tour Include', 'Create');
        $breadcrumb = ['Create Tour  Include' => ''];
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
        return view('tour_include.create', ['roles' => $roles, 'breadcrumb' => $breadcrumb]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
        ]);

        $faq = new TourInclude();
        $faq->title = $request->input('title');
        $faq->save();

        return redirect()->route('app.tour-include.index')->with('success', 'Tour Inculde created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $this->set_page_data('Edit Tour Include', 'Edit');
        $breadcrumb = ['Edit Tour Include' => ''];
        $tourInclude = TourInclude::findOrFail($id);
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
        return view('tour_include.edit', ['roles' => $roles, 'breadcrumb' => $breadcrumb, 'tourInclude' => $tourInclude]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
        ]);

        $faq = TourInclude::findOrFail($id);

        $faq->title = $request->input('title');
        $faq->save();

        return redirect()->route('app.tour-include.edit', ['id' => $id])->with('success', 'Tour Include updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function status_change(Request $request)
    {
        if ($request->ajax()) {
            $result = TourInclude::find($request->id);
            if ($result) {
                $result->update(['status' => $request->status]);
                return $this->status_message($result);
            } else {
                return $this->response_json('error', 'Failed to change status', null, 204);
            }
        }
    }
}
