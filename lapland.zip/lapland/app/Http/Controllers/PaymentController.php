<?php

namespace App\Http\Controllers;

use App\Booking;
use App\Mail\TourConfirmationEmail;
use App\Models\Role;
use App\Payment;
use App\Traits\Base;
use App\Traits\UploadAble;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Mail;
use Stripe\Stripe;
use Stripe\Charge;
use Stripe\Event;
use Stripe\Exception\CardException;
use Stripe\PaymentIntent;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Str;

class PaymentController extends Controller
{
    use UploadAble, Base;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $getData = Payment::whereIn('status', [1, 2])->orderBy('created_at', 'desc');
            return DataTables::eloquent($getData)
                ->addIndexColumn()
                ->filter(function ($query) use ($request) {
                    if (!empty($request->search)) {
                        $searchTerm = '%' . $request->search . '%';
                        $query->where(function ($query) use ($searchTerm) {
                            $query->where('booking_id', 'LIKE', $searchTerm)
                                ->orWhereHas('user', function ($subQuery) use ($searchTerm) {
                                    $subQuery->where('name', 'LIKE', $searchTerm)
                                        ->orWhere('email', 'LIKE', $searchTerm);
                                })
                                ->orWhere('stripe_payment_id', 'LIKE', $searchTerm)
                                ->orWhereHas('booking', function ($subQuery) use ($searchTerm) {
                                    $subQuery->where('booking_number', 'LIKE', $searchTerm);
                                });
                        });
                    }
                })
                ->addColumn('booking_number', function ($row) {
                    return $row->booking->booking_number;
                })
                ->addColumn('stripe_payment_id', function ($row) {
                    return $row->stripe_payment_id ?? null;
                })
                ->addColumn('user', function ($row) {
                    return $row->user->name;
                })
                ->addColumn('amount', function ($row) {
                    return ($row->amount) ? (config('settings.currency_icon') . $row->amount) : null;
                })->addColumn('failure_code', function ($row) {
                    return $row->failure_code ?? '';
                })->addColumn('failure_message', function ($row) {
                    return $row->failure_message ?? '';
                })
                ->addColumn('stripe_payment_status', function ($row) {
                    if ($row->stripe_payment_status === 'succeeded') {
                        return '<span class="badge badge-success">' . ucfirst($row->stripe_payment_status) . '</span>';
                    } elseif ($row->stripe_payment_status === 'failed') {
                        return '<span class="badge badge-danger">' . ucfirst($row->stripe_payment_status) . '</span>';
                    } else {
                        // Otherwise, display the payment status without a badge
                        return $row->stripe_payment_status ?? null;
                    }
                })
                ->addColumn('status', function ($row) {
                    return change_status($row->id, $row->status, $row->title);
                })
                ->addColumn('created_at', function ($row) {
                    return date('Y-m-d', strtotime($row->created_at));
                })
                ->addColumn('created_by', function ($row) {
                    return $row->createdBy->name ?? null;
                })
                ->addColumn('bulk_check', function ($row) {
                    return table_checkbox($row->id);;
                })
                // ->addColumn('actions', function ($row) {

                //     $action = '<div class="d-flex align-items-center justify-content-end">';
                //     if (Gate::allows('app.user.view')) {
                //         $action .= '<button type="button" class="btn-style btn-style-view view_data ml-1" data-id="' . $row->id . '"><i class="fa fa-eye"></i></button>';
                //     }
                //     if (Gate::allows('app.user.edit')) {
                //         $action .= '<a href="' . route('app.blog.category.edit', $row->id) . '" class="btn-style btn-style-edit edit_data ml-1"><i class="fa fa-edit"></i></a>';
                //     }
                //     if (Gate::allows('app.user.delete')) {
                //         $action .= '<button type="button" class="btn-style btn-style-danger delete_data ml-1" data-id="' . $row->id . '" data-name="' . $row->role_name . '"><i class="fa fa-trash"></i></button>';
                //     }
                //     $action .= '</div>';

                //     return $action;
                // }) 
                ->addColumn('invoice', function ($row) {
                    return '<a href="' . route('app.booking.invoice', $row->booking_id) . '" target="_blank" class="btn btn-info"><i class="fa fa-eye"></i></a>';
                })
                ->rawColumns(['bulk_check', 'booking_number', 'user', 'stripe_payment_status', 'action', 'created_by', 'status', 'invoice'])
                ->make(true);
        }

        $this->set_page_data('Payments', 'Payment List');
        $breadcrumb = ['Payments' => ''];
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();
        return view('payment.index', ['roles' => $roles, 'breadcrumb' => $breadcrumb]);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function showPaymentForm()
    {
        return view('payment.test');
    }

    public function processPayment(Request $request)
    {
        Stripe::setApiKey(env('STRIPE_SECRET'));

        try {
            $data = Charge::create([
                'amount' => $request->amount * 100, // Amount in cents
                'currency' => 'usd',
                'source' => $request->stripeToken,
                'description' => 'Payment Description',
            ]);


            $payment = new Payment();
            // $payment->booking_id = $request->booking_id ?? Str::upper(Str::random(7));
            $payment->booking_id = $request->booking_id ?? 1;
            $payment->user_id = $request->user_id ?? 1;
            $payment->api_response = json_encode($data);
            $payment->stripe_payment_id = $data->id;
            $payment->stripe_payment_status = $data->status;
            $payment->type = $data->payment_method_details->type ?? null;
            $payment->card_brand = $data->payment_method_details->card->brand ?? null;
            $payment->last_four_digits = $data->payment_method_details->card->last4 ?? null;
            $payment->exp_month = $data->payment_method_details->card->exp_month ?? null;
            $payment->exp_year = $data->payment_method_details->card->exp_year ?? null;
            $payment->routing_number = $data->ach_credit_transfer->routing_number ?? null;
            $payment->account_number = $data->payment_method_details->ach_credit_transfer->account_number ?? null;
            $payment->account_holder_name = $data->payment_method_details->ach_credit_transfer->account_holder_name ?? null;
            $payment->amount = $data->amount;
            $payment->amount_captured = $data->amount_captured;
            $payment->amount_refunded = $data->amount_refunded;
            $payment->balance_transaction = $data->balance_transaction;
            $payment->captured = $data->captured;
            $payment->created = Carbon::createFromTimestamp($data->created)->toDateTimeString();
            $payment->currency = $data->currency;
            $payment->description = $data->description;
            $payment->invoice_id = $request->invoice_id;
            $payment->livemode = $data->livemode;
            $payment->metadata = json_encode($data->metadata);
            $payment->payment_method = $data->payment_method;
            $payment->payment_intent = $data->payment_intent;
            $payment->receipt_number = $data->receipt_number;
            $payment->receipt_url = $data->receipt_url;
            $payment->refunded = $data->refunded;
            $payment->source_transfer = $data->source_transfer;
            $payment->statement_descriptor = $data->statement_descriptor;
            $payment->statement_descriptor_suffix = $data->statement_descriptor_suffix;
            $payment->failure_code = $data->failure_code ?? null;
            $payment->failure_message =  $payment->failure_message ?? null;
            $payment->status = 1;
            $payment->save();

            if ($payment->stripe_payment_status == 'succeeded') {
                // $booking= Booking::findOrFail($request->booking_id);
                $booking = Booking::findOrFail(3);
                $booking->status = 1;
                $booking->payment_id = $payment->id;
                $booking->payment_status = 1;
                $booking->save();
                 $this->sendBookingConfirmationMail($payment);
                return 0;

            }


            // $this->sendBookingConfirmationMail($payment);
            return redirect()->route('dashboard')->with('success', 'Payment successful!');
        } catch (CardException $e) {
            $payment = new Payment();
            $payment->booking_id = $request->booking_id ?? 1;
            $payment->user_id = $request->user_id ?? 1;
            $payment->amount = $request->amount;
            $payment->api_response = $e;
            $payment->stripe_payment_id = $e->getRequestId();;
            $payment->stripe_payment_status = 'failed';
            $payment->failure_code = $e->getDeclineCode();
            $payment->failure_message = $e->getMessage();
            $payment->status = 1;
            $payment->save();


            return redirect()->route('app.dashboard')->with('error', 'Your card was declined. Please check your card details and try again.');
        } catch (\Exception $e) {
            return redirect()->route('app.dashboard')->with('error', 'An error occurred while processing your payment.');
        }
    }
    public function getPayments()
    {

        Stripe::setApiKey(config('services.stripe.secret'));

        try {

            $payments = Charge::all();

            dd($payments->data);

            return view('payments', ['payments' => $payments]);
        } catch (\Exception $e) {

            return view('payments', ['error' => $e->getMessage()]);
        }
    }

    public function getPaymentInvoice($id)
    {
        $this->set_page_data('Invoice', 'Invoice');
        $breadcrumb = ['Invoice' => ''];
        $payment = Payment::findOrFail($id);
        $roles = Role::where('slug', '!=', 'super-admin')->select('id', 'name')->get();

        return view('emails.confirmation', ['roles' => $roles, 'breadcrumb' => $breadcrumb, 'payment' => $payment]);
    }

    public function sendBookingConfirmationMail()
    {
        $data = [
            'subject' => 'Boooking Confirmation',
            'title' => 'Hello,',
            'content' => 'This is a custom email content.',
        ];

        Mail::to('shojeeb@myolbd.com')->queue(new TourConfirmationEmail($data));

        // return "Email sent successfully";
    }
}
