<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    protected $table = 'bookings';
    protected $guarded = [];

    public function bookedBy()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
    public function successfulPayment()
    {
        return $this->hasOne(Payment::class, 'booking_id', 'id')
            ->where('stripe_payment_status', 'succeeded');
    }
    public function payments()
    {
        return $this->hasMany(Payment::class, 'booking_id', 'id')->orderBy('id','desc');
    }
    public function lastPayment()
    {
        return $this->payments->orderBy('id','desc')->first();
    }
    public function bookingDetails()
    {
        return $this->hasMany(BookingDetails::class, 'booking_id', 'id');
    }
}
