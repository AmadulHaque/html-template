<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tour extends Model
{
    protected $table = 'tours';
    protected $guarded = [];

    public function category()
    {
        return $this->belongsTo(TourCategory::class, 'tour_category_id', 'id');
    }
    public function faqs()
    {
        return $this->hasMany(Faq::class, 'faq_id', 'id');
    }
    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by', 'id');
    }

    public function bookingDetails()
    {
        return $this->hasMany(BookingDetails::class, 'tour_id', 'id');
    }

}
